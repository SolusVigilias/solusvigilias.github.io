MirrorVerse Loop Lab v1.1, 7 September 2026

Requires Node.js 22 or later. No npm packages for the numerical experiment.
Create a folder called lab and unpack this archive inside it.
From lab:
  node experiment/run.mjs
  node experiment/verify-guide.mjs
  python3 experiment/verify-csv.py
Results are written to ../results.

For plots (prefer a Python virtual environment):
  python3 -m pip install -r experiment/requirements.txt
  python3 experiment/plot.py
Plots are written to ../plots.

The interactive lab uses the same lib/model.mjs. No fitting is performed.
