"""Independent stdlib verification of exported dynamics, errors, and aggregate metrics."""
import csv,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[2]
manifest=json.loads((root/'results/scenarios.json').read_text())
scenarios={s['id']:s['events'] for s in manifest['scenarios']}
expected={}
for name,events in scenarios.items():
 for a in range(8):
  for b in range(8):
   transfer=add=interaction=0;q=b//4;approx=a+b
   expected[(name,a,b,0)]=(a+b,a+b,approx)
   for t,ev in enumerate(events,1):
    e=ev['e'];rule=ev['rule']
    if rule=='transfer':transfer+=e;q=math.floor((4*q-e)/4)
    elif rule=='add':add+=e;approx+=e
    else:interaction+=e*(b-transfer);approx+=e*4*q
    expected[(name,a,b,t)]=(a+b+add+interaction,a+b+add,approx)
agg={};count=0
with (root/'results/traces.csv').open() as f:
 for r in csv.DictReader(f):
  k=(r['scenario'],int(r['a0']),int(r['b0']),int(r['t']));actual,sumhat,approxhat=expected[k]
  pred={'full':actual,'repaired':actual,'sum':sumhat,'approx':approxhat}[r['mode']]
  error=abs(pred-actual)
  assert (int(r['actual']),int(r['predicted']),int(r['absolute_error']))==(actual,pred,error),r
  g=agg.setdefault((r['scenario'],r['mode']),{'max':0,'total':0,'n':0,'firstFailure':17})
  g['max']=max(g['max'],error);g['total']+=error;g['n']+=1
  if error:g['firstFailure']=min(g['firstFailure'],int(r['t']))
  count+=1
with (root/'results/metrics.csv').open() as f:
 for r in csv.DictReader(f):
  g=agg[(r['scenario'],r['mode'])]
  assert g['max']==float(r['maxError'])
  assert abs(g['total']/g['n']-float(r['mae']))<1e-12
  assert min(16,g['firstFailure']-1)==int(r['horizon0'])
report={'allPassed':True,'rowsVerified':count,'scheduleMethodGroups':len(agg),'method':'Python standard library, accumulated transfer/add/interaction closed form; independent quantized recurrence and CSV reaggregation'}
(root/'results/independent-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
