import assert from 'node:assert/strict';
import { guideSnapshot } from '../lib/guide.mjs';

const expected = [
  { actual: [4, 4], predicted: [4, 4], state: 16, total: 58 },
  { actual: [5, 5], predicted: [5, 5], state: 16, total: 58 },
  { actual: [7, 6], predicted: [4, 4], state: 16, total: 58 },
  { actual: [7, 6], predicted: [4, 4], state: 16, total: 58 },
  { actual: [7, 6], predicted: [7, 6], state: 32, total: 74 },
];
for (const [index, values] of expected.entries()) {
  const step = guideSnapshot(index);
  assert.deepEqual(
    step.rows.map((row) => row.actual),
    values.actual,
  );
  assert.deepEqual(
    step.rows.map((row) => row.predicted),
    values.predicted,
  );
  assert.equal(step.budget.fields, values.state);
  assert.equal(step.budget.total, values.total);
}
assert.equal(guideSnapshot(3).floor, 0.5);
assert.equal(guideSnapshot(4).floor, 0);
console.log(
  'Guide verified: 5 stages, shared engine, reset semantics, prediction floor and packed costs.',
);
