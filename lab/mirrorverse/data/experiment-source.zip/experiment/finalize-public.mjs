import { rmSync, readdirSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '../build-public');
// Publish only the lab and its downloads; preserve the source public directory.
for (const item of readdirSync(root)) {
  if (!['index.html', 'assets', 'data', 'favicon.svg'].includes(item)) {
    rmSync(resolve(root, item), { recursive: true, force: true });
  }
}
rmSync(resolve(root, 'data/traces.csv'), { force: true });
function size(dir) { return readdirSync(dir).reduce((n, name) => {
  const path = resolve(dir, name), stat = statSync(path);
  return n + (stat.isDirectory() ? size(path) : stat.size);
}, 0); }
console.log(`Static release: ${size(root)} bytes, scoped to /lab/mirrorverse/.`);
