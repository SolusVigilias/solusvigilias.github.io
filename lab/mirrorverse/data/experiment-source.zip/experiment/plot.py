"""Render publication-ready SVG and PNG plots from saved results; no simulation."""
import json, sys, os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parents[3] / 'work' / 'matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path(__file__).resolve().parents[2]
source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'results'
out=Path(sys.argv[2]) if len(sys.argv)>2 else root/'plots'
out.mkdir(parents=True,exist_ok=True)
data=json.loads((source/'summary.json').read_text())
colors={'full':'#3779bd','sum':'#b46a20','approx':'#9b57ab','repaired':'#158d76'}
labels={'full':'Full state','sum':'Sum only','approx':'Approximate b','repaired':'Repaired (x,b)'}
plt.rcParams.update({'font.size':10,'axes.titlesize':12,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#f5f8fc','axes.facecolor':'#f5f8fc','text.color':'#1c2f45','axes.labelcolor':'#1c2f45','xtick.color':'#43556c','ytick.color':'#43556c','svg.hashsalt':'mirrorverse-v1'})
fig,ax=plt.subplots(1,3,figsize=(15.2,5.3),gridspec_kw={'width_ratios':[1.07,1.0,1.0]})
for m in colors:
 rows=sorted([r for r in data['byStep'] if r['group']=='mixed' and r['mode']==m],key=lambda r:r['t'])
 ax[0].plot([r['t'] for r in rows],[r['mae'] for r in rows],label=labels[m],color=colors[m],lw=2,ls='--' if m=='repaired' else '-',marker='o' if m=='full' else None,markersize=3)
ax[0].set(title='A  Mixed events: approximation can lose',xlabel='Event step',ylabel='Mean absolute output error (units)',xticks=[0,4,8,12,16]);ax[0].grid(axis='y',alpha=.2);ax[0].legend(frameon=False,fontsize=9,loc='upper left');ax[0].set_ylim(bottom=-.65)
for j,m in enumerate(colors):
 hs=[next(r['worstHorizon'] for r in data['summary'] if r['scenario']==s and r['mode']==m) for s in ['safe','boundary','interaction','mixed']]
 ax[1].bar(np.arange(4)+(j-1.5)*.2,hs,width=.18,color=colors[m])
 for i,v in enumerate(hs):
  if v==0:ax[1].plot(i+(j-1.5)*.2,.12,marker='_',color=colors[m],markersize=5)
ax[1].set(title='B  Exact depth depends on the context',ylabel='Worst supported prefix (steps)',xticks=np.arange(4),xticklabels=['Safe','Delayed\nboundary','Interaction','Mixed'],ylim=(0,18),yticks=[0,4,8,12,16]);ax[1].text(.02,.965,'Tolerance = 0; 16 = tested cap',transform=ax[1].transAxes,fontsize=9,va='top');ax[1].grid(axis='y',alpha=.2);ax[1].set_axisbelow(True)
items=[('Pair: full',32,'full'),('Pair: sum',16,'sum'),('Pair: approx.',24,'approx'),('Pair: repaired',32,'repaired'),('Nuisance: full',48,'full'),('Nuisance: repaired',32,'repaired')]
y=np.arange(len(items));ax[2].barh(y,[r[1] for r in items],color=[colors[r[2]] for r in items],height=.6,label='Retained state');ax[2].barh(y,[117]*len(y),left=[r[1] for r in items],color='#d2dce8',height=.6,label='Scenario + metadata')
for i,(_,bits,_) in enumerate(items):ax[2].text(bits+117+2,i,str(bits+117),va='center',fontsize=9)
ax[2].set(title='C  Packed budget at depth 16',xlabel='Logical retained bits',yticks=y,yticklabels=[r[0] for r in items],xlim=(0,183));ax[2].invert_yaxis();ax[2].legend(frameon=False,fontsize=9,loc='lower right',bbox_to_anchor=(1,-.28))
fig.suptitle('MirrorVerse Loop Lab · reproducible finite experiment',fontsize=17,x=.045,ha='left',y=.985)
fig.text(.045,.02,'64 initial pairs × 69 schedules × 4 representations. Seed 20260907. h = a + b. Exact analytic rules; no fitting.\nPanel A averages 64 mixed schedules; panel B takes the worst over all tested states/schedules. Zero-error full and repaired curves overlap.',fontsize=10,color='#51647c')
fig.subplots_adjust(left=.055,right=.977,top=.82,bottom=.25,wspace=.49)
for ext in ['svg','png']:fig.savefig(out/f'comparison.{ext}',dpi=190,metadata={'Date':None} if ext=='svg' else None)
plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.3))
t=np.arange(9)
ax[0].plot(t,4+3*t,color='#158d76',lw=2,marker='o',label='World A actual: 4 + 3t')
ax[0].plot(t,4+2*t,color='#9b57ab',lw=2,marker='s',label='World B actual: 4 + 2t')
ax[0].plot(t,np.full(9,4),color='#b46a20',lw=2,ls='--',label='Sum baseline: 4')
ax[0].fill_between(t,4+2*t,4+3*t,color='#b5bfd0',alpha=.25)
ax[0].set(title='Same x = 4, incompatible future totals',xlabel='Interaction steps (e = 1)',ylabel='Output a + b (units)',xticks=[0,2,4,6,8]);ax[0].legend(frameon=False,fontsize=9)
ax[1].plot(t,t/2,color='#243c5c',lw=2,label='Unavoidable real-valued minimax error ≥ t/2')
ax[1].plot(t,3*t,color='#b46a20',lw=2,ls='--',label='Chosen sum baseline worst error = 3t')
ax[1].set(title='Separate information loss from predictor choice',xlabel='Interaction steps (e = 1)',ylabel='Worst absolute error (units)',xticks=[0,2,4,6,8]);ax[1].legend(frameon=False,fontsize=9)
for a in ax:a.grid(axis='y',alpha=.2)
fig.tight_layout(pad=2)
for ext in ['svg','png']:fig.savefig(out/f'counterexample.{ext}',dpi=190,metadata={'Date':None} if ext=='svg' else None)
print(f'Plots written to {out}')
