import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  MODES,
  RULES,
  F,
  C,
  update,
  output,
  decode,
  key,
  rng,
  schedule,
  states,
  trace,
  evaluate,
  storage,
  inEncoding,
  routes,
  parseEvents,
} from '../lib/model.mjs';
import { pack, unpack } from '../lib/encoding.mjs';
const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  '../..',
);
const out = process.argv[2]
  ? path.resolve(process.argv[2])
  : path.join(root, 'results');
fs.mkdirSync(out, { recursive: true });
const tests = [];
let assertions = 0;
const eq = (a, b) => {
  assertions++;
  assert.deepEqual(a, b);
};
const ok = (x) => {
  assertions++;
  assert.ok(x);
};
const test = (name, fn) => {
  const before = assertions;
  fn();
  tests.push({ name, status: 'pass', assertions: assertions - before });
};
const finite = [];
for (let a = -8; a <= 8; a++)
  for (let b = -8; b <= 8; b++) finite.push({ a, b });
const inputs = [];
for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) inputs.push({ a, b });
const events = RULES.flatMap((rule) =>
  [-2, -1, 0, 1, 2].map((e) => ({ rule, e })),
);
let closureChecks = 0;
test('Required pair: exact full updates and compressed route counterexample', () => {
  eq(
    states().map((z) => C(z, 'sum')),
    [{ x: 4 }, { x: 4 }],
  );
  for (const [rule, expected] of [
    ['transfer', [4, 4]],
    ['add', [5, 5]],
    ['interaction', [7, 6]],
  ])
    eq(
      states().map((z) => output(F(z, { rule, e: 1 }))),
      expected,
    );
  eq(F({ a: 1, b: 3 }, { rule: 'transfer', e: 1 }), { a: 2, b: 2 });
  eq(F({ a: 1, b: 3 }, { rule: 'add', e: 1 }), { a: 2, b: 3 });
  eq(F({ a: 1, b: 3 }, { rule: 'interaction', e: 1 }), { a: 4, b: 3 });
  eq(update({ x: 4 }, { rule: 'interaction', e: 1 }, 'sum'), { x: 4 });
});
test('Full and repaired commute for all 289 grid states × 15 events', () => {
  for (const z of finite)
    for (const ev of events)
      for (const m of ['full', 'repaired']) {
        const r = routes(z, ev, m);
        eq(r.left, r.right);
        closureChecks++;
      }
});
test('Sum-only commutes for transfer and add throughout the finite grid', () => {
  for (const z of finite)
    for (const ev of events.filter((e) => e.rule !== 'interaction')) {
      const r = routes(z, ev, 'sum');
      eq(r.left, r.right);
      closureChecks++;
    }
});
test('Fiber consistency: equal sums have compatible compressed transfer/add successors', () => {
  for (const rule of ['transfer', 'add'])
    for (const e of [-2, -1, 0, 1, 2]) {
      const seen = new Map();
      for (const z of finite) {
        const k = key(C(z, 'sum')),
          v = key(C(F(z, { rule, e }), 'sum'));
        if (seen.has(k)) eq(seen.get(k), v);
        seen.set(k, v);
      }
    }
});
test('Output recovery: total factors through sum; b does not', () => {
  for (const z of finite)
    for (const m of MODES) eq(decode(C(z, m), m, 'sum'), output(z));
  for (const m of ['full', 'repaired'])
    for (const z of finite) eq(decode(C(z, m), m, 'b'), z.b);
  ok(states()[0].b !== states()[1].b);
  eq(C(states()[0], 'sum'), C(states()[1], 'sum'));
  eq(evaluate(states(), schedule('interaction', 2), 'sum', 'b').horizon, -1);
});
test('Coordinate invertibility: repaired representation preserves the whole pair', () => {
  for (const z of finite) {
    const r = C(z, 'repaired');
    eq({ a: r.x - r.b, b: r.b }, z);
  }
});
test('Approximate quantization discards distinctions and can fail closure under transfer', () => {
  const z = { a: 1, b: 3 },
    ev = { rule: 'transfer', e: 1 };
  eq(C(z, 'approx'), C({ a: 2, b: 2 }, 'approx'));
  const r = routes(z, ev, 'approx');
  eq(r.left, { x: 4, q: -1 });
  eq(r.right, { x: 4, q: 0 });
  ok(key(r.left) !== key(r.right));
});
test('No initial collision, yet approximation can still fail: update-design counterexample', () => {
  const zs = [
      { a: 1, b: 4 },
      { a: 2, b: 2 },
    ],
    ev = [
      { rule: 'transfer', e: 1 },
      { rule: 'interaction', e: 1 },
    ];
  const r = evaluate(zs, ev, 'approx');
  eq(r.floors, [0, 0, 0]);
  ok(r.maxError > 0);
});
test('Horizon is a prefix: cancellation does not erase an earlier boundary', () => {
  const ev = [
    { rule: 'interaction', e: 1 },
    { rule: 'interaction', e: -1 },
  ];
  const r = evaluate(states(), ev, 'sum');
  eq(r.errors, [0, 3, 0]);
  eq(r.horizon, 0);
  eq(r.informationHorizon, 0);
  eq(evaluate(states(), ev, 'sum', 'sum', 3).horizon, 2);
  eq(r.floors, [0, 0.5, 0]);
});
test('Exact observation supplies missing information without rewriting earlier errors', () => {
  const ev = schedule('interaction', 8);
  const r = evaluate(states(), ev, 'sum', 'sum', 0, 2);
  eq(r.errors.slice(0, 3), [0, 3, 6]);
  ok(r.errors.slice(3).every((e) => e === 0));
  eq(r.horizon, 0);
  eq(r.trajectories[0][2].r, { x: 10, b: 3 });
});
test('Irrelevant variables: full and repaired remain exact across 64 mixed schedules', () => {
  for (let i = 0; i < 64; i++) {
    const ev = schedule('mixed', 16, 20260907 + i);
    for (const m of ['full', 'repaired']) {
      const r = evaluate(states('nuisance'), ev, m);
      eq(r.maxError, 0);
      eq(
        r.trajectories[0].map((x) => x.actual),
        r.trajectories[1].map((x) => x.actual),
      );
    }
  }
  eq(
    storage('full', 16, true).fields - storage('repaired', 16, true).fields,
    16,
  );
});
test('Negative control: nuisance reduction fails if the output asks for u', () => {
  const [a, b] = states('nuisance');
  eq(C(a, 'repaired'), C(b, 'repaired'));
  ok(a.u !== b.u);
});
test('PRNG is reproducible and custom sequences validate and repeat', () => {
  eq(schedule('mixed', 16, 20260907), schedule('mixed', 16, 20260907));
  ok(
    key(schedule('mixed', 16, 20260907)) !==
      key(schedule('mixed', 16, 20260908)),
  );
  eq(parseEvents('T:1, A:-2, I:0', 4)[3], { rule: 'transfer', e: 1 });
  assert.throws(() => parseEvents('I:9', 4));
  assertions++;
});
test('Payload and all auxiliary fields round-trip through real packed serialization', () => {
  for (const mode of MODES)
    for (const nuisance of [false, true])
      for (const z of nuisance ? states('nuisance') : finite) {
        const ev = schedule('mixed', 16, 20260907),
          r = C(z, mode);
        const packed = pack(r, mode, ev, 'b', 0.25, 7, nuisance);
        const back = unpack(packed);
        eq(back.r, r);
        eq(back.events, ev);
        eq(back.tolerance, 0.25);
        eq(back.cursor, 7);
        eq(packed.bitLength, storage(mode, 16, nuisance).total);
        eq(packed.bytes.length * 8, packed.bitLength + packed.paddingBits);
      }
  const r = { x: 7, b: 3 },
    ev = schedule('interaction', 8),
    audit = { oldMode: 'sum', at: 1 };
  const packed = pack(r, 'repaired', ev, 'sum', 0, 1, false, audit);
  eq(unpack(packed, true).observation, audit);
  assert.throws(() => pack({ x: 32768 }, 'sum', ev));
  assertions++;
});
const partition = (ev, h = 'sum') =>
  new Set(
    inputs.map((z) =>
      JSON.stringify(trace(z, ev, 'full', h).map((r) => r.actual)),
    ),
  ).size;
test('Finite output-equivalence partitions: safe total needs 15 classes, interaction 64', () => {
  eq(partition(schedule('safe', 16)), 15);
  eq(partition(schedule('interaction', 1)), 64);
  eq(partition(schedule('mixed', 16), 'b'), 8);
});
const designs = ['transfer', 'add', 'interaction', 'safe', 'boundary'];
const scenarios = designs.map((name) => ({
  id: name,
  group: name,
  events: schedule(name, 16),
  seed: null,
}));
const master = rng(20260907);
for (let i = 0; i < 64; i++) {
  const seed = Math.floor(master() * 4294967296);
  scenarios.push({
    id: `mixed-${i.toString().padStart(2, '0')}`,
    group: 'mixed',
    events: schedule('mixed', 16, seed),
    seed,
  });
}
const metrics = [],
  traceLines = ['scenario,mode,a0,b0,t,rule,e,actual,predicted,absolute_error'];
let overflowCount = 0,
  trajectoryCount = 0;
const stepAggregate = {};
for (const s of scenarios)
  for (const mode of MODES) {
    const ev = evaluate(inputs, s.events, mode, 'sum', 0);
    const positive = evaluate(inputs, s.events, mode, 'sum', 2);
    metrics.push({
      scenario: s.id,
      group: s.group,
      mode,
      maxError: ev.maxError,
      mae: ev.mae,
      horizon0: ev.horizon,
      horizon2: positive.horizon,
      informationHorizon0: ev.informationHorizon,
      stateBits: storage(mode, 16).fields,
      totalBits: storage(mode, 16).total,
    });
    for (let i = 0; i < inputs.length; i++) {
      trajectoryCount++;
      for (const r of ev.trajectories[i]) {
        if (!inEncoding(r.r, mode)) overflowCount++;
        const p = pack(r.r, mode, s.events, 'sum', 0, r.t);
        eq(unpack(p).r, r.r);
        const prev = s.events[r.t - 1];
        traceLines.push(
          [
            s.id,
            mode,
            inputs[i].a,
            inputs[i].b,
            r.t,
            prev?.rule ?? 'initial',
            prev?.e ?? 0,
            r.actual,
            r.predicted,
            r.error,
          ].join(','),
        );
        const k = `${s.group}:${mode}:${r.t}`;
        const agg = stepAggregate[k] ?? {
          group: s.group,
          mode,
          t: r.t,
          totalError: 0,
          n: 0,
          maxError: 0,
        };
        agg.totalError += r.error;
        agg.n++;
        agg.maxError = Math.max(agg.maxError, r.error);
        stepAggregate[k] = agg;
      }
    }
  }
eq(overflowCount, 0);
const summary = [];
for (const scenario of [...designs, 'mixed'])
  for (const mode of MODES) {
    const rows = metrics.filter((r) => r.group === scenario && r.mode === mode);
    summary.push({
      scenario,
      mode,
      schedules: rows.length,
      maxError: Math.max(...rows.map((r) => r.maxError)),
      mae: rows.reduce((s, r) => s + r.mae, 0) / rows.length,
      worstHorizon: Math.min(...rows.map((r) => r.horizon0)),
      meanHorizon: rows.reduce((s, r) => s + r.horizon0, 0) / rows.length,
      worstHorizonTolerance2: Math.min(...rows.map((r) => r.horizon2)),
      stateBits: rows[0].stateBits,
      totalBits: rows[0].totalBits,
    });
  }
const byStep = Object.values(stepAggregate).map((r) => ({
  ...r,
  mae: r.totalError / r.n,
}));
const nuisanceMetrics = [];
for (const s of scenarios)
  for (const mode of MODES) {
    const r = evaluate(states('nuisance'), s.events, mode);
    nuisanceMetrics.push({
      scenario: s.id,
      group: s.group,
      mode,
      maxError: r.maxError,
      mae: r.mae,
      horizon0: r.horizon,
      stateBits: storage(mode, 16, true).fields,
      totalBits: storage(mode, 16, true).total,
    });
  }
const nuisanceSummary = MODES.map((mode) => {
  const rows = nuisanceMetrics.filter((r) => r.mode === mode);
  return {
    mode,
    maxError: Math.max(...rows.map((r) => r.maxError)),
    mae: rows.reduce((s, r) => s + r.mae, 0) / rows.length,
    worstHorizon: Math.min(...rows.map((r) => r.horizon0)),
    stateBits: storage(mode, 16, true).fields,
    totalBits: storage(mode, 16, true).total,
  };
});
const manifest = {
  schemaVersion: 1,
  seed: 20260907,
  prng: 'LCG: x=(1664525*x+1013904223) mod 2^32; u=x/2^32',
  initialStates: inputs,
  scenarios,
  output: 'a+b',
  depth: 16,
  tolerances: [0, 2],
  approximation:
    'q=floor(b/4); decode bHat=4q; re-quantize after every transfer',
  sumBaseline: 'bHat=0, fixed in schema; no fitted parameter',
  nuisanceExample: states('nuisance'),
};
const result = {
  schemaVersion: 1,
  seed: 20260907,
  testsPassed: tests.length,
  assertions,
  closureChecks,
  trajectoryCount,
  overflowCount,
  summary,
  nuisanceSummary,
  nuisanceTrajectoryCount: scenarios.length * MODES.length * 2,
  byStep,
  partitions: {
    initialDomainSize: 64,
    safeTotalClasses: 15,
    interactionDepth1Classes: 64,
    componentBClasses: 8,
  },
};
const csv = (rows) =>
  [
    Object.keys(rows[0]).join(','),
    ...rows.map((r) => Object.values(r).join(',')),
  ].join('\n') + '\n';
fs.writeFileSync(
  path.join(out, 'scenarios.json'),
  JSON.stringify(manifest, null, 2) + '\n',
);
fs.writeFileSync(
  path.join(out, 'summary.json'),
  JSON.stringify(result, null, 2) + '\n',
);
fs.writeFileSync(path.join(out, 'metrics.csv'), csv(metrics));
fs.writeFileSync(path.join(out, 'nuisance-metrics.csv'), csv(nuisanceMetrics));
fs.writeFileSync(path.join(out, 'traces.csv'), traceLines.join('\n') + '\n');
fs.writeFileSync(
  path.join(out, 'tests.json'),
  JSON.stringify(
    { tests, assertions, closureChecks, overflowCount, allPassed: true },
    null,
    2,
  ) + '\n',
);
console.log(
  JSON.stringify(
    {
      out,
      testsPassed: tests.length,
      assertions,
      trajectoryCount,
      overflowCount,
      summary,
    },
    null,
    2,
  ),
);
