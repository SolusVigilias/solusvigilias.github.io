"""Deterministic public downloads; run before the static Vite build."""
from pathlib import Path
import gzip, zipfile

lab = Path(__file__).resolve().parents[1]
data = lab / 'public/data'
(data / 'traces.csv.gz').write_bytes(gzip.compress((data / 'traces.csv').read_bytes(), mtime=0))
readme = '''MirrorVerse Loop Lab v1.1, 7 September 2026

Requires Node.js 22 or later. No npm packages for the numerical experiment.
Create a folder called lab and unpack this archive inside it.
From lab:
  node experiment/run.mjs
  node experiment/verify-guide.mjs
  python3 experiment/verify-csv.py
Results are written to ../results.

For plots (prefer a Python virtual environment):
  python3 -m pip install -r experiment/requirements.txt
  python3 experiment/plot.py
Plots are written to ../plots.

The interactive lab uses the same lib/model.mjs. No fitting is performed.
'''
with zipfile.ZipFile(data / 'experiment-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    files = [p for pat in ['lib/*.mjs', 'experiment/*'] for p in lab.glob(pat) if p.is_file()]
    entries = [(str(p.relative_to(lab)), p.read_bytes()) for p in sorted(files)] + [('README.txt', readme.encode())]
    for name, content in entries:
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, content)
