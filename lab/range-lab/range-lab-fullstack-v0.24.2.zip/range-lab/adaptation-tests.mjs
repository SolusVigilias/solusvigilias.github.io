import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {snapshot} from './dist/poker.js';
import {RESPONSE_PRIOR,trainResponse,responseContext} from './dist/adaptation.js';
import {publicContext,actionPolicy,seeded} from './dist/policy.js';
import {newBelief,updateBelief,beliefSummary,nodeBeliefs,conditionCards} from './dist/learning.js';
import {newPractice,practiceSave,practiceRestore,advancePracticeAdaptive,botDecisionInput,decisionMix,practicePolicy} from './dist/practice.js';
import {analyzeTree} from './dist/tree.js';

const near=(a,b,e=1e-6)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
let h=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Ad']});
h=appendLiveAction(h,{kind:'call',actor:'Hero'});h=appendLiveAction(h,{kind:'check',actor:'Bot'});h=appendLiveAction(h,{kind:'board',cards:['Qh','8d','4s']});
const ctx=publicContext(h,h.events.length,'Bot'),rows=conditionCards(newBelief(),ctx.board),opposing=beliefSummary(rows,ctx.board),model=RESPONSE_PRIOR();ctx.responseModel=model;
const event={kind:'bet',to:10},u=updateBelief(rows,ctx,event,opposing);
// Compare the marginal log-likelihood derivative to finite differences. The
// hidden holding is integrated out; no known hole-card labels train this fit.
const key=responseContext(ctx),epsilon=1e-5;
model.contexts[key]={theta:{bet:epsilon}};const plus=updateBelief(rows,ctx,event,opposing).logLoss;
model.contexts[key].theta.bet=-epsilon;const minus=updateBelief(rows,ctx,event,opposing).logLoss;
near(u.gradient.bet,-(plus-minus)/(2*epsilon));delete model.contexts[key];
const before=actionPolicy(ctx,['7c','2d'],0,opposing).filter(a=>a.kind==='bet').reduce((s,a)=>s+a.prob,0);
for(let i=0;i<20;i++){const action=i===19?{kind:'check'}:event;trainResponse(model,ctx,updateBelief(rows,ctx,action,opposing),action);}
const after=actionPolicy(ctx,['7c','2d'],0,opposing).filter(a=>a.kind==='bet').reduce((s,a)=>s+a.prob,0);
assert(after>before*2,'Repeated bets must learn a response beyond the four fixed styles.');assert.equal(model.actions,20);assert.equal(model.contexts[key].counts.bet,19);
console.log('Same weak holding, baseline vs learned bet probability:',before,after);

// Hold the bot's cards and public decision fixed. Fitting frequent opponent bets
// must affect its actual EV-based defense, not merely an observation counter.
h=appendLiveAction(h,{kind:'check',actor:'Bot'});
const heroContext=publicContext(h,h.events.length,'Hero');h=appendLiveAction(h,{...event,actor:'Hero'});
const defenses=[];
for(const fitted of [RESPONSE_PRIOR(),model]){
 const heroRows=updateBelief(rows,{...heroContext,responseModel:fitted},event,opposing).rows;
 const fixture={hand:h,type:0,botCards:['7c','7d'],filters:{Hero:heroRows,Bot:rows},responses:{Hero:fitted,Bot:RESPONSE_PRIOR()},learning:{sharedHands:0},config:{rakePct:5,rakeCap:1}};
 const estimate=await analyzeTree(botDecisionInput(fixture)),mix=decisionMix(estimate,practicePolicy(fixture),10);
 defenses.push({callEV:mix.find(a=>a.kind==='call').ev,fold:mix.find(a=>a.kind==='fold').prob});
}
assert(defenses[1].callEV>defenses[0].callEV);assert(defenses[0].fold-defenses[1].fold>.1,'Discounted observations must still materially change actual bot defense.');
console.log('Identical bot decision before / after observed frequent bets:',defenses);

// Reproduce the reported public action line with a synthetic bot draw. Calling
// costs 12 cents, despite a nominal 250-cent raise; excess is returned.
let short=createLiveHand({players:[{name:'Hero',stack:1380},{name:'Bot',stack:512}],heroSeat:1,button:2,sb:5,bb:10,cards:['Ac','Ad']});
for(const c of [
 {kind:'bet',actor:'Bot',to:20},{kind:'call',actor:'Hero'},
 {kind:'board',cards:['Th','3d','8h']},{kind:'bet',actor:'Hero',to:10},{kind:'call',actor:'Bot'},
 {kind:'board',cards:['3h']},{kind:'bet',actor:'Hero',to:20},{kind:'bet',actor:'Bot',to:120},
 {kind:'bet',actor:'Hero',to:220},{kind:'bet',actor:'Bot',to:470},{kind:'bet',actor:'Hero',to:720}
])short=appendLiveAction(short,c);
const c=publicContext(short,short.events.length,'Bot'),equivalent=structuredClone(c);
equivalent.level-=238;equivalent.pot-=238;equivalent.players.find(p=>p.name==='Hero').streetContribution-=238;
const original=actionPolicy(c,['Jh','9s'],0),corrected=actionPolicy(equivalent,['Jh','9s'],0);
near(original.find(a=>a.kind==='call').prob,corrected.find(a=>a.kind==='call').prob);
assert.equal(original.find(a=>a.kind==='call').cost,12);
const node=nodeBeliefs([],short,short.events.length),p={hand:short,type:0,botCards:['Jh','9s'],deck:[],filters:node.filters,responses:node.responses,learning:{sharedHands:0},config:{rakePct:5,rakeCap:1,extraFee:0}};
const input=botDecisionInput(p),changed=structuredClone(p);changed.hand.players[0].cards=['2c','2d'];changed.deck=['As','Ks'];
assert.deepEqual(botDecisionInput(changed),input,'Real Hero cards and future deck must not reach bot search.');
const result=await analyzeTree(input),mix=decisionMix(result,practicePolicy(p),10),call=mix.find(a=>a.kind==='call');
assert(call.ev>0,'A viable draw at this tiny price must have positive call EV.');assert(call.prob>.99,'The bot must act on the favorable short-call EV.');
console.log('12-cent call diagnostic:',{ev:call.ev,probability:call.prob,routes:call.routes});

// The live path fits the Hero action before searching, and restores the learned
// coefficients exactly from observations without double counting.
const random=seeded(234),live=newPractice([],0,null,random,{pauseAtBot:true});
await advancePracticeAdaptive(live,{kind:'bet',to:20},random);
assert.equal(live.responses.Hero.actions,1);assert(live.hand.live.complete||live.hand.live.actor==='Hero');
const restored=practiceRestore(practiceSave(live),[]);assert.deepEqual(restored.responses,live.responses);assert.deepEqual(restored.filters,live.filters);
console.log('PASS: likelihood gradient, online contextual fitting, effective call price, positive-EV short call, private information isolation, live policy improvement and exact resume.');
