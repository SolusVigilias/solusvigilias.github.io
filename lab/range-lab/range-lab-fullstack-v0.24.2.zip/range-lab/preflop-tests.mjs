import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {parseHistory,decisionIndices,snapshot,evDecision,actionCandidates,analyze,prior,rangeAt,DEFAULT_RESPONSE} from './dist/poker.js';
const config={betTo:.25,rakePct:0,rakeCap:0,extraFee:0,futureMin:-1,futureBet:0,preflopModel:'manual',response:DEFAULT_RESPONSE};
const matrix=row=>Object.fromEntries(Object.keys(DEFAULT_RESPONSE).map(k=>[k,row]));
const make=(stacks=[1000,1000,1000,1000,1000,1000],heroSeat=4)=>createLiveHand({players:stacks.map((stack,i)=>({name:i+1===heroSeat?'Hero':'P'+(i+1),stack})),heroSeat,button:1,sb:5,bb:10,cards:'As Ah',id:'LIVEpreflop',date:'2026/09/28 05:00:00'});
const act=(h,kind,to)=>appendLiveAction(h,{kind,actor:h.live.actor,...(to===undefined?{}:{to})});
const inputs=(hand,step=hand.events.length)=>({hand,step,ranges:Object.fromEntries(snapshot(hand,step).players.filter(p=>!p.folded&&p.name!==hand.hero).map(p=>[p.name,rangeAt(hand,step,p.name,prior('wide'),true)])),config,iterations:1000});
const close=(a,b)=>assert(Math.abs(a-b)<1e-8,`${a} should equal ${b}`);
const normalized=r=>{for(const [line,routes] of Object.entries(r.routes)){if(!routes.length)continue;close(routes.reduce((n,x)=>n+x.p,0),1);close(routes.reduce((n,x)=>n+x.contribution,0),r.ev[line]);}if(r.canRaise)close(Object.values(r.mix).reduce((a,b)=>a+b,0),1);};
let h=make();assert.equal(h.live.actor,'Hero');let args=inputs(h),r=analyze(args);assert(r.preflop);assert.equal(r.opponents,5);normalized(r);
let candidates=actionCandidates(args);for(const to of [.2,.22,.25,.3,.4])assert(candidates.some(a=>a.betTo===to));
for(const a of candidates.filter(a=>a.line==='aggressive'))act(h,'bet',Math.round(a.betTo*100));
const folds=analyze({...args,config:{...config,response:matrix([100,0,0])}});close(folds.ev.aggressive,.15);close(folds.mix.fold,1);close(folds.mix.call,0);normalized(folds);
const raises=analyze({...args,config:{...config,response:matrix([0,0,100])}});close(raises.ev.aggressive,-.25);close(raises.ev.passive,-.1);close(raises.mix.raise,1);
const calls=analyze({...args,config:{...config,response:matrix([0,100,0])}});close(calls.ev.aggressive,1.5*calls.equity-.25);close(calls.ev.passive,.6*calls.equity-.1);normalized(calls);
const shove=analyze({...args,config:{...config,betTo:10,response:matrix([0,0,100])}});close(shove.mix.raise,0);close(shove.ev.aggressive,60*shove.equity-10);
const rake=analyze({...args,config:{...config,rakePct:5,rakeCap:1,response:matrix([0,100,0])}});close(rake.ev.aggressive,1.425*rake.equity-.25);
const noFlop=analyze({...args,config:{...config,rakePct:20,rakeCap:1,extraFee:1,response:matrix([100,0,0])}});close(noFlop.ev.aggressive,.15);
// Hero on the button faces a raise with two players behind, then a 3-bet later.
h=make([1000,1000,1000,1000,1000,1000],1);h=act(h,'bet',30);h=act(h,'fold');h=act(h,'fold');
assert.equal(h.live.actor,'Hero');args=inputs(h);candidates=actionCandidates(args);assert(candidates.some(a=>a.label.startsWith('3-bet')&&a.betTo===.9));
h=act(h,'bet',90);h=act(h,'fold');h=act(h,'bet',270);h=act(h,'fold');assert.equal(h.live.actor,'Hero');assert(actionCandidates(inputs(h)).some(a=>a.label.startsWith('5-bet')));
// A raiser who has already acted does not get to raise again after a closing call.
h=make([1000,1000],1);h=act(h,'bet',30);h=act(h,'bet',90);args=inputs(h);assert(actionCandidates(args).some(a=>a.label.startsWith('4-bet')));r=analyze({...args,config:{...config,response:matrix([0,0,100])}});assert(!r.routes.passive.some(x=>x.name.includes('folds')));normalized(r);
// But the big blind keeps its option after a limp.
h=make([1000,1000],1);args=inputs(h);r=analyze({...args,config:{...config,response:matrix([0,0,100])}});close(r.ev.passive,-.05);
// Short all-in calls: Hero contests only the main pot, not the larger side pot.
h=make([1000,1000,100],3);h=act(h,'bet',200);h=act(h,'call');args=inputs(h);r=analyze({...args,config:{...config,response:matrix([0,100,0])}});
assert.equal(r.C,.9);assert(!r.canRaise);close(r.ev.passive,3*r.equity-.9);normalized(r);
// Covering wager: unmatched chips return before the showdown payoff.
h=make([1000,15],1);args=inputs(h);r=analyze({...args,config:{...config,betTo:.2,response:matrix([0,100,0])}});close(r.B,.1);close(r.ev.aggressive,.3*r.equity-.1);
// A short big blind does not reduce the nominal bring-in while several players have chips.
h=make([1000,1000,7,1000],4);const at=h.events.length;const later=act(h,'call');close(evDecision(later,at).C,.1);close(evDecision(later,at).minTo,20);
// Conflicting narrow ranges fail explicitly instead of dealing a duplicate card.
h=make([1000,1000,1000],1);args=inputs(h);const same={rows:[{cards:['Ks','Kh'],prob:1}]};assert.throws(()=>analyze({...args,ranges:{P2:same,P3:same},iterations:1}),/overlap/);
// Future replay cards/outcomes, or actual chosen action, never inform this node.
const hands=parseHistory(fs.readFileSync('./dist/sample.txt','utf8')).hands;
const imported=hands.find(h=>h.id==='HD145437828'),step=decisionIndices(imported)[0];args=inputs(imported,step);const baseline=analyze(args),future=structuredClone(imported);
for(const e of future.events.slice(step)){if(e.type==='street')e.board=['2c','3c','4c','5c','6c'].slice(0,e.board.length);if(e.type==='show')e.cards=['Ks','Kh'];}future.heroNet=99999;
assert.deepEqual(analyze({...args,hand:future}),baseline);normalized(baseline);
console.log('PASS: 6-max preflop, legal open/3-bet/4-bet sizes, field folds/calls/raises, blind option and closed action, main/side pots, short calls, refunds, fees, joint blockers, and future-information isolation.');
