import assert from 'node:assert/strict';
import {createLiveHand} from './dist/live.js';
import {DECK,evaluate,bucket} from './dist/poker.js';
import {evaluate as referenceEvaluate,bucket as referenceBucket} from './perf/reference-poker.mjs';
import {nodeBeliefs} from './dist/learning.js';
import {handSignal,seeded,publicContext,actionPolicy} from './dist/policy.js';
import {handSignal as referenceSignal,actionPolicy as referencePolicy} from './perf/reference-policy.mjs';
import {buildExactGame,trainExact,exactPolicyFor} from './dist/exact-cfr.js';
import {buildExactGame as buildReference,trainExact as trainReference} from './perf/reference-exact-cfr.mjs';
const rng=seeded(491);
for(let n=0;n<16000;n++){
 const cards=[];while(cards.length<7){const c=DECK[Math.floor(rng()*52)];if(!cards.includes(c))cards.push(c);}
 for(const size of [2,3,4,5,6,7])assert.deepEqual(evaluate(cards.slice(0,size)),referenceEvaluate(cards.slice(0,size)));
 const board=cards.slice(2);assert.equal(bucket(cards.slice(0,2),board),referenceBucket(cards.slice(0,2),board));assert.equal(handSignal(cards.slice(0,2),board),referenceSignal(cards.slice(0,2),board));
}
let hand=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Js']});
const input={hand,step:hand.events.length,beliefState:nodeBeliefs([],hand,hand.events.length)};
const ctx=publicContext(hand,hand.events.length,'Hero');assert.deepEqual(actionPolicy(ctx,['As','Js']),referencePolicy(ctx,['As','Js']));
const before=buildReference(input),after=buildExactGame(input),iterations=150;
let t=performance.now();trainReference(before,iterations);const oldMs=performance.now()-t;t=performance.now();trainExact(after,iterations);const newMs=performance.now()-t;
assert.equal(before.randomState,after.randomState);assert.equal(before.nodes.size,after.nodes.size);let maxError=0;
for(const [key,a] of before.nodes){const b=after.nodes.get(key);assert(b,key);assert.deepEqual(a.actions,b.actions);for(const field of ['base','regret','sum'])a[field].forEach((v,i)=>{maxError=Math.max(maxError,Math.abs(v-b[field][i]));});assert.equal(a.updates,b.updates);assert.equal(a.averageVisits,b.averageVisits);}
assert(maxError<1e-9,'Exact optimization changed training');
console.log(JSON.stringify({passed:true,iterations,informationSets:after.nodes.size,oldMs,newMs,speedup:oldMs/newMs,maxError}));
