import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {nodeBeliefs,conditionCards,newBelief,comboMass} from './dist/learning.js';
import {analyzeCfr,cfrBudget} from './dist/river-cfr.js';
import {treePanel} from './dist/learning-ui.js';
let h=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Opponent',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['Ad','Jc']});
for(const a of [{kind:'bet',actor:'Hero',to:120},{kind:'call',actor:'Opponent'},{kind:'board',cards:['Qh','Js','7d']},{kind:'check',actor:'Opponent'}])h=appendLiveAction(h,a);
const step=h.events.length,config={rakePct:5,rakeCap:1,extraFee:0};
const result=await analyzeCfr({hand:h,step,hands:[],config,solveOptions:{iterations:60,samples:256,runouts:8}});
assert.equal(result.model,'exact-hand-cfr');assert.equal(result.actions.length,5);
assert(Math.abs(result.allActions.reduce((v,a)=>v+a.policy,0)-1)<1e-10);
for(const a of result.allActions){
 assert(Math.abs(a.tree.ev-a.ev)<1e-9);
 assert(Math.abs(a.routes.reduce((v,r)=>v+r.p,0)-1)<1e-9);
 assert(Math.abs(a.routes.reduce((v,r)=>v+r.contribution,0)-a.ev)<1e-9);
 assert(Math.abs(a.routes.reduce((v,r)=>v+r.p*r.investment,0)-a.expectedInvestment)<1e-9);
 for(const r of a.routes)assert(Math.abs(r.payoff-(r.award-r.investment))<1e-9);
 if(a.heroActionRange.length)assert(Math.abs(a.heroActionRange.reduce((v,r)=>v+r.probability,0)-1)<1e-9);
 assert(a.heroActionRange.every(r=>r.cards.every(c=>!['Qh','Js','7d'].includes(c))));
}
const check=result.allActions.find(a=>a.kind==='check');assert.equal(check.immediateInvestment,0);assert(check.zeroInvestmentProbability>0);assert(check.routes.some(r=>r.zeroInvestment));
const jam=result.allActions.find(a=>a.to===880);assert(jam);assert.equal(jam.immediateInvestment,8.8);assert(jam.routes.some(r=>r.name.startsWith('Opponent folds')&&r.investment===0));
const before=nodeBeliefs([],h,step);assert(Object.values(before.filters).every(rows=>rows.every(r=>r.cards.every(c=>!['Qh','Js','7d'].includes(c)))));
h=appendLiveAction(h,{kind:'check',actor:'Hero'});h=appendLiveAction(h,{kind:'board',cards:['As']});h=appendLiveAction(h,{kind:'check',actor:'Opponent'});
const after=nodeBeliefs([],h,h.events.length);for(const rows of [...Object.values(after.filters),...Object.values(after.views).map(v=>v.rows)]){assert(rows.every(r=>!r.cards.includes('As')));assert(Math.abs(rows.reduce((v,r)=>v+r.prob,0)-1)<1e-9);}
const two=[{cards:['As','Kd'],prob:.6},{cards:['Ah','Kd'],prob:.4}];assert.deepEqual(conditionCards(two,['As']),[{cards:['Ah','Kd'],prob:1}]);
const blocked=comboMass(conditionCards(newBelief(),['Qh','Js','7d','Ad','Jc']));assert.equal(blocked.length,1081);
const turn=await analyzeCfr({hand:h,step:h.events.length,hands:[],config,solveOptions:{iterations:20,samples:128}});assert(turn.allActions.every(a=>a.heroActionRange.every(r=>!r.cards.includes('As'))));
assert.equal(await analyzeCfr({hand:h,step:h.events.length,hands:[],cancel:()=>true}),null);
// Future public cards in replay must not affect a solve at an earlier decision.
const replay=await analyzeCfr({hand:h,step,hands:[],config,solveOptions:{iterations:60,samples:256,runouts:8}});assert.deepEqual(replay.allActions,result.allActions);
assert.deepEqual(cfrBudget(0),{iterations:600});
const html=treePanel(h,step,{config:{engine:'belief'},ranking:result},String);assert(html.includes('All legal root actions'));assert(html.includes('Played mixture'));assert(html.includes('Zero net further investment'));assert(html.includes('MC margin'));
console.log(JSON.stringify({passed:true,checkZeroProbability:check.zeroInvestmentProbability,fallbackRate:result.fallbackRate,actions:result.allActions.length}));
