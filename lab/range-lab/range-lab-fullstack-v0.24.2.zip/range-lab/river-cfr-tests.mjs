import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {newBelief,conditionCards} from './dist/learning.js';
import {buildRiverGame,trainRiver,measureRiver,solveRiverCfr} from './dist/river-cfr.js';
import {legalActions,publicContext,seeded} from './dist/policy.js';
import {advancePracticeAdaptive,botDecisionInput} from './dist/practice.js';
import {RESPONSE_PRIOR} from './dist/adaptation.js';
import {practiceView} from './dist/learning-ui.js';
let h=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Ad']});
for(const c of [{kind:'call',actor:'Hero'},{kind:'check',actor:'Bot'},{kind:'board',cards:['Qh','8d','4s']},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:['2c']},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:['9h']}])h=appendLiveAction(h,c);
const rows=conditionCards(newBelief(),['Qh','8d','4s','2c','9h']);
const p={hand:h,type:0,botCards:['Qc','Qd'],deck:['3c'],filters:{Hero:rows,Bot:rows},responses:{Hero:RESPONSE_PRIOR(),Bot:RESPONSE_PRIOR()},learning:{sharedHands:0},config:{rakePct:5,rakeCap:1,extraFee:0}};
const input=botDecisionInput(p),game=buildRiverGame(input,{samples:2048}),initial=measureRiver(game);
// Same own information, two hidden opponent types, opposite best actions.
// A legitimate best response gets zero; one that peeks would get +1.
const mass=Array(36).fill(0);mass[0]=mass[1]=.5;
const v=Array(36).fill(0);v[0]=1;v[1]=-1;
const toy={root:{actor:0,actions:[{id:'a'},{id:'b'}],sum:Array.from({length:6},()=>[1,1]),children:[{values:[v,v.map(x=>-x)]},{values:[v.map(x=>-x),v]}]},mass,ownType:0};
assert.equal(measureRiver(toy).nashConv,0,'Best responses may not distinguish hidden opponent types.');
const noRake=buildRiverGame({...input,config:{rakePct:0,rakeCap:0,extraFee:0}},{samples:64}),rootPot=publicContext(input.hand,input.step,input.hand.hero).pot/input.hand.bb;
function conservation(node){if(node.values){for(let k=0;k<36;k++)assert(Math.abs(node.values[0][k]+node.values[1][k]-rootPot)<1e-10);return;}node.children.forEach(conservation);}
conservation(noRake.root);
trainRiver(game,2000);const result=measureRiver(game);
assert(result.nashConv<initial.nashConv/5,'CFR must materially reduce the measured deviation gap.');
assert(Math.abs(result.policy.reduce((n,a)=>n+a.prob,0)-1)<1e-10);
const legal=legalActions(publicContext(input.hand,input.step,input.hand.hero));assert.deepEqual(result.policy.map(a=>a.id),legal.map(a=>a.id));
const changed=structuredClone(p);changed.hand.players[0].cards=['7c','6c'];changed.deck=['5c'];assert.deepEqual(botDecisionInput(changed),input,'Opponent hidden cards/future deck must not reach CFR.');
const otherOwn=structuredClone(input);otherOwn.hand.players.find(x=>x.name===otherOwn.hand.hero).cards=['7c','6c'];
const otherGame=buildRiverGame(otherOwn,{samples:2048});assert.deepEqual(otherGame.mass,game.mass,'The public training game must not reveal the bot’s actual cards.');
assert.equal(await solveRiverCfr(input,{samples:64,cancel:()=>true}),null);
await advancePracticeAdaptive(p,null,seeded(73));assert.equal(p.lastDecision.engine,'river-cfr');assert(p.lastAction.includes('River CFR'));assert(p.hand.live.actor==='Hero'||p.hand.live.complete);
const state={config:{engine:'belief',treeSamples:200,rakePct:5,rakeCap:1},loading:false};
const markup=practiceView(p,state,String,String);if(!p.hand.live.complete){assert(markup.includes('Hand-specific action frequencies become visible'));assert(!markup.includes('Export CFR decision'));}
const complete=structuredClone(p);complete.hand.live.complete=true;assert(practiceView(complete,state,String,String).includes('Export CFR decision'));
console.log('PASS: river convergence diagnostic, legal root actions, normalized strategy, hidden-card isolation, public game invariance, cancellation and actual bot CFR path.',{initialGap:initial.nashConv,finalGap:result.nashConv,iterations:result.iterations,nodes:result.nodeCount});
