# v0.24.1: preserve learned wager beliefs

## Change

`wagerConditionedBeliefs` now preserves the already-conditioned belief state.
Human wagers retain the learned predictive likelihood. Recorded bot actions
retain their recorded policy likelihood. Neither is applied a second time.
The old hypothetical opponent CFR reconstruction has been removed. This saves
one reconstruction solve on affected analysis/all-in paths, not every bot turn.
The worker also applies CFR_ITERATIONS to restored/in-progress games.

## Bayesian interpretation

Let D be public observations before the action, s the public state, h the
opponent holding, and theta the opponent response parameters. The full target is

    q_new(h,theta) ∝ pi_theta(a | h,s) q_old(h,theta).

The hand posterior and parameter posterior are its two marginals. Under the
approximate factorization q_old(h,theta) ≈ R(h) rho(theta), the predictive
likelihood is L(h) = integral pi_theta(a | h,s) rho(theta) dtheta and

    R_new(h) = R(h)L(h) / sum_j R(j)L(j).
    rho_new(theta) ∝ rho(theta) sum_h R(h)pi_theta(a | h,s).

Both use the same pre-observation distribution: do not feed R_new back into
this same parameter update as if it were independent evidence.

## What is actually implemented

The existing contextual response model stores coefficient means and diagonal
precisions. Four fixed antithetic Gaussian parameter draws approximate predictive
action probabilities. An online gradient/curvature update, coefficient clipping,
and an eight-opportunity half-life update compact parameters. These are approximate
inference and adaptation mechanisms, not exact Bayesian density propagation or a
full joint posterior over hands and strategy. The baseline remains heuristic;
this patch does not introduce a solved GTO prior or establish playing strength.
Public board cards remove incompatible holdings before normalization.

The parameter update occurs after computing the action likelihood and hand update.
This patch preserves that output in downstream wager evaluation rather than
replacing it with a hypothetical CFR policy.

## Remaining limitations

Shown cards currently constrain the range at the reveal; they do not yet perform
retrospective supervised refitting of all earlier actions in that hand.
The patch does not resolve every source of overcalling or solver latency.

## Deployment

Finish the pending action. Upload the v0.24.1 ZIP to the server and extract in the
home directory with `unzip -o`. The archive excludes .env, private keys, and data.
From ~/range-lab run:

    sudo docker compose --profile public up -d --build --wait
    curl --fail --show-error https://poker.solusvigilias.com/api/health

The health response should report version 0.24.1. Do not remove Docker volumes.
