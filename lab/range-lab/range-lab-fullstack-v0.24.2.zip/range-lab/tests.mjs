import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseHistory,snapshot,memory,ALL_COMBOS,evaluate,prior,rangeAt,analyze,decisionIndices,DEFAULT_RESPONSE} from './dist/poker.js';
const text=fs.readFileSync(new URL('./dist/sample.txt',import.meta.url),'utf8');
const {hands,errors}=parseHistory(text,'sample');
assert.equal(hands.length,42);assert.equal(errors.length,0);assert.equal(hands.flatMap(h=>h.warnings).length,0);
assert.equal(hands.reduce((a,h)=>a+h.heroNet,0),1018);assert.equal(hands.reduce((a,h)=>a+h.totalFees,0),282);
for(const h of hands){const end=snapshot(h,h.events.length);assert.equal(end.pot,0);assert.equal(end.players.reduce((a,p)=>a+p.stack,0),h.players.reduce((a,p)=>a+p.stack,0)-h.totalFees);}
const nines=hands.find(h=>h.id==='HD145438261');assert.equal(nines.heroNet,792);assert.equal(nines.events.find(e=>e.actor==='Hero'&&e.action==='raises').contribution,513);assert.equal(nines.events.find(e=>e.type==='return').amount,298);
assert.equal(parseHistory(hands.map(h=>h.raw).join('\n\n'),'roundtrip').hands.length,42);
assert.throws(()=>parseHistory('not a poker history'));
assert.throws(()=>parseHistory(text.split('*** SUMMARY')[0]));
const stats=memory(hands);assert.equal(stats.reduce((a,p)=>a+p.net,0),-282);assert.equal(stats.find(p=>p.name==='Hero').vpip,10);
const earliest=[...hands].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id))[0];assert.equal(memory(hands,earliest).length,0);
assert.equal(ALL_COMBOS.length,1326);assert.equal(ALL_COMBOS.filter(c=>c.cls==='AA').length,6);assert.equal(ALL_COMBOS.filter(c=>c.cls==='AKs').length,4);assert.equal(ALL_COMBOS.filter(c=>c.cls==='AKo').length,12);
const rank=s=>evaluate(s.split(' '));
const examples=['As Ks Qs Js Ts 2c 3d','As Ah Ac Ad Ks 2c 3d','As Ah Ac Ks Kh 2c 3d','As Js 8s 5s 2s Kc Qd','As 2h 3c 4d 5s Kc Qd','As Ah Ac Kd Qs 2c 3d','As Ah Kc Kd Qs 2c 3d','As Ah Kc Qd Js 2c 3d','As Kh Qc Jd 9s 2c 3d'];
for(let i=0;i<examples.length;i++){assert.equal(rank(examples[i]).category,8-i);if(i)assert(rank(examples[i-1]).score>rank(examples[i]).score);}
assert.equal(rank('As Ah Ac Ks Kh Kd 2s').category,6);assert.equal(rank('As Ks Qs Js Ts 2d 3c').score,rank('As Ks Qs Js Ts 9d 8c').score);
const h=hands.find(h=>h.id==='HD145437828'),step=decisionIndices(h).find(i=>h.events[i].street==='Turn'),s=snapshot(h,step),opp=s.players.find(p=>p.name!==h.hero&&!p.folded);
const range=rangeAt(h,step,opp.name,prior('wide'),true);assert(range.total>0);for(const c of range.rows)assert(c.cards.every(x=>![...s.board,...h.players.find(p=>p.name===h.hero).cards].includes(x)));
assert(Math.abs(range.rows.reduce((a,c)=>a+c.prob,0)-1)<1e-9);
const config={opponent:opp.name,betTo:.5,rakePct:5,rakeCap:1,extraFee:0,futureMin:-1,futureBet:1,preflopModel:'manual',postflopModel:'manual',response:DEFAULT_RESPONSE};
let result=analyze({hand:h,step,range,config,iterations:5000});
for(const line of Object.values(result.routes)){assert(Math.abs(line.reduce((a,r)=>a+r.p,0)-1)<1e-8);assert(line.every(r=>Number.isFinite(r.payoff)&&r.p>=0));}
const changed=structuredClone(h);changed.heroNet=-999999;for(const e of changed.events.slice(step+1)){if(e.type==='show')e.cards=['As','Ah'];if(e.type==='street')e.board=['2h','3h','4h','5h','6h'].slice(0,e.board.length);}
assert.deepEqual(analyze({hand:changed,step,range,config,iterations:5000}),result,'Future observations must not influence EV.');
const turn=decisionIndices(h).find(i=>h.events[i].street==='Turn'),turnRange=rangeAt(h,turn,opp.name,prior('wide'),true);
result=analyze({hand:h,step:turn,range:turnRange,config:{...config,futureMin:5,futureBet:.8},iterations:1000});
for(const line of Object.values(result.routes))assert(Math.abs(line.reduce((a,r)=>a+r.p,0)-1)<1e-8);
const ninesStep=decisionIndices(nines).find(i=>nines.events[i].street==='River');assert.throws(()=>analyze({hand:nines,step:ninesStep,range,config}),/heads-up/);
console.log('PASS: all 42 hand ledgers, refunds, fees, exports, memory cutoff, hand evaluator, blockers, route probabilities, future-card isolation, and multiway guard.');

// Exercise the actual UI handlers with a minimal document adapter. This is not a browser layout test.
const handlers={},docHandlers={},registered={},downloads=[];
const app={innerHTML:'',addEventListener:(t,f)=>handlers[t]=f};
globalThis.window={addEventListener(){}};
globalThis.document={getElementById:id=>id==='app'?app:{click(){},focus(){},setSelectionRange(){}},addEventListener:(t,f)=>docHandlers[t]=f,body:{classList:{add(){},remove(){}}},createElement:()=>({click(){}}),modelContext:{registerTool:t=>registered[t.name]=t}};
globalThis.fetch=async()=>({text:async()=>text});
globalThis.URL.createObjectURL=blob=>{downloads.push(blob);return 'blob:test';};globalThis.URL.revokeObjectURL=()=>{};
await import('./dist/app.js');
const click=(action,value,id)=>handlers.click({target:{closest:()=>({dataset:{action,value,id}})},preventDefault(){}});
const change=(id,value,extra={})=>handlers.change({target:{id,value,classList:{contains:()=>false},...extra}});
click('sample');await new Promise(resolve=>setTimeout(resolve,0));
change('analysis-engine','legacy');
assert(app.innerHTML.includes('42 hands'));assert(app.innerHTML.includes('Hand replay'));
const session=()=>registered.read_imported_session.execute();
const awaitCalculation=async()=>{for(let i=0;i<100&&session().calculating;i++)await new Promise(r=>setTimeout(r,50));assert.equal(session().calculating,false);};
assert(app.innerHTML.includes('Top 5 EV actions'));click('rank-actions');await awaitCalculation();
assert.equal(session().ranking.actions.length,5);assert(session().ranking.preflop);assert(session().ranking.opponents>1);assert(app.innerHTML.includes('EV contribution'));
assert(app.innerHTML.includes('Best tested'));assert(app.innerHTML.includes('View routes'));
change('bet-to','0.81');assert.equal(session().ranking,null);
click('rank-actions');click('next');await new Promise(r=>setTimeout(r,100));
assert.equal(session().ranking,null,'Cancelled ranking must not appear at another node.');
registered.select_hand_decision.execute({handId:h.id,eventIndex:step});

click('view','ranges');assert(app.innerHTML.includes('Range construction'));assert(app.innerHTML.includes('range-scroll'));
click('calculate');await new Promise(r=>setTimeout(r,500));assert(registered.read_imported_session.execute().result);
assert.equal(session().result.model,'postflop-range');assert(app.innerHTML.includes('Inspect fold / call / raise ranges'));click('export-response-ranges','decision');const branchExport=JSON.parse(await downloads.at(-1).text());assert.equal(branchExport.model,'postflop-range');assert(branchExport.ranges.combos.length>0);click('rank-actions');await awaitCalculation();assert.equal(session().ranking.model,'postflop-range');const rangeAction=session().ranking.actions.find(a=>a.responseRanges);assert(rangeAction);assert(app.innerHTML.includes('Within branch'));click('export-response-ranges',rangeAction.id);assert(JSON.parse(await downloads.at(-1).text()).ranges.branches.call);change('postflop-bluffs','0.25');assert.equal(session().result,null);change('postflop-mix','',{checked:true});assert.equal(session().result,null);change('postflop-mix','',{checked:false});change('postflop-model','manual');assert(app.innerHTML.includes('Legacy model:'));change('postflop-model','range');change('postflop-bluffs','0.5');
click('view','memory');assert(app.innerHTML.includes('Player observations'));
const selected=registered.select_hand_decision.execute({handId:h.id,eventIndex:step});assert.equal(selected.street,'Turn');assert.throws(()=>registered.select_hand_decision.execute({handId:'bad',eventIndex:-1}));
click('export-project');const project=await downloads.at(-1).text();assert.equal(JSON.parse(project).format,'range-lab');
change('import-files','',{files:[{name:'test.json',size:project.length,text:async()=>project}]});await new Promise(r=>setTimeout(r,200));assert.equal(registered.read_imported_session.execute().hands.length,42);
change('import-files','',{files:[{name:'bad.txt',size:4,text:async()=>'junk'}]});await new Promise(r=>setTimeout(r,200));assert.equal(registered.read_imported_session.execute().hands.length,42);assert(app.innerHTML.includes('Import failed'));
change('import-files','',{files:[{name:'duplicate.txt',size:text.length*2,text:async()=>text+text}]});await new Promise(r=>setTimeout(r,200));assert.equal(registered.read_imported_session.execute().hands.length,42);assert(app.innerHTML.includes('duplicate IDs skipped'));
click('view','ranges');fs.writeFileSync('/workspace/scratch/b11c1bc8474c/range-lab-rendered-check.html',app.innerHTML);
console.log('PASS: actual UI event handlers, all three views, EV calculation, valid/invalid navigation, project import/export, failed-import preservation, duplicate detection. Browser layout and native WebMCP context were not available.');

// Live entry exercises the same delegated handlers users invoke.
const liveFields=new Map();
document.getElementById=id=>id==='app'?app:liveFields.get(id)||{click(){},focus(){},setSelectionRange(){}};
const draft=(id,value)=>handlers.input({target:{id,value,dataset:{liveDraft:''}}});
click('live-new');assert(app.innerHTML.includes('Start a live hand'));
draft('live-count','2');draft('live-cards','As Kh');click('live-start');
assert(app.innerHTML.includes('LIVE HAND'));assert(app.innerHTML.includes('IN PROGRESS'));
const liveID=registered.read_imported_session.execute().selected;assert(liveID.startsWith('LIVE'));
assert(app.innerHTML.includes('Top 5 EV actions'));const liveStep=session().step;
click('rank-actions');await awaitCalculation();assert.equal(session().ranking.actions.length,5);
assert.equal(session().step,liveStep,'Comparing must not enter a live action.');
click('view','replay');assert(app.innerHTML.includes('Best tested'));
click('view','live');assert(app.innerHTML.includes('Best tested'));

click('live-act','check');assert(app.innerHTML.includes('cannot check'));
click('live-act','call');assert.equal(session().ranking,null);click('live-act','check');assert(app.innerHTML.includes('Enter the flop'));
liveFields.set('live-board',{value:'As 3d 7s'});click('live-board');assert(app.innerHTML.includes('duplicates'));
liveFields.set('live-board',{value:'2c 3d 7s'});click('live-board');assert(app.innerHTML.includes('Player 2'));
click('live-act','check');click('live-analyze');assert(app.innerHTML.includes('Hero decision'));
click('calculate');await new Promise(r=>setTimeout(r,500));assert(registered.read_imported_session.execute().result);
click('export-project');const liveProject=await downloads.at(-1).text();
const liveSaved=JSON.parse(liveProject);assert.equal(liveSaved.version,3);assert.equal(liveSaved.config.postflopModel,'range');assert.equal(liveSaved.config.postflopBluffFactor,.5);assert.equal(liveSaved.config.postflopUseMix,false);assert.equal(liveSaved.hands.find(h=>h.live)?.live.commands.length,4);
change('import-files','',{files:[{name:'live.json',size:liveProject.length,text:async()=>liveProject}]});await new Promise(r=>setTimeout(r,200));
assert.equal(registered.read_imported_session.execute().selected,liveID);assert(app.innerHTML.includes('IN PROGRESS'));
click('live-undo');assert(app.innerHTML.includes('Player 2'));click('live-act','check');
liveFields.set('live-amount',{value:'0.20'});click('live-act','bet');click('live-act','fold');assert(app.innerHTML.includes('Record the result'));
liveFields.set('live-fee',{value:'0.00'});click('live-finish');assert(app.innerHTML.includes('HAND COMPLETE'));
click('export-hand');assert.equal(parseHistory(await downloads.at(-1).text()).hands[0].heroNet,10);
click('live-next');assert(app.innerHTML.includes('value="101"'));assert(app.innerHTML.includes('99 BB'));click('live-cancel');
console.log('PASS: live setup, legal action controls, board validation, current-node EV, unfinished project export/import, undo, settlement, text export, and carried stacks.');

// Seat/profile selection and the deck must drive the actual live UI state.
liveFields.clear();click('live-new');draft('live-count','2');
const profileOptions=[...app.innerHTML.matchAll(/<option value="([^"]+)"[^>]*>([^<]+)<\/option>/g)];
const decode=x=>x.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>');
const importedHero=profileOptions.find(([,value,label])=>value.includes('Hero [')&&label.includes('duplicate.txt'));
assert(importedHero,'Imported Hero should appear in the history picker.');
change('live-profile',decode(importedHero[1]),{dataset:{liveProfile:''}});
click('live-card','As');click('live-card','Kh');assert(app.innerHTML.includes('As')&&app.innerHTML.includes('picked'));
click('live-card','Qc');assert(app.innerHTML.includes('Remove a selected card'));
click('live-start');const visualLiveID=registered.read_imported_session.execute().selected;
click('export-project');let visualProject=JSON.parse(await downloads.at(-1).text());
let visualHand=visualProject.hands.find(x=>x.live?.spec.id===visualLiveID);assert.equal(visualHand.live.spec.players[0].memoryKey,decode(importedHero[1]));
click('live-act','call');click('live-act','check');
click('live-card','As');assert(app.innerHTML.includes('already in use'));
for(const c of ['2c','3d','7s'])click('live-card',c);click('live-board');
click('live-act','check');click('live-act','check');click('live-card','8c');click('live-board');
click('live-act','check');click('live-act','check');click('live-card','9h');click('live-board');
click('live-act','check');click('live-act','check');
click('live-seat','2');click('live-card','Ks');click('live-card','Kd');
click('live-auto-finish');assert(app.innerHTML.includes('HAND COMPLETE'));
click('export-project');visualProject=JSON.parse(await downloads.at(-1).text());visualHand=visualProject.hands.find(x=>x.live?.spec.id===visualLiveID);
assert.deepEqual(visualHand.live.commands.at(-1).shown['Player 2'],['Ks','Kd']);
click('live-next');assert(app.innerHTML.includes('NEXT HAND'));assert(!app.innerHTML.includes('class="deck-card suit-s picked"'));
click('live-card','Ac');click('live-card','Qd');click('live-start');
click('export-project');visualProject=JSON.parse(await downloads.at(-1).text());
const continued=visualProject.hands.find(x=>x.live?.spec.handNumber===2&&x.live.spec.sessionId===visualHand.live.spec.sessionId);
assert(continued);assert.equal(continued.live.spec.button,2);assert.equal(continued.live.spec.players[0].memoryKey,visualHand.live.spec.players[0].memoryKey);
assert.deepEqual(continued.live.spec.players.map(p=>p.stack),[990,1010]);
change('import-files','',{files:[{name:'visual-session.json',size:JSON.stringify(visualProject).length,text:async()=>JSON.stringify(visualProject)}]});await new Promise(r=>setTimeout(r,200));
assert(app.innerHTML.includes('HAND 2'));assert(app.innerHTML.includes('PLAYER MEMORY'));
console.log('PASS: imported-player picker, card clicks, duplicate-card prevention, community-card progression, shown-card selection, next-hand rotation/stack/profile carry, and resumed visual session.');

// Six-seat live preflop comparisons and visual sizing use the current Hero node.
liveFields.clear();click('live-new');draft('live-count','6');draft('live-hero','4');draft('live-cards','As Ah');click('live-start');
assert(app.innerHTML.includes('Hero vs 5 opponents'));assert(app.innerHTML.includes('2.5 BB'));
click('live-size','to-25');assert(app.innerHTML.includes('value="0.25"'));
click('rank-actions');await awaitCalculation();assert(session().ranking.preflop);assert.equal(session().ranking.opponents,5);assert.equal(session().ranking.actions.length,5);
click('live-act','bet');assert.equal(session().ranking,null);
click('view','replay');click('preflop-decision');assert(app.innerHTML.includes('Hero vs 5 opponents'));
console.log('PASS: imported preflop landing, six-player live Top 5 EV, BB sizing preset, invalidation after betting, and preflop replay shortcut.');

// Baseline controls invalidate results and persist through project export/import.
assert(app.innerHTML.includes('General cash baseline (default)'));
change('population-tightness','0.04');assert.equal(session().ranking,null);
change('preflop-model','manual');assert(app.innerHTML.includes('size-independent calls can make large shoves'));
click('export-project');let baselineProject=JSON.parse(await downloads.at(-1).text());assert.equal(baselineProject.config.preflopModel,'manual');assert.equal(baselineProject.config.populationTightness,.04);
change('preflop-model','cash');click('export-project');baselineProject=JSON.parse(await downloads.at(-1).text());assert.equal(baselineProject.config.preflopModel,'cash');
const legacyBaseline=structuredClone(baselineProject);delete legacyBaseline.config.preflopModel;delete legacyBaseline.config.populationTightness;
change('import-files','',{files:[{name:'legacy-baseline.json',size:JSON.stringify(legacyBaseline).length,text:async()=>JSON.stringify(legacyBaseline)}]});await new Promise(r=>setTimeout(r,200));
click('export-project');const migrated=JSON.parse(await downloads.at(-1).text());assert.equal(migrated.config.preflopModel,'cash');assert.equal(migrated.config.populationTightness,0);assert.deepEqual(migrated.priors,legacyBaseline.priors);
console.log('PASS: cash/manual baseline controls, tighter/looser assumptions, result invalidation, and legacy-project migration preserving range edits.');

// Stack entry uses BB, but the ledger and next-hand carry retain exact cents.
liveFields.clear();click('live-new');draft('live-count','2');draft('live-cards','As Kh');
assert(app.innerHTML.includes('Current stack (BB)'));assert(app.innerHTML.includes('value="100"'));
draft('live-stack-0','100.01');click('live-start');assert(app.innerHTML.includes('Enter a stack in BB that equals whole cents'));
draft('live-stack-0','123.4');change('live-bb','0.20',{dataset:{liveDraft:''}});
assert(app.innerHTML.includes('value="61.7"'),'Changing the blind preserves the stack’s cash value.');
click('live-start');assert(app.innerHTML.includes('class="visual-stack">61.45 BB'));
const bbHandID=session().selected;click('export-project');let bbProject=JSON.parse(await downloads.at(-1).text());
const bbHand=bbProject.hands.find(x=>x.live?.spec.id===bbHandID);
assert.equal(bbHand.live.spec.bb,20);assert.equal(bbHand.live.spec.players[0].stack,1234);
click('view','replay');click('first');assert(app.innerHTML.includes('<span>61.7 BB</span>'));
click('view','ranges');assert(app.innerHTML.includes('<span>Hero stack</span><b>61.7 BB</b>'));
click('view','live');click('live-act','fold');click('live-finish');click('live-next');
assert(app.innerHTML.includes('value="61.45"'));assert(app.innerHTML.includes('50.25 BB'));
change('live-sb','0.01',{dataset:{liveDraft:''}});change('live-bb','0.03',{dataset:{liveDraft:''}});
assert(app.innerHTML.includes('value="409.666666667"'));
click('live-card','Ac');click('live-card','Qd');click('live-start');click('export-project');
bbProject=JSON.parse(await downloads.at(-1).text());
const bbNext=bbProject.hands.find(x=>x.live?.spec.sessionId===bbHand.live.spec.sessionId&&x.live.spec.handNumber===2);
assert.equal(bbNext.live.spec.bb,3);assert.deepEqual(bbNext.live.spec.players.map(p=>p.stack),[1229,1005]);
console.log('PASS: BB stack display and input, fractional-cent validation, stake conversion, replay/EV stacks, and exact next-hand/export balances.');
