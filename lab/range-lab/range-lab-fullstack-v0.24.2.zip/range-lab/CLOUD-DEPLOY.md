# Range Lab cloud play — v0.24.2

This is a runnable Node 24 full-stack application. No npm dependencies, external AI API, or GPU are required. The server serves the mobile table and the existing analysis workspace. Its poker worker runs the existing experimental bot.

## Local use

```sh
npm start
```

Open http://localhost:3000. A SQLite database is created under `data/`. Create a player and deal. To use a different port, set `PORT`. The static-only/offline workspace remains available with `npm run start:static`.

## Cloud deployment

Use one Linux VPS with Docker Compose, preferably 2 GB or more of RAM. This release uses one calculation worker with a 512 MB JS heap cap and a container memory limit of 1 GB. It is intended for a small invitation-only playtest. A queue keeps concurrent requests from multiplying CPU use; it does not make a single calculation instantaneous.

1. Copy this project onto the server.
2. Point a subdomain, such as `poker.solusvigilias.com`, at the server's public IP. The domain must belong to you and resolve to this server.
3. Copy `.env.example` to `.env`. Set `DOMAIN` and replace `INVITE_CODE` with a private random code of at least 16 characters. Production startup rejects the placeholder. Set `ALLOWED_ORIGINS` to the exact frontend origins you use, without a path. Keep `.env` private.
4. Open TCP ports 80 and 443 in the provider firewall. Keep port 3000 private.
5. Start:

```sh
docker compose --profile public up -d --build
```

Caddy obtains HTTPS certificates. Visit your subdomain. Players create an identity using the invitation code and retain their private recovery key. To use the existing Sites or GitHub frontend, open Cloud play and enter this HTTPS server origin. The server must allow that frontend origin.

For a private smoke test, `docker compose up -d --build app` exposes the backend only at the VPS's 127.0.0.1:3000. Use an SSH port forward to access it locally. `DOMAIN` is still required by Compose interpolation.

## Cost control

A $10 account credit is a hosting budget, not a per-player wallet. This application has no real-money deposits, winnings, or payment handling.

Choose a fixed-size server and verify the provider's current total including tax, IP addresses, disk and transfer. Provider credits and billing alerts are not necessarily hard spending limits. A running or powered-off VPS can continue accruing charges until the resource is deleted. No provider account has been created or charged by this project.

Application controls:

- One solver worker; at most eight running/queued commands by default.
- One outstanding command per player; no automatic worker scaling.
- 90-second wall-clock timeout per command; a failed calculation leaves the committed game intact.
- 3,600 solver wall-seconds globally per UTC day; 600 per player.
- The full timeout is reserved on admission and unused time is refunded after completion. Queue time is excluded. Reservations survive a crash conservatively; a restart cannot bypass them.
- Admission limits and quotas persist in SQLite. These are **workload controls, not a dollar meter or a cloud billing stop**. They do not stop the VM bill.
- A 100-player cap, per-IP signup throttling, command throttling, small request bodies, and a 1,000-hand history retention cap per player.

`CFR_ITERATIONS=0` preserves the existing per-street defaults. A lower override can reduce latency but changes solver coverage. Cloud compute does not correct the opponent-model weaknesses identified in the previous review, and this bot is not validated as GTO.

## What moved to the server

Deck generation, hidden cards, betting state, bot decisions, player identity, compact learned memory, and completed hand history. The browser receives only a public game projection, its own cards, and cards actually shown. A worker sends a public deal preview before calculating the bot's response. One warm game tree is retained in memory; persisted games can resume after worker/server restarts with a fresh solve.

The original range/history analysis workspace and local practice still run in the browser. This release moves **cloud practice play** to the server; it does not migrate every analysis panel or add human-versus-human tables. Download completed hands and import them into the workspace for analysis.

## Recovery and backups

Identity is a random bearer recovery key; the database stores only its SHA-256 hash. Keep keys private. Losing a key loses access to that player unless the operator develops a recovery procedure. This is invitation-based prototype identity, not email login.

The SQLite volume holds hidden cards and player memory. Keep server/backup access private. For a simple consistent backup, stop the app, back up the `game-data` Docker volume, then restart. Do not copy only the SQLite file while it is active in WAL mode. Restore the entire stopped volume. `docker compose down` preserves volumes; `down -v` deletes them.

Do not run multiple API processes against separate databases: queue admission is designed for one API process with one worker. A future larger deployment should introduce a shared job queue and database.

## API

- `GET /api/health` — service identity and queue counts.
- `POST /api/players` — `{name, invite}`; returns a private token once.
- `GET /api/me` — public game, pending job, memory count and quota.
- `POST /api/commands` — `{kind, version, requestId, action?}`. `kind` is `new`, `next`, `rebuy` or `act`; `action` is `{kind: fold|check|call|bet, to?}`. `to` uses integer cents internally, while the UI displays BB. Arbitrary private cards, chip states or solver budgets cannot be supplied by clients.
- `GET /api/jobs/:id` — only the authenticated player's job; includes safe deal previews.
- `GET /api/history` — that player's completed histories as `.txt`.

All endpoints except health and player creation require `Authorization: Bearer <recovery key>`. Requests use optimistic game versions and idempotency keys; retries cannot apply an action twice. Keys expire from the idempotency table after seven days, but stale game versions still prevent replaying old actions. CORS is restricted to the server origin and explicit allowlist. Behind a trusted reverse proxy set `TRUST_PROXY=1`; do not expose that API listener directly to the internet.

## Verification

```sh
npm run test:server
```

The server suite covers ownership, private-data filtering, command validation, duplicate and stale actions, persisted recovery, queue and quota limits, and a real engine worker hand. Original poker tests remain under `npm test`.
