import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {evDecision,actionCandidates,rankActionResults,analyze,rangeAt,prior,DEFAULT_RESPONSE,snapshot} from './dist/poker.js';
const config={betTo:.27,rakePct:0,rakeCap:0,extraFee:0,futureMin:-1,futureBet:0,preflopModel:'manual',postflopModel:'manual',response:DEFAULT_RESPONSE};
const make=(stacks=[1000,1000])=>createLiveHand({players:stacks.map((stack,i)=>({name:i?'V':'Hero',stack})),heroSeat:1,button:1,sb:5,bb:10,cards:'As Ah',id:'LIVEranking',date:'2026/09/28 05:00:00'});
const act=(h,kind,to)=>appendLiveAction(h,{kind,actor:h.live.actor,...(to===undefined?{}:{to})});
const board=(h,cards)=>appendLiveAction(h,{kind:'board',cards});
function candidates(h){return actionCandidates({hand:h,step:h.events.length,config});}
function legal(h){
 const d=evDecision(h,h.events.length),as=candidates(h),aggressive=as.filter(a=>a.line==='aggressive');
 assert.equal(new Set(aggressive.map(a=>a.investment)).size,aggressive.length);
 for(const a of aggressive){
  const to=Math.round(a.betTo*100);assert(to>=Math.min(d.minTo,d.maxTo)&&to<=d.maxTo);
  const updated=act(h,'bet',to);assert(updated.events.some(e=>e.actor==='Hero'&&e.type==='action'));
 }
 return as;
}
let h=make(),as=legal(h);assert(as.some(a=>a.line==='fold'));assert(as.some(a=>a.betTo===.27));assert(as.some(a=>a.detail==='All-in'));
assert(as.find(a=>a.betTo===.3),'A pot raise includes the call before sizing: 5 + 5 + (15 + 5) = 30 cents total.');
as=legal(make([15,1000]));assert.equal(as.length,3);assert.equal(as.at(-1).betTo,.15);assert.equal(as.at(-1).detail,'All-in');
as=legal(make([1000,15]));assert.equal(as.length,3);assert.equal(as.at(-1).betTo,.2,'Covering a short stack still requires a legal minimum raise.');assert.equal(as.at(-1).investment,.1);
as=candidates(make([1000,7]));assert.deepEqual(as.map(a=>a.line),['fold','passive']);
assert.deepEqual(candidates(make([7,1000])).map(a=>a.line),['fold','passive']);

// River certainty provides independently known EVs for sorting and payoff accounting.
h=act(h,'call');h=act(h,'check');
for(const cards of ['2c 3d 7s','8c']){h=board(h,cards);h=act(h,'check');h=act(h,'check');}
h=board(h,'9h');h=act(h,'check');
const river=h,alwaysCall={...config,response:Object.fromEntries(Object.keys(DEFAULT_RESPONSE).map(k=>[k,[0,100,0]]))};
function ranked(h,cards,cfg=alwaysCall){
 const step=h.events.length,actions=actionCandidates({hand:h,step,config:cfg}),range={rows:[{cards,prob:1,bucket:'made'}]},results=actions.map((a,order)=>{
  const r=analyze({hand:h,step,range,config:{...cfg,betTo:a.betTo??cfg.betTo},iterations:20});
  return {...a,order,ev:a.line==='fold'?0:r.ev[a.line],routes:a.line==='fold'?[{p:1,contribution:0}]:r.routes[a.line],result:r};
 });
 for(const a of results){assert(Math.abs(a.routes.reduce((n,r)=>n+r.p,0)-1)<1e-9);assert(Math.abs(a.routes.reduce((n,r)=>n+r.contribution,0)-a.ev)<1e-9);}
 const ranking=rankActionResults(results);for(let i=1;i<ranking.actions.length;i++)assert(ranking.actions[i].ev<=ranking.actions[i-1].ev);return ranking;
}
let ranking=ranked(h,['Ks','Kd']);assert.equal(ranking.actions.length,5);assert.equal(ranking.actions[0].detail,'All-in');assert(Math.abs(ranking.actions[0].ev-10.1)<1e-9);assert(!candidates(h).some(a=>a.line==='fold'));
const covering=make([1000,15]),range={rows:[{cards:['Ks','Kd'],prob:1,bucket:'made'}]};
const covered=analyze({hand:covering,step:covering.events.length,range,config:{...alwaysCall,betTo:.2},iterations:10});assert.equal(covered.betTo,.2);assert.equal(covered.B,.1);assert.equal(covered.mix.raise,0);
// Both views must use only the information available at the decision.
h=act(river,'bet',20);h=act(h,'bet',40);const before=h.events.length;
const knownRange=rangeAt(h,before,'V',prior('wide'),true),baseline=analyze({hand:h,step:before,range:knownRange,config,iterations:100});
const future=act(h,'fold');assert.deepEqual(actionCandidates({hand:future,step:before,config}),actionCandidates({hand:h,step:before,config}));
assert.deepEqual(analyze({hand:future,step:before,range:knownRange,config,iterations:100}),baseline);
ranking=ranked(h,['9s','9d']);assert.equal(ranking.actions[0].line,'fold');assert.equal(ranking.actions[0].ev,0);assert(ranking.actions.slice(1).every(a=>a.ev<0));
// Tie ordering is deterministic and fewer than five routes are preserved.
const small=rankActionResults([{id:'call',ev:0,order:1},{id:'fold',ev:0,order:0}]);assert.equal(small.actions.length,2);assert.equal(small.actions[0].id,'fold');assert(small.actions.every(a=>a.gap===0));
console.log('PASS: ranked sizes are legal, stack-bounded and deduplicated; covering/short all-ins, pot-raise sizing, EV order and known river payoffs, route totals, ties and future-information isolation.');
