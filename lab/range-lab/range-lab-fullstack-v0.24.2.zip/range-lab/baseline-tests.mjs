import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {analyze,rangeAt,prior,snapshot,cashResponse,cashStrength,DEFAULT_RESPONSE} from './dist/poker.js';
const config={preflopModel:'cash',populationTightness:0,rakePct:5,rakeCap:1,extraFee:0,futureMin:-1,futureBet:0,response:DEFAULT_RESPONSE,betTo:.25};
function make(cards='As Js',stack=1000,scale=1){let h=createLiveHand({players:Array.from({length:6},(_,i)=>({name:i?'P'+(i+1):'Hero',stack:stack*scale})),heroSeat:1,button:1,sb:5*scale,bb:10*scale,cards,id:'LIVEbaseline',date:'2026/09/28 05:59:00'});for(let i=0;i<3;i++)h=appendLiveAction(h,{kind:'fold',actor:h.live.actor});return h;}
function inputs(hand,extra={}){const step=hand.events.length,ranges=Object.fromEntries(snapshot(hand,step).players.filter(p=>!p.folded&&p.name!==hand.hero).map(p=>[p.name,rangeAt(hand,step,p.name,prior('all'),true,false,config)]));return {hand,step,ranges,config:{...config,...extra},iterations:20000};}
const close=(a,b)=>assert(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const row=(cards,level=25,extra={})=>cashResponse({cards,position:'BB',aggressorPosition:'BTN',owed:level-10,pot:level+15,level,bb:10,effective:1000,canRaise:level<1000,...extra});
for(const cards of [['As','Js'],['Qs','Qh'],['7s','2h'],['As','Ks']]){
 let previous=1;
 for(const level of [25,40,100,250,1000]){const probs=row(cards,level),continuing=1-probs[0];close(probs.reduce((a,b)=>a+b,0),1);assert(probs.every(p=>p>=0&&p<=1));assert(continuing<=previous+1e-8);previous=continuing;}
}
assert(row(['As','Js'],1000)[0]>row(['As','Js'])[0]);assert.equal(row(['As','Js'],1000)[2],0);
assert(row(['As','Ah'],1000)[1]>row(['7s','2h'],1000)[1]);
assert(1-row(['9s','8s'],25,{position:'BB'})[0]>=1-row(['9s','8s'],25,{position:'SB'})[0]);
assert(1-row(['9s','8s'],25,{tightness:.04})[0]<=1-row(['9s','8s'],25,{tightness:-.04})[0]);
let args=inputs(make());assert(Object.values(args.ranges).every(r=>r.rows.length===1225),'Unacted unknowns retain every unblocked combination.');
const small=analyze(args),shove=analyze({...args,config:{...config,betTo:10}});
assert(shove.mix.fold>small.mix.fold);assert(shove.calledEquity<small.calledEquity);assert(small.ev.aggressive>shove.ev.aggressive,'The 100 BB AJs shove must not beat a small open under the neutral baseline.');
assert(small.routes.aggressive.some(r=>r.name.includes('Hero calls')));assert(small.routes.aggressive.some(r=>r.name.includes('Hero folds')));
for(const result of [small,shove]){for(const [line,rs] of Object.entries(result.routes)){close(rs.reduce((n,r)=>n+r.p,0),1);close(rs.reduce((n,r)=>n+r.contribution,0),result.ev[line]);assert(rs.every(r=>r.payoff>=-10-1e-8&&r.payoff<=20+1e-8));}close(Object.values(result.mix).reduce((a,b)=>a+b,0),1);}
// Money denomination is not a fabricated population signal. Same BB/rake inputs => scaled EV.
const scaleBase=analyze({...args,config:{...config,betTo:.2}}),scaled=analyze({...inputs(make('As Js',1000,10),{betTo:2,rakeCap:10}),iterations:20000});close(scaled.ev.aggressive,scaleBase.ev.aggressive*10);close(scaled.mix.fold,scaleBase.mix.fold);
// No future observations or actual opponent holdings can enter a baseline response.
let future=appendLiveAction(args.hand,{kind:'bet',actor:'Hero',to:25});future.heroNet=9999;future.players.filter(p=>p.name!=='Hero').forEach(p=>p.cards=['Ks','Kh']);assert.deepEqual(analyze({...args,hand:future}),small);
// Historical actions tighten the prior, while retaining a small uncertainty floor.
let h=createLiveHand({players:Array.from({length:6},(_,i)=>({name:i?'P'+(i+1):'Hero',stack:1000})),heroSeat:1,button:1,sb:5,bb:10,cards:'As Js',id:'LIVEhistory',date:'2026/09/28 05:59:00'});
h=appendLiveAction(h,{kind:'bet',actor:h.live.actor,to:25});
const before=rangeAt(h,2,'P4',prior('all'),true,false,config),after=rangeAt(h,h.events.length,'P4',prior('all'),true,false,config),mean=r=>r.rows.reduce((n,c)=>n+c.prob*cashStrength(c.cards),0);
assert(mean(after)>mean(before));assert.equal(after.rows.length,before.rows.length);
// Premium/weak hands and short/deep stacks remain finite under the same policy.
for(const cards of ['As Ah','7s 2h'])for(const stack of [200,1000]){const x=analyze({...inputs(make(cards,stack),{betTo:stack/100}),iterations:500});assert(Number.isFinite(x.ev.aggressive));assert.equal(x.mix.raise,0);}
console.log('PASS: cash baseline tightens by size, keeps unacted ranges complete, handles position/tendency, permits Hero calls, preserves BB scaling/blockers, and ranks a small AJs open above the 100 BB shove.');
console.log(JSON.stringify({AJs100BB:{smallOpenEV_BB:small.ev.aggressive/.1,shoveEV_BB:shove.ev.aggressive/.1,smallOpenFoldProbability:small.mix.fold,shoveFoldProbability:shove.mix.fold}}));
