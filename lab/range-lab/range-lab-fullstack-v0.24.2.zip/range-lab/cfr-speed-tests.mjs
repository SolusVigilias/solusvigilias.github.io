import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {newBelief} from './dist/learning.js';
import {buildRiverGame,trainRiver,measureRiver} from './dist/river-cfr.js';
import {trainRiverReference} from './cfr-reference-test-helper.mjs';
const h=createLiveHand({players:[{name:'Bot',stack:1000},{name:'Hero',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Js']}),rows=newBelief();
const input=hand=>({hand,step:hand.events.length,beliefState:{filters:{Bot:rows,Hero:rows}},config:{rakePct:5,rakeCap:1,extraFee:0}});
const start=performance.now(),old=buildRiverGame(input(h),{samples:2048,runouts:32}),buildMs=performance.now()-start,fast=structuredClone(old);
let t=performance.now();trainRiverReference(old,400);const oldMs=performance.now()-t;t=performance.now();trainRiver(fast,400);const newMs=performance.now()-t;
const baseline=measureRiver(old),optimized=measureRiver(fast);let maxRegret=0,maxAverage=0;
function compare(a,b){if(a.regret){for(let t=0;t<6;t++)for(let i=0;i<a.actions.length;i++){maxRegret=Math.max(maxRegret,Math.abs(a.regret[t][i]-b.regret[t][i]));maxAverage=Math.max(maxAverage,Math.abs(a.sum[t][i]-b.sum[t][i]));}}a.children?.forEach((c,i)=>compare(c,b.children[i]));}compare(old.root,fast.root);
console.log('comparison',{oldMs,newMs,maxRegret,maxAverage,oldGap:baseline.nashConv,newGap:optimized.nashConv,policyDiff:baseline.policy.map((a,i)=>a.prob-optimized.policy[i].prob)});assert(maxRegret<1e-4);assert(maxAverage<1e-5);assert(Math.abs(baseline.nashConv-optimized.nashConv)<1e-8);baseline.policy.forEach((a,i)=>assert(Math.abs(a.prob-optimized.policy[i].prob)<1e-8));
console.log('PASS: all-node regrets/average policies and exact best-response gap match the reference at 400 iterations.',{buildMs,oldMs,newMs,speedup:oldMs/newMs,maxRegret,maxAverage,oldGap:baseline.nashConv,newGap:optimized.nashConv});
// Later-street games, correlated chance reach, chunked resume and zero support.
let river=h;for(const a of [{actor:'Bot',kind:'call'},{actor:'Hero',kind:'check'},{kind:'board',cards:['Qh','8d','4s']},{actor:'Hero',kind:'check'},{actor:'Bot',kind:'check'},{kind:'board',cards:['2c']},{actor:'Hero',kind:'check'},{actor:'Bot',kind:'check'},{kind:'board',cards:['9h']},{actor:'Hero',kind:'check'}])river=appendLiveAction(river,a);
const a=buildRiverGame(input(river),{samples:64}),b=structuredClone(a);trainRiverReference(a,100);trainRiver(b,30);trainRiver(b,70);const da=measureRiver(a),db=measureRiver(b);assert(Math.abs(da.nashConv-db.nashConv)<1e-8);da.policy.forEach((r,i)=>assert(Math.abs(r.prob-db.policy[i].prob)<1e-8));
console.log('PASS: river game and chunked training retain equivalent results.');
