import assert from 'node:assert/strict';
import {parseHistory,playerKey} from './dist/poker.js';
import {completeMemory,nodeBeliefs,restoreMemory} from './dist/learning.js';
const raw=`Poker Hand #SHOWTEST: Hold'em No Limit ($0.05/$0.10) - 2026/10/01 18:41:21
Table 'Test' 6-max Seat #2 is the button
Seat 1: Hero ($10.00 in chips)
Seat 2: Bot ($10.00 in chips)
*** HOLE CARDS ***
Dealt to Hero [Ad 9s]
Bot: posts small blind $0.05
Hero: posts big blind $0.10
Bot: raises $0.10 to $0.20
Hero: calls $0.10
*** FLOP *** [4d 6h Td]
Hero: checks
Bot: checks
*** TURN *** [4d 6h Td] [2c]
Hero: checks
Bot: checks
*** RIVER *** [4d 6h Td 2c] [6s]
Hero: checks
Bot: checks
Bot: shows [5h Ac]
Hero: shows [Ad 9s]
Hero collected $0.38 from pot
*** SUMMARY ***
Total pot $0.40 | Rake $0.02`;
const {hands,errors}=parseHistory(raw);assert.equal(errors.length,0);const h=hands[0];assert.equal(h.warnings.length,0);
const unknown=structuredClone(h);unknown.events=unknown.events.filter(e=>e.type!=='show');
const step=h.events.findIndex(e=>e.type==='show');
assert.deepEqual(nodeBeliefs([],h,step),nodeBeliefs([],unknown,step),'Future reveals cannot change decision-time beliefs');
const knownMemory=completeMemory(h),unknownMemory=completeMemory(unknown);
for(const p of h.players){const key=playerKey(h,p),known=knownMemory.profiles[key],blind=unknownMemory.profiles[key];
 assert.equal(known.actions,blind.actions);assert.equal(known.response.actions,blind.response.actions);
 assert.notDeepEqual(known.response.contexts,blind.response.contexts,'Known holdings must change hand-dependent fitting');
}
assert.equal(knownMemory.hands,1);
assert.deepEqual(restoreMemory(JSON.parse(JSON.stringify(knownMemory))),knownMemory);
assert.deepEqual(completeMemory(h),knownMemory,'Rebuilding from the same pre-hand checkpoint is deterministic');
const secret=structuredClone(unknown);secret.players[1].cards=['Ah','Kh'];
assert.deepEqual(completeMemory(secret),unknownMemory,'Unrevealed private cards must not train memory');
const second=structuredClone(h);second.memoryStart=knownMemory;
const twice=completeMemory(second);assert.equal(twice.hands,2);
for(const p of h.players){const key=playerKey(h,p);assert.equal(twice.profiles[key].actions,2*knownMemory.profiles[key].actions);}
console.log('PASS: reveal-aware fitting, unchanged action counts, no future-card leakage, hidden-card isolation, compact persistence and consecutive hands.');
