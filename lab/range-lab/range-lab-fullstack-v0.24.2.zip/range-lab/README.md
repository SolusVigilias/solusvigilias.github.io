# Range Lab

A dependency-free poker workspace with a Node 24 cloud-play backend and the original browser analysis tools. Includes the supplied 42-hand example.

## Cloud play (v0.24)

Run `npm start`, then open http://localhost:3000. The mobile cloud table receives public game state from a server-owned deck and a separate poker worker. SQLite persists identities, compact player memory and completed hands. Queue, quota, timeout, optimistic-version and idempotency controls bound workload and protect games during reconnects. The original workspace is at `/index.html`.

See [CLOUD-DEPLOY.md](CLOUD-DEPLOY.md) for the Docker Compose, HTTPS, subdomain, invitation and backup setup. This release provides the portable backend; a running cloud server must be supplied to the published frontend. Existing browser analysis and strategy-model limitations remain.

## Faster exact computation and restored probes (v0.23)

This release keeps individual hands and the same training budgets. It eliminates repeated computation: an exact rank-mask evaluator replaces sorting and map construction; hand strength and draw classification share one calculation; board evaluations and legal menus are cached; summary subsets are selected once; one-action policies skip strength evaluation; fold terminals skip showdown evaluation; immutable action records allow shallow state copies; and strategy probabilities are normalized once per query. Menu sharing never merges beliefs or information sets. Progress rendering is throttled while cancellation still yields frequently.

`exact-speed-tests.mjs` freezes the v0.22 modules in `perf/` and compares 96,000 two-to-seven-card evaluations, draw classifications, hand signals and the complete 150-iteration training state. All 43,593 information sets, action menus, regret sums and average-strategy sums matched with maximum numeric difference 0. In that run, training decreased from 4.76 s to 2.42 s (1.96×). A separate 600-iteration preflop solve decreased from 18.82 s to 8.99 s (2.09×), with identical queried policy and the same 60,000-state cap. These are local runtime measurements, not a universal latency guarantee or stronger-strategy claim. Frozen reference files are test-only and are not shipped in the website or standalone HTML.

Paid exploration is re-enabled in postflop practice. The old evaluator required a 6×6 bucket value table; v0.22 paused it because that cost calculation had not been ported. The new evaluator integrates exact combinations and prices a shared small probe using 160 paired continuation samples from the public compatible joint range. It estimates the average loss relative to the current played policy, adds two Monte Carlo standard errors, clips negative cost to zero, and limits mixture weight by the remaining budget. This is an uncertainty adjustment, not a calibrated upper confidence guarantee.

The objective is one-response information about local fold-odds alternatives around the current response policy. Candidate probes exclude all-ins and cost at most one pot or 10% of the remaining stack. The selected mixture is capped at 5%, scaled by the expected remaining hands, and charged against 0.02 BB per decision, 0.05 BB per hand and the saved 0.25 BB total budget. These are **estimated public-range-average EV costs**, not limits on realized losses or each individual holding's EV. This cost scope differs from the old own-bucket calculation. The old requirement that the unmixed action be within 0.05 BB of the best bucket value is replaced by the uncertainty-adjusted cost of the actual small mixture. The UI reports the cost mean, error, sample count, mixture, charge and fallback usage.

Probe choice and pricing never use the bot's dealt hand. The same mixture rule is applied to every root combination, preserving a coherent public action likelihood. Action evidence and retained range updates use that played mixture. Immediate response predictions condition only on the bot's own cards; public probe selection averages both ranges. Frozen predictions, hypothesis observations, budgets and player IDs survive save/restore. General opponent learning remains the continuous model; the three local fold-odds hypotheses are not full player-style categories. Information gain is a frozen-kernel one-response proxy, not proven long-run value of information.

Checks: exact numeric optimizer parity, evaluator regression, continuation-route accounting, full app play/save/import/reload, all-in equity and fees, probe budget/cancellation/privacy checks, played-policy range conditioning and prediction persistence. `npm run test:exact-speed` runs the frozen comparison; `npm run test:exact-exploration` tests the new probe path.

## Individual hands and continuous behavior (v0.22)

The default heads-up live/replay/practice path now dispatches to `dist/exact-cfr.js`, an external-sampling CFR implementation. Each information set identifies the acting player, exact two-card combination, exact public board and full within-solve action history. Both players train against compatible public ranges; selecting another actual Hero hand does not change the public training run. Terminal all-in responses retain v0.21's individual-hand equity calculation.

Private deals are sampled in shuffled cycles over the first player's compatible combinations, with conditional opponent sampling and importance weights restoring the public joint prior. Chance cards are sampled without replacement. At each updating-player decision all retained actions are evaluated; other-player actions are sampled. Regrets and average strategies are separate. The implementation follows the external-sampling method described by [Lanctot et al., 2009](https://papers.nips.cc/paper_files/paper/2009/hash/00411460f7c92d2124a67ea0f4cb5f85-Abstract.html); it is not a full Hold'em equilibrium solver.

Every root menu action is retained. Future menus restrict sizes and permit at most two new preflop wagers and one per postflop street, counting the root wager. Check, call and fold remain available when legal. There is no private-hand or public-texture bucketing in this path. The six-bucket code remains only as a historical reference; `solveBucketCfr` names it explicitly.

The UI reports exact information-set count, actual-hand regret/average visits, probability mass of visited root holdings, rollout baseline-use rate and the 60,000-state memory cap. Unvisited nodes use the continuous baseline; after the cap, new nodes are transient and their updates are not retained. Root nodes are reserved first. Default training iterations are 600 preflop, 1,200 flop, 2,400 turn, 4,000 river, with a user override of 150/600/2,000/8,000. Sparse coverage is a material limitation, especially preflop: individual-card resolution does not imply a stronger or converged policy. No abstract gap is repurposed as a full-game guarantee.

To avoid a single sampled outcome producing an extreme played strategy, the played policy shrinks the raw CFR average toward its learned baseline with 16 pseudo-visits: trained weight = visits / (visits + 16). Raw regret and average accumulators remain separate. This is an explicit finite-budget stabilization, not a Nash guarantee. The played weight is displayed. Action EVs use 600 continuation rollouts per root action under that same played mixture and its unvisited-state baseline. They report Monte Carlo error, zero-versus-paid terminal routes, immediate and total further investment, exact-combination action-conditioned ranges, and the first three sampled continuation events. The UI shows the top eight children per node; exports retain all sampled children. A check has zero immediate cost but may lead to later calls. Fees, refunds and payouts remain in integer cents internally and BB in the results. MC intervals exclude opponent-model error and training uncertainty.

Opponent inference now uses a single probability per exact combination and continuous contextual coefficients, rather than a mixture of neutral/tight/loose/aggressive styles. Each context has four action-group intercepts and 14 feature coefficients per group (60 total), including hand strength, draws, board texture, price, stack pressure, range and sizing. A diagonal Gaussian approximation tracks coefficient means and precision. Four fixed antithetic parameter draws approximate the predictive distribution; these are integration samples, not player styles. Posterior-weighted marginal-likelihood gradients update means, expected diagonal curvature updates precision, and old evidence decays toward the prior with an eight-opportunity half-life. This is approximate online inference, not calibrated Bayesian confidence; coefficient correlations are omitted.

Observations update the action model and exact-combination range immediately. Public board and shown cards eliminate impossible combinations and renormalize. Shown hands are not used to retrospectively refit previous action coefficients in this release. Per-opponent images, player IDs, compact memory and action-policy evidence persist. Old categorical weights are accepted for save compatibility but ignored by active inference; old response means are preserved and missing precisions start at 4 (SD 0.5). Legacy bot-style labels identify separate saved-memory slots only.

Learned ranges initialize CFR; learned response coefficients supply initial/unvisited policies. CFR still updates both players rather than optimizing a fixed-opponent best response. Retained continuations require at least four average-strategy visits for the actual hand; unsupported or sparse continuations start a fresh solve. Reloaded sessions also solve anew. Exploration spending is explicitly paused: the old six-bucket EV-cost estimator has not been ported, while ordinary learning and saved exploration budgets remain intact.

Validation: `npm test` runs current-path tests for exact hand/board separation, a known river decision, hidden-card and future-replay isolation, production solver dispatch, route accounting, blockers, cancellation, predictive gradients, strategy reversal, uncertainty persistence, live chip conservation, player IDs, and full app play/import/export/reload. `npm run test:bucket-reference` retains the earlier optimizer comparison. Historical street-specific bucket tests below describe earlier releases and are not evidence about v0.22 playing strength.

## Faster exact CFR traversal (v0.19.2)

The trainer now propagates six counterfactual utilities per player instead of 36 raw joint-deal values through each internal betting node. Static chance probabilities and joint range mass are compiled into terminal payoff matrices once. Each terminal then multiplies these matrices by the opponent's reach vector. Pure chance continuations with no remaining decisions (notably all-in runouts) are integrated during compilation. Typed scratch arrays are reused instead of allocating values, policies and chance-reach arrays at every node on every iteration.

A subtree is skipped only if both players' counterfactual reach vectors are entirely zero; merely having zero joint realized reach is insufficient. This preserves regret updates for unilateral deviations. The original game tree remains available for exact best-response measurement, exploration, exports and retained-plan range updates. Compilation uses a WeakMap and is released after a completed solve. Progress renders are throttled to about 40 ms while cancellation is checked every iteration.

With B private buckets, E traversed edges, L compiled terminal matrices and I iterations, the main training work changes from roughly O(I E B²) to O(N B² + I(E B + L B²)), where N is the original tree size. Internal messages therefore lose a factor of B, and chance-only suffixes leave the repeated traversal; dense terminal matrix-vector work remains quadratic in B. This is not a claim that worst-case full-game CFR becomes linear in bucket count. The same samples, runouts, 400 preflop iterations and action abstraction are retained.

`npm run test:cfr-speed` compares with the v0.19 reference traversal. It checks cumulative regrets and average weights across all nodes within floating-point accumulation tolerance, root action probabilities within 1e-8, the best-response gap within 1e-8, and later-street/chunked training equivalence. Separate complete-hand tests cover retained continuations and no-flop-no-drop. The 400-iteration preflop benchmark measured 20.691 seconds for the reference and 7.711 seconds for the compiled traversal (2.68×), including compilation in the latter. Root frequencies differed by at most 8.67e-9 and the gap by 6.24e-10 BB. Timings are environment-dependent; this is a computation improvement, not a change to the game's approximation or a playing-strength claim.

## Coupled preflop → showdown CFR (v0.19)

The adaptive heads-up practice bot now solves preflop decisions jointly with all later streets. The preflop game uses 2,048 compatible public hand pairs, 32 uniform ordered five-card runouts per pair and 400 CFR iterations. Both blind positions are supported. Root actions include the full existing legal menu, including the effective all-in. Up to two new preflop wagers from the current solve root permit an opening raise and a re-raise; postflop allows one new wager per street. Later preflop sizes are nearest 3× the level (2.5 BB when unopened), and later postflop sizes nearest 75% pot, each with maximum as another choice. Unsupported actions trigger a fresh solve.

Preflop private hands use six unequal heuristic strength buckets, with weighted-quantile boundaries 35%, 65%, 85%, 95%, 98.5% to preserve more distinctions among strong starting hands. The same type persists through showdown; different exact hand improvements inside a bucket remain indistinguishable. Four flop classes are paired, suited, high-rainbow (Q/K/A), and low-rainbow, in priority order. Turn and river each have paired-or-suited and other classes. Chance distributions condition on private bucket pairs and prior public classes. Showdown payoffs use exact evaluation of each sampled runout. This is an intentionally coarse finite game, not full Hold'em equilibrium.

Supported actions and flop/turn/river reveals retain the preflop plan and use its policy-conditioned joint ranges. Diagnostics label Preflop → river CFR and show the card and raise abstractions. Preflop exploration remains disabled; the existing bounded exploration may adjust retained postflop nodes. Zero-support private buckets retain the rollout fallback. Fresh flop/turn/river solves keep their earlier, finer abstractions. Preflop fold terminals now explicitly apply no-flop-no-drop to rake and extra deductions. Replay Top 5 remains rollout-based.

The default-fee 100 BB AJs button fixture decreases the restricted-game best-response gap from 13.9775 to 0.2472 BB in 400 iterations. Its all-in weight is 0.244%, with most mass on calls and 2–4 BB raises. This is a deterministic sampled-game diagnostic, not a win-rate or full-game exploitability estimate. Solving took about 22 seconds here; progress updates and cancellation remain active between iterations. Tests cover legal root sizes, preflop re-raises, all three chance transitions, normalized conditional probabilities, hidden-card isolation, no-flop-no-drop, actual blind defense and a complete hand retaining the same solve. Functional UI waits accommodate the longer solve.

## Budgeted opponent exploration (v0.18)

Practice now carries three explicit response hypotheses per public street/price context: continues more, CFR-like, and folds more. Fold odds are tilted by exp(-1.2), 1, exp(1.2) around the frozen CFR opponent policy after a 1% uniform lapse. Likelihoods integrate opponent buckets conditional on the bot's own bucket and current joint range. Each supported immediate response updates hypothesis weights by Bayes' rule, then mixes 2% uniform prior to permit strategy change. Pre-update log loss is compared with the CFR-like model. These are approximate, uncalibrated model probabilities; card and hypothesis distributions are factorized anew at each prediction. Unsupported response sizes are skipped and counted. Only supported postflop responses with a fold option are scored; this is not full-history hypothesis fitting.

Exploration computes each root action's exact average-policy continuation value within the existing sampled abstract game. A probe must be within 0.05 BB of the best conditional action, add more than 0.001 nats of one-response information relative to the current action mixture, and beat its opportunity cost using a heuristic exchange rate of 1 BB per nat. It must not be all-in, and its wager must fit both one pot and 10% of the current stack. At most 5% mixture weight moves toward the selected probe, linearly reduced for expected future hands below 20 and disabled at zero. Preflop remains unchanged.

The charge is mixture weight times (best conditional action value minus probe value): a conservative upper bound on expected EV lost relative to the original mixture under the frozen continuation model. Limits are 0.02 BB per decision, 0.05 BB per hand, and 0.25 BB total per player/style with no automatic refill. The budget measures estimated EV, not realized chip losses. Zero-cost informative probes are allowed. Every own bucket receives a corresponding policy adjustment, and joint range conditioning reads the exact adjusted policy used to act. A copied node preserves transaction cancellation safety. Opponent continuation policies remain frozen; this is not a new equilibrium solve after the adjustment.

Player-ID profiles, project/compact exports and practice saves preserve hypothesis summaries, wallet and pending response predictions. Old saves get the uniform prior and a fresh wallet. Hypothesis weights and predictive scores appear below action controls in Live model updates; hand-specific probe details unlock after completion. Users can disable exploration or set expected further hands to zero. The CFR diagnostic gap is recomputed for the current adjusted node and frozen continuation. The separate learned response model continues its earlier updates.

Tests exercise zero/positive information gain, posterior evidence and reversal, public range conditioning under the adjusted policy, tree immutability, budget/wager/all-in limits, disabled/zero-horizon behavior, unsupported response skipping, save/resume, player isolation and a real practice response update. This is experimental information-directed exploration, not reward-trained RL or a validated Bayes-adaptive strategy. Information gain does not establish future profitability; predictive calibration and held-out match benchmarks remain outstanding.

## Coupled flop → turn → river CFR (v0.17)

Heads-up practice now begins the coupled solve on the flop. It samples 1,024 compatible range pairs and 32 ordered, collision-free turn/river runouts per pair, then trains 600 CFR iterations on the complete restricted three-street betting tree. Private types remain six heuristic flop-strength buckets. Each future public card uses four texture classes, in priority order: paired board rank, matching a suit already present at least twice, overcard, other. Turn chance probabilities condition on the private bucket pair; river chance probabilities additionally condition on the turn class. Payoffs average exact showdown evaluations of the sampled runouts. This is a coarse sampled abstraction: different exact holdings/boards inside a class share a policy, including hands that improve differently.

Supported actions and observed card classes retain the original plan across both streets, with policy-conditioned joint range updates. Unsupported actions or zero-support chance branches trigger a fresh solve; preflop and unsupported private buckets retain the rollout fallback. Fresh turn/river solves remain available. All root menu sizes remain possible, with one new wager per street and half-pot/pot/maximum sizes at later nodes. Therefore this does not solve every legal raise sequence. The UI reports flop CFR, runout counts, texture groups and continuation reuse; post-hand CFR exports include the new diagnostics. Plan persistence, memory and replay ranking retain their earlier behavior.

Tests cover a complete three-street hand using the same trained plan, conditional chance normalization, policy-conditioned joint ranges, hidden-card isolation, unsupported-size invalidation and chip conservation. The 512-pair deterministic fixture reduces the abstract best-response gap from 24.8368 to 0.1989 BB after 600 iterations. Existing turn/river and functional UI checks pass. Typical flop solving took roughly 11 seconds in this environment, with iteration progress shown and cancellation checked between batches.

Reconstructing the earlier Th Jd / 2h 4d 3h flop decision with the two earlier imported hands and neutral incoming inference gives about 0.0208% for the 95 BB shove, 46.82% for 5 BB and 32.65% for 3.3 BB; abstract gap 0.3721 BB. This reconstruction is not the original saved model state and is not proof of general playing strength. Preflop remains rollout-based, incoming observational range inference still uses its separate learned policy, and variable rake prevents a standard zero-sum CFR convergence claim.

## Coupled turn → river CFR (v0.16)

Heads-up practice now solves turn actions, river-card chances and river responses together. The turn game samples 2,048 compatible public range pairs, integrates all 44 legal river cards for each pair into texture groups, retains six heuristic turn-strength buckets per player, and trains CFR for 600 iterations. Future river decisions therefore contribute to the turn action values. This deliberately coarse abstraction does not distinguish every exact river holding.

The trained average-policy continuation stays in memory for the rest of the hand. Supported actions update its joint bucket distribution using that same policy, and the observed river selects its chance group. The bot then follows the retained continuation rather than independently optimizing that river decision. Unsupported sizes, unsupported actual-hand buckets or a reload require a fresh solve or the existing rollout fallback. The plan is not checkpointed. Separate observational memory still learns with the existing response model.

Turn-built games permit at most one new bet/raise per street; standalone river solves retain their two-wager restriction. Root actions use the existing discrete menu, later sizes use half-pot, pot and maximum. Diagnostics show the sampled game's best-response gap, whether the continuation was retained, and post-hand strategy export. Preflop/flop rollouts and replay Top 5 are unchanged. This is neither safe full-game subgame solving nor a full Hold'em Nash equilibrium, and does not by itself resolve preflop/flop over-shoving.

`turn-cfr-tests.mjs` checks chance normalization, policy-conditioned joint range updates, retained continuation reuse during a complete hand, unsupported-action invalidation, hidden-card isolation and chip conservation. Its deterministic 512-pair fixture reduces the restricted-game gap from 23.1502 to 0.1304 BB after 600 iterations. This is a software/model diagnostic, not a win-rate benchmark.

## Rollout sizing correction (v0.15)

Reproduced a 99 BB shove into a 2 BB pot with As Kd on Ah 7d 2s, from 100 rollouts. The previous action selector assigned it 61.67% probability. It discounted only one Monte Carlo standard error and used the fourth root of the baseline prior, substantially flattening rare sizing preferences.

For bets/raises, the selector now uses `score = EV - 2 * hypot(SE, immediate action cost / sample count)` (both monetary quantities in dollars). Fold/call/check retain `EV - SE`. Within the bet/raise category, the full conditional sizing prior replaces its flattened fourth root; the total pre-score category weight is preserved. Final weights are multiplied by `exp(score / 0.2BB)`. The extra term is a one-loss exposure floor for sparse expensive actions, not a calibrated confidence interval. This regularizes selection rather than changing raw reported EVs, legal action menus or learned response parameters. It cannot repair misspecified opponent behavior, and the river CFR path is unchanged. Clearly superior all-ins remain selectable. The UI labels the uncertainty adjustment; no claim of GTO or improved win rate follows from this correction.

`sizing-tests.mjs` reproduces the real rollout fixture and checks reduced shove probability, a zero-variance missed-loss case, precision scaling, normalization, and a clearly profitable all-in. Existing adaptation tests retain the favorable short-call and live learning checks.

## Hold’em river CFR (v0.14)

The adaptive practice bot now uses CFR for every supported heads-up river decision. Earlier streets retain EV rollouts. CFR uses both public learned hand ranges (without conditioning the public training game on the bot’s actual holding), samples 4,096 compatible joint pairs, groups each range into six weighted showdown-strength buckets, and trains simultaneous vanilla CFR for 2,000 iterations. The bot samples its action from its bucket’s reach-weighted average root strategy. Unsupported actual-hand buckets fall back to EV rollouts.

The root includes every legal action in the existing discrete menu. Future bet sizes are nearest half-pot, pot and maximum; at most two new aggressive actions are allowed per solve. The real table still permits all legal responses and re-solves after an out-of-abstraction action. This is not safe subgame solving with an equilibrium blueprint. Rake and odd-chip splitting enter payoffs. Because variable rake is not zero-sum, no standard convergence guarantee is claimed.

Exact unilateral best responses within the sampled abstract game produce the displayed gap in BB; it is neither a confidence interval nor a full-Hold’em exploitability bound. Learned response coefficients affect the incoming range inference, but are not directly exploited in the CFR strategy objective. All styles use this river solver. Last-decision diagnostics appear in practice; hand-specific frequencies and JSON export unlock only after hand completion. Diagnostic reports are ephemeral and are recomputed on future decisions, not saved as training state. Replay Top 5 remains the existing rollout model and is not a CFR ranking.

Tests cover chip conservation, no clairvoyant best response, normalized legal policy, hidden-card isolation, independence of the public training game from the bot’s actual cards, cancellation and actual bot use. A deterministic 2,048-pair fixture reduced its gap from 26.5697 BB to 0.04416 BB after 2,000 iterations; this is a model diagnostic, not a playing-strength claim.

## Equilibrium lab (v0.13)

Open **Equilibrium lab** in the header. The isolated Kuhn poker trainer uses full-tree simultaneous vanilla CFR, two players, a three-card deck, ante 1 and fixed bet 1 without rake. Train in 1,000 or 10,000 iteration batches, pause/continue, reset, and export the measured average strategy and convergence history. Training remains in tab memory; exports are inspection reports, not resumable checkpoints. Hold’em practice and opponent memories are unchanged.

Every metric is an exact enumeration of six deals and each player's 64 deterministic information-set policies. NashConv sums unilateral best-response improvements; exploitability is half that sum. The displayed target is total gap ≤ 0.01 chip/hand, not a claim that finite training has solved the game exactly. At 10,000 iterations the deterministic implementation gives NashConv 0.0046355726 and P1 value -0.0555463958. A known analytic equilibrium evaluates to -1/18 and zero deviation gap. Tests also cover normalized strategies, chunk-invariant training, UI controls, cancellation races and export. No equilibrium or playing-strength claim carries over to Hold’em.

## Conditional response learning (v0.12)

The shared practice/replay/rollout policy now uses `softmax(log baseline + context intercept + weights · features)`, followed by the existing 0.1% uniform lapse. Each context has four intercepts and four vectors of 14 features: heuristic hand strength, draw indicator, paired/suited/connected board texture, effective call price, stack pressure, strength relative to the perceived opposing range, perceived aggression, four interactions, and candidate bet size. Features are bounded and scaled; strength is a heuristic, not computed equity. All bet sizes share a category but their size feature can now learn a different slope.

The observed action's marginal likelihood integrates the incoming joint hand/style distribution. Its exact gradient (including the lapse) weights per-holding contributions by the posterior. Both intercepts and feature weights use `clip(decay * weight + 0.4 * gradient, -4, 4)` with an eight-comparable-opportunity half-life. Ranges update immediately; hypothetical rollouts never fit weights. This is Euclidean online predictive-loss learning, not a manifold model, equilibrium solver, or reward-trained strategy. Identifying hidden-hand behavior from unlabeled actions remains ambiguous and depends on the range model.

Player-ID memory, checkpoints and exports carry feature weights. Old checkpoints without feature weights are valid and start the new coefficients at zero. The response inspector shows the largest learned feature coefficients alongside EMA rates. The older colored range grid remains separate from the Learning & image posterior.

Validation: `feature-tests.mjs` finite-differences the marginal feature gradients including bet size, checks hand-specific transfer, old-memory acceptance and malformed-weight rejection. Existing adaptation, recency, profile and UI tests cover real bot response changes, hidden-card isolation, strategy reversals and exact resume. These are software/model diagnostics, not evidence of GTO strength.

## Player identities (v0.11)

Practice now has named player profiles with generated stable IDs. A display name is only a label: two profiles named Solus have different IDs and separate learned memories. Select the existing player when starting another 100 BB match to reuse their compact memory. **Create player** starts fresh. **Forget this player's bot memory** clears that profile's learned summaries while retaining the ID; **New match · keep player memory** rebuys without erasing learning. This supersedes v0.10's practice-match reset behavior. New manual live tables remain fresh as before.

Memory is indexed by player ID and bot style; each style remembers only its own encounters with that ID. Completed hands update that compact profile summary once, and EMA still discounts older observations within each context. Full exports include the profile registry. Compact exports include only the current practice player's profile and current hand. Existing pre-ID practice saves acquire an ID while preserving their model values. Import does not merge players by name. Enable **Save on this device** or export a project/session to retain IDs and memory between visits; no accounts or automatic cross-device/cloud synchronization are introduced.

`player-profile-tests.mjs` checks name collisions, same-ID continuation across matches, player/style isolation, idempotent completion, compact restoration, old-save migration and explicit forgetting.

## Recency and history-free sessions (v0.10)

New installations open an empty live table setup. The example history is opt-in; importing files is optional. New live tables and new practice matches start with fresh priors, even when older hands are present in the workspace. Next hand retains stacks, rotates the button, and carries only a compact memory checkpoint. Imported names remain selectable when available, but a new live table does not inherit their earlier inference data. Existing saved device sessions still resume normally.

For each comparable action context, recent counts update as `C ← λC + one_hot(action)` and `W ← λW + 1`, where `λ = 2^(−1/8)`. The displayed recent frequency is `C/W`. Thus an observation loses half its weight after eight more opportunities in that context, rather than after eight unrelated moves or a wall-clock delay. Response logits update as `θ ← λθ + 0.4 ∇ log P(observed action)`, bounded to ±4. This replaces the shrinking learning rate and persistent coefficients of v0.9. It is discounted online gradient fitting, not an exact optimizer of a batch EMA objective. Between hands, style posteriors mix back toward their baseline with the same eight-hand half-life. No GTO or guaranteed adaptation speed is claimed; sparse contexts still need evidence.

Live/practice hand records carry a validated `memoryStart` checkpoint containing type probabilities, response parameters, counts and losses. Learning processes the current hand's public events on top of that checkpoint; Next hand summarizes the just-completed hand once. It does not replay the full session. Historical records remain optional for replay/audit. **Export compact session** saves one current hand plus its memory (and a resumable private practice deal where applicable). Importing that file restores the same model with no previous hand records. Old v3 saves without checkpoints migrate once from their available histories. Full project export remains available.

`recency-tests.mjs` verifies exponential decay, reversal after a long prior pattern, isolation between contexts, fresh-match resets and live/practice continuation after removing all earlier hand records. The controlled reversal test moves a fixed weak holding's modeled bet probability from about 48% after 60 bets to 6% after eight checks. This is a model diagnostic, not a measured win-rate improvement. The earlier 80%-call example documented for v0.9 is not a v0.10 benchmark.

## Online response fitting and adaptive play (v0.9)

The practice bot now fits player-specific action-response parameters **after each public action**, before choosing its response. The four hand/style hypotheses remain the baseline, augmented with contextual logits for fold, check, call and bet/raise. Contexts distinguish preflop position/open/re-raise and postflop street/call-size class. Training uses the gradient of the observed action's marginal log likelihood, integrating over the current hidden-hand/style posterior. Gradients include the lapse component; a small ridge penalty, decaying step size and bounded logits limit drift. This is online predictive fitting with a filtered latent state, not reward training or an equilibrium solve. Hidden Hero cards and future deal cards are not training labels. Parameters are rebuilt from saved observations, with no duplicate updates on resume.

At each bot turn, **the updated model feeds a full-hand rollout comparison** of legal actions (100 samples per action). The bot selects from a softmax of `EV − one Monte Carlo standard error`, at temperature 0.2 BB, multiplied by the fourth root of its baseline action probability. This is an explicit, approximate regularized policy-improvement rule. It uses only the bot's holding, public actions/board and its inferred opponent range. Responses are recalculated after the next real action; model coefficients stay fixed within a hypothetical rollout while card ranges continue updating. Future play uses the fitted continuation policy, rather than recursively solving every future decision. There is no exploitability guarantee, and model error and small-sample errors remain. A decision can take a few seconds. Cancelling a pending decision leaves the previously committed session intact.

The live table exposes observation counts and fitted contextual bet multipliers. Replay and Top 5 EV use the same learned response likelihoods. The old colored starting-range grid still belongs to the legacy model; use Learning & image to inspect current posteriors. The historical sections below describe the earlier versions where relevant; the fixed-policy limitation of v0.8/v0.8.1 is superseded by this response-fitting and root-action improvement layer.

Fixed short-stack pricing: the call amount is capped by the caller's remaining stack, and the opponent's unmatched excess is excluded from the heads-up contestable pot. A regression recreates a 12-cent remaining stack facing a nominal $2.50 raise, verifies identical baseline call likelihood to the equivalent effective wager, and checks the adaptive bot calls a positive-EV synthetic draw. The original folded holding is unknown; the regression does not claim to reconstruct it.

`node adaptation-tests.mjs` checks the likelihood gradient by finite differences, response changes after repeated bets, effective call accounting, hidden-card/deck isolation, adaptive play and exact coefficient restoration. UI checks also exercise asynchronous play and persisted session import/export. Uploaded user histories are not bundled in the Site.

## Live learning and blind defense (v0.8.1)

The practice table now shows how many of your current-hand actions and earlier shared hands/actions the bot has observed. Its public belief about your range changes after every action and publicly shown cards condition that belief at showdown. Earlier observations supply the next hand's prior. Saves rebuild the same beliefs and counters without counting the current hand twice. This is live Bayesian inference inside a fixed strategy family; the bot does not optimize its strategy coefficients from rewards.

Corrected an overly tight continuation rule for the heads-up big blind facing the first preflop raise. The shared policy now distinguishes the cheap call price from large bets and stack commitment. In a fresh 100 BB test with Hero holding 7c 2d, enumerating every legal BB combination against the inferred opening range gives neutral fold frequencies of 30.5% versus a 2 BB open (previously 72.5%), 40.5% versus 3 BB (previously 80.4%), and 96.8% versus a 100 BB shove. These are diagnostics of a heuristic policy, **not GTO targets or measured population frequencies**. The rule applies to two-player tables only; six-player inference, re-raises and postflop thresholds are unchanged. Inference and tree continuations use the same corrected policy as the practice bot.

## Learning tree and practice bot (v0.8)

Keep using the HTML workspace and choose **Play a bot** for the new heads-up practice table. Each match starts at 100 BB, $0.05/$0.10, with a neutral, tight, loose/passive or aggressive heuristic opponent. Actions, dealing, legal raises, refunds, showdown and payouts are automatic. Next hand carries exact stacks, rotates blinds and retains observer memory. Starting a new match rebuys without erasing completed observations. Bot profiles are separate from imported players. The client-side bot is for practice, not secure competitive play; its hidden deal is included in project saves so unfinished hands can resume.

**Learning tree** is the new default analysis engine for two active players, preflop through river. The earlier models remain explicitly selectable for six-player preflop or comparisons. Replay and live entry both expose Top 5 EV actions. Each legal candidate receives full-hand rollouts, including bets after checks and all later betting rounds. Root ranges contain exact combinations crossed with four latent policy styles. Future beliefs use 32 systematically resampled particles per player; if a public card eliminates their entire support, the engine reconstructs support from the full root distribution and observed rollout line. Each action export reports the recovery count. Future boards are integrated into displayed tree nodes; the first three subsequent decisions are expandable and later decisions are still simulated.

The shared `actionPolicy` returns one normalized distribution across fold/check/call and legal discrete sizes for each holding. Inference, the practice bot and tree continuation all call this policy. A hand-strength heuristic, price, stack commitment, public opposing range summary, position and inferred aggression determine the distribution. Heads-up range summaries remove the actor's own-card blockers analytically. This is a deliberately limited policy family, **not an equity-based best response, population fit, range-balancing equilibrium or GTO solution**. Deep preflop shoves receive very little policy weight except with premium hands; they remain legal counterfactuals in EV comparisons.

For joint hand/style weights q(c,t), an action updates q'(c,t) ∝ q(c,t) × π(action | c,t,public information). Historical wager totals map to the nearest legal log-size bucket; the policy includes a 0.1% lapse component. Chance cards remove impossible combinations and shown cards condition the distribution only at the reveal event. Opponent type weights persist across completed hands; each hand mixes 2% of the initial [.55,.15,.15,.15] style prior back in. Learning uses the most recent 200 valid earlier completed hands plus the current visible prefix. It scores actions using pre-update negative log predictive probability, not winnings. The model cache is derived from immutable observations and can be rebuilt after importing a project.

**Learning & image** shows full combination distributions, four style weights, observation counts and predictive log loss. Every opponent has a separate modeled view of Hero, trained only on shared tables and public Hero actions/reveals. Their response likelihoods use that modeled view. This version does not separately identify a player's private beliefs from their responses: style, card distribution and image remain confounded. The filters factor players' ranges and use an averaged public strength summary in multiway historical inference; they do not maintain a full joint multi-player posterior. Folded-player card ranges are not sampled in heads-up continuations. A shown hand is selected evidence, and the decision to reveal is not itself fitted.

The play objective is Q^π(action) = E[terminal award − new investment | visible decision, forced root action, modeled continuation policy]. Earlier contributions are sunk. Root action comparisons do not recursively optimize future actions or solve regret minimization. The displayed Hero frequency is the assumed mixed policy, separate from the EV ranking; the public-range reach probability is the action likelihood used by an observer. A high-EV root deviation need not preserve that assumed distribution. The prototype therefore supports inspection and testing of a consistent policy, not automatic equilibrium balancing.

Terminal route probabilities sum to one. Rows report conditional pot awards, additional investment, net payoff and EV contribution in BB. Tree nodes show conditional and overall reach probabilities and conditional terminal EV. The ±1.96 standard-error margin describes Monte Carlo noise only; it excludes opponent-model error, approximate belief tracking and action abstraction. Rare all-in pots can make small-sample intervals unreliable. Increase rollouts and compare policies rather than interpreting tiny gaps as precise recommendations. Tree fees use an editable percentage/cap/extra estimate with no flop, no drop. Practice uses fixed 5%, $1 cap and no extra deduction. These are assumptions, not a verified room fee schedule.

**Export project** now writes v3, including observations, linked profiles, range priors, settings and a resumable practice deal. v1/v2 imports remain supported. Beliefs are rebuilt from saved observations, so no duplicate learning occurs on restore. **Save on this device** opts into local browser storage; export remains available when storage is blocked or full. Unchecking removes this device's saved copy. Data stays in the browser or exported files; there is no poker-client connection or real-money automation.

The new engine uses prior-range edits, fee inputs and rollout count. The older range grid still visualizes the previous scenario likelihoods; the learned posterior is in Learning & image. Legacy bet-frequency/bluff controls apply only to the earlier models and do not change the shared learning policy.

The following sections document the existing live-entry flow and earlier scenario engines, retained for comparison.

## Live actions

The interface uses a light palette with dark text and distinct suit colors. **+ Live hand** opens a visual table with a 52-card deck alongside it. Click a seat to edit its name and stack or choose an imported/session player from the history selector. Stacks display in **BB** in replay, live seats, and decision details; live starting stacks are entered in BB (100 BB = $10 at $0.05/$0.10). Displays round to two decimals, while hand ledgers, next-hand balances, and exports retain exact cents. Changing the setup big blind preserves cash balances and updates their BB equivalent. BB stack entries must resolve to whole cents. Blinds, wagers, pots, results, and EV amounts retain their labeled units. Choosing a profile preserves a stable memory link; its historical stack is not assumed to be the current stack. A profile cannot occupy two seats. Display names can differ from the linked imported name.

Select your seat and click two deck cards, then start the hand. When the next street is ready, select the board and click its new cards; confirm with **Add board cards**. At showdown, click a player's seat and pick the cards they actually showed. Used cards are unavailable, and clicking a selected card removes it. Text entry remains available. Minimum, half-pot, and pot buttons fill the wager amount; they do not submit an action.

**Next hand** advances the button and blinds among players with chips, carries their closing stacks and profile links, clears hole/board cards, and increments the session hand number. On reaching heads-up, the big blind advances from the previous big blind before assigning the button/small blind. This is a moving-button convention for funded seats, not a room-specific dead-button implementation. The hand is posted after selecting new Hero cards and confirming setup. Completed hands add to the same linked player-memory records. Revisiting Next hand resumes an existing successor; an earlier hand with successors cannot be undone, preventing stale carried stacks. **+ Live hand** starts a fresh table.

Select **+ Live hand** to set up 2–6 players, starting stacks, blinds, button, your seat and your cards. Seats run clockwise. Blinds are posted automatically. Enter fold, check, call, bet/raise-to, or all-in for the indicated player, then add flop/turn/river cards as each round closes. The amount field is the player's **total on that street**, not the added chips. The app checks turn order, minimum raises, short-all-in reopening, stack limits, and card uniqueness. Manual mode uses a single board, without antes or straddles.

**Undo last entry** removes the last action, board, or settlement and its automatic refunds. Historical replay is available without changing the live hand. **Back to live actions** returns to the latest state. Current Hero decisions use the same editable ranges and EV models as imported hands: up to six active players preflop, and heads-up postflop. Live preflop controls include BB open sizes and multiples of the current raise.

At the end, select the actual winners of each main/side pot (multiple selections split it equally), or enter all eligible players' shown cards and determine winners automatically. Optional shown cards become memory evidence only after their show event. Enter the actual total deductions: these are charged to the main pot first, then side pots. Odd cents go clockwise from the button. This deduction-allocation convention may differ from a room's side-pot rake convention. Finished live hands reconcile to exported text; unfinished hands are excluded from final results and player-memory statistics. **Next hand** carries remaining stacks and advances the button among funded seats; if the prior Hero has no chips, choose the correct new Hero seat before starting.

**Export project** saves unfinished live hands, action history, ranges, inputs and practice in version 3 JSON; versions 1 and 2 still import. A reload restores an opted-in device save, otherwise it starts the sample. There is no automatic poker-client recording or connection. Live entry is manual, and timestamps use UTC. Text exports include completed hands only; use the project export to resume a hand in progress. Matching player names link observations; the included sample remains in the session unless replaced by an import.

## Top 5 EV actions

At a Hero preflop decision with up to six active players, or a heads-up postflop decision, click **Compare top actions** in **Hand replay** or **Live actions**. The same panel is available in **Ranges & EV**. It ranks fold (when facing a bet), check/call, and minimum, one-third, half, three-quarter, pot, one-and-a-half-pot, custom, and effective-stack wagers. Raises use the pot after calling; all amounts are total street contributions. Sizes are rounded to cents, bounded by legal raise and stack limits, and deduplicated by matched investment. A covering wager can be larger than the opponent's remaining stack to satisfy the minimum raise; unmatched chips are returned. Fewer than five rows appear if fewer distinct actions are available.

Each row shows estimated net EV in dollars and big blinds, its gap from the best tested action, and expandable route probabilities, conditional net payoffs and EV contributions. Preflop rankings use every remaining opponent's edited range; postflop rankings use the single remaining opponent's range. Edit the custom size, sample count, ranges, fees and postflop policy assumptions in **Ranges & EV**, then recalculate. Each postflop result exposes fold/call/raise ranges, conditional calling equity, and Hero’s response to a further raise. Expand a branch to inspect its 20 highest-weight combinations, or export every combination with its reach weight, action frequency, joint probability, and conditional probability. A replay move, live action or changed assumption clears stale results. Inspecting an EV row does not enter a live action.

Preflop and legacy manual sizes share seeded deals. The range-conditioned postflop model uses common seeds while sampling each action’s distinct conditional ranges. The default preflop cash baseline changes responses with size, position, pot odds, stack commitment and an explicit tendency setting. Default postflop responses depend on each exact hand’s equity against an assumed size-conditioned Hero betting range. Fixed hand-bucket responses remain available only in explicitly selected legacy mode. Consequently, these are **best among tested sizes under the chosen assumptions**, not solved strategies or GTO recommendations. Both ranking and the original route calculator support multiway preflop. Postflop remains heads-up, without short-call or side-pot counterfactuals.

## Run locally

From this directory, run:

```sh
python3 -m http.server 3000 -d dist
```

Then open http://localhost:3000. Any static HTTP server can serve `dist/`. No API key or account is required for a local copy. The hosted Site is private by default.

## Use

1. Import one or more GG `.txt` files. A new import replaces the current session; duplicate hand IDs keep the first copy. Drag and drop also works. Files are parsed in browser memory and are not uploaded by the app.
2. Select a hand; it opens at the first Hero decision. The **Preflop** button and **Preflop decision** street selector return to the first preflop decision. Step through its actions. Arrow keys step when no input is focused. “Next decision” selects the next Hero decision.
3. In Ranges & EV, select a player and edit class weights with a percentage brush. Unknown players start with all legal holdings. Optional preflop action weighting uses the selected baseline and position; postflop likelihoods remain coarse. Existing edited or imported priors are preserved. No policy is fitted automatically from memory statistics.
4. At a preflop Hero decision, edit any remaining player's range, adjust response assumptions and compare all legal candidates. At a heads-up postflop decision, select the live opponent and calculate. On the turn, an optional visible-strength rule models future river betting and payments.
5. Player memory defaults to earlier hands only and shows frequencies with numerators and opportunity denominators.
6. Export a project `.json` to retain histories, priors, hero bet frequencies, and analysis inputs. Reimport it to resume. Raw `.txt` and session-results `.csv` exports are also available. A reload opens the sample; browser memory is not durable storage.

## Supported accounting

Variable occupancy, blinds, straddles, checks, calls, bets, raise-to amounts, all-ins, uncalled returns, shows, collections, gross pot, rake, jackpot and other named deductions. Recorded contributions use integer cents. Every imported hand is checked against its summary. Unsupported blocks and accounting warnings are displayed.

The supplied file imports as 42 hands with no reconciliation warnings. Recorded Hero net: **+$10.18**. Total table pot deductions: **$2.82**. These are observed results, not EV estimates.

## EV scope

Preflop supports 2–6 active players. It compares fold, limp/complete/call/check, legal 2–4 BB opens, 2.5–4 times the current raise for 3-bets/4-bets/later raises, minimum and pot-based sizes, custom size and effective-stack wagers. Every remaining opponent has its own editable range. Whole independent range proposals are rejected on any card collision, preserving the product-of-range-weights distribution conditioned on legal joint deals. Future recorded boards and showdowns never enter the estimate.

The default **General cash baseline** is an explicit, uncalibrated heuristic, not a GTO solution or measured NL10 population model. Before voluntary actions, unknown players have all unblocked combinations. Position and prior actions narrow that range using an assumed opening/response policy with a small likelihood floor. Each player keeps their own range and linked observations; population behavior and individual policies are not automatically fitted from a handful of hands.

The cash policy uses a documented hand-strength ordering (not equity), smooth continuation thresholds, wager size in BB, pot odds, fraction of the effective stack committed, player/aggressor positions, raise depth and estimated rake percentage. Neutral, tighter (+0.04 threshold) and looser (-0.04) are editable scenarios, not measured pool frequencies. Dollar stakes do not change behavior by themselves; rake and stacks matter. Fractional-cent sizing is rounded, so scaling dollar denominations can change chip-grid discretization slightly. No room's rake is inferred from its stake label.

The baseline gives each player still owed action a response in seat order. Players whose action is closed are not re-offered a turn after Hero calls; the big blind keeps its option after a limp. One further raise is modeled at a legal 3× in-position / 3.5× other size, capped by the raiser's stack. All remaining players, including Hero, then fold or call using only their own cards and visible betting information. There is no second raise in this bounded tree. Against a Hero shove, the size-conditioned fold/call policy is recomputed instead of recycling the small-bet response. Continuing hands then check down, with no later side-pot betting or postflop strategy. This remains a scenario comparison, not a full strategy optimizer.

**Manual bucket weights (legacy)** preserves the earlier behavior for explicit experiments: fixed response weights across sizes, Hero always folds to a further raise, and impossible raises become calls/checks. A visible warning identifies the known tendency of that model to overrate large shoves. Existing projects without a model setting migrate to the cash baseline while preserving their edited priors. Model and tendency choices are saved in project JSON.

A genuine GTO benchmark must come from a verified solution matching table size, stacks, action sizes and rake. No such solution or empirical NL10 dataset is bundled. See the solver provider's [description of configurable preflop inputs](https://blog.gtowizard.com/introducing-multiway-preflop-solving/). The prototype's formulas and coefficients are locally authored and are not extracted from that provider.

Preflop refunds unmatched chips and constructs main/side pots from committed cents. Hero can win only eligible pots. Short calls and different stack sizes are supported. Showdown ties use fractional expected shares; estimated deductions come from the main pot first. Preflop folds pay no estimated rake. Aggregate routes show everyone folding, a raise followed by Hero folding/calling, or a checkdown against each possible opponent count. Individual action probabilities and board outcomes are Monte Carlo estimates, so small ranking gaps may be noise.

### Range-conditioned postflop model (v0.7)

Postflop counterfactuals remain heads-up only. Past money is sunk at the selected node. Opponent reach weights are conditioned on the known Hero cards and public board. For a candidate action of size B and an opponent hand h:

- P(a | B) = Σ_h w(h) π(a | h, B), for a ∈ {fold, call, raise}.
- w(h | a, B) = w(h) π(a | h, B) / P(a | B), when the denominator is positive.
- EV(B) = Σ_routes P(route | B) E[net payoff | route, B].

Thus equity against the entire reaching range is not substituted for equity against the calling range. Each showdown branch samples from its own normalized range; ties receive their proper share. Fold branches and branch masses are computed directly. The displayed action-range inspector and downloadable JSON expose the same weights used by EV.

**Public betting range assumption.** Opponent policy inference uses a hypothetical Hero range inferred from earlier actions, never Hero’s actual cards. Automatic value weights select the top made-hand mass `clamp(0.5 / (1 + bet/pot), 0.025, 0.45)`; tied hands share the cutoff. Draws and weaker hands supply a bluff component. Its bluff:value ratio is `factor × bet/(pot + bet)`, bounded by available combinations. The editable factor defaults to 0.5; 0, 0.25 and 1 provide sensitivity scenarios. These coefficients are uncalibrated modeling choices, not solver output or measured population behavior. For a raise, sizing uses the increment above the call and the pot after calling. Alternatively, **Use my edited Hero betting mix** applies the 169-class frequency grid, with 50% for untouched classes. An empty mix is rejected.

**Combination-specific responses.** Each opponent hand’s equity is estimated against that public betting range using 128 seeded runouts on flop/turn; river equity is enumerated over the compatible opposing range. The calling threshold uses pot odds after estimated deductions and an optional tendency shift. A ±4 percentage-point linear band around the threshold supplies mixed continuation. Strong hands may raise; draws have a small modeled semi-bluff component. These are explicit policies, not optimal strategies. An all-in disables raising and recomputes the call/fold decision; it does not turn an old fixed raise bucket into guaranteed calls.

**One further raise.** Villain may raise to approximately three times Hero’s incremental investment, bounded by legal minimum and effective stacks. Hero estimates equity against the entire raising range (512 policy samples on flop/turn, exact on river) and folds or calls using the offered price. Hero never gets to inspect the sampled hidden hand or future runout. The engine accounts for the initial wager lost when folding and the additional investment when calling.

**Continuation limit.** After this betting round, both players check down. Checking/calling at the initial node also leads to showdown; checking out of position does not model a bet behind. There are no future-street bets, second re-raises, equilibrium balancing, or fitted equity-realization factors. The result is an assumed-policy scenario EV, not a solved strategy. The old optional turn-to-river rule belongs only to legacy manual mode, which retains fixed bucket responses and automatic Hero folding to a raise.

**Historical ranges.** In the new model, checks preserve strong hands instead of automatically stripping most of them out. Observed postflop bets/calls/raises use size-aware likelihoods. To bound inference cost, the public reference range for a past action uses earlier legacy likelihoods internally; there is no recursive game solve. Calls use 64 policy samples. Likelihoods have a 0.005 floor so this approximate policy does not declare observed hands impossible. No later board, revealed holding, or result enters the selected-node range or policy.

Counterfactual rake is an editable percentage/cap/extra-fee approximation, with no deduction on a preflop fold. The default 5%, $1 cap, $0 extra fee is an assumption, not a verified GG fee schedule. Recorded deductions are kept separate and parsed from the export.

Multiway postflop EV, postflop short calls and counterfactual side pots, insurance/cashout, multiple runouts, tournaments and non-GG formats are not modeled. This is not a GTO solver. Tiny EV differences can be simulation noise.

## Range and memory details

1,326 exact combinations underlie the 169-cell grid. Starting weights and observed-action likelihoods form unnormalized reach weights, then are normalized for equity sampling. Hero's counterfactual range excludes the board but is not blocked by Hero's actual cards. The Hero bet-frequency grid allocates reach weight into a betting line. Enable **Use my edited Hero betting mix** to make it the public range used by postflop opponent responses; otherwise the automatic sizing assumption applies.

Prior presets, action likelihoods and buckets are transparent prototype heuristics. Whole-session player frequencies are displayed as evidence and are not automatically converted into precise hand-conditional policies. Imported Hero identities are grouped by source file; other imported names are matched exactly as exported. Live seats can explicitly link to those profiles and retain their links and range weights across display-name changes and subsequent hands. Project export preserves these links; plain hand-history text does not carry profile metadata. Revealed showdowns are treated as selected evidence rather than an unbiased range sample.

## Verify

```sh
node tests.mjs
node live-tests.mjs
node visual-tests.mjs
node ranking-tests.mjs
node preflop-tests.mjs
node baseline-tests.mjs
node postflop-tests.mjs
node learning-tests.mjs
node learning-ui-tests.mjs
```

Checks cover the supplied ledgers, refunds and deductions; evaluation and blocker logic; range and route probabilities; future-information isolation; multiway guards; and import/export and UI handler flows. Baseline regressions also check size-dependent tightening, unacted full ranges, position/tendency effects, Hero calls, matching BB scaling, and the reported AJs/100-BB shove failure. Postflop regressions cover all three screenshot scenarios, exact branch normalization, conditional equities, blocker/public-information isolation, raising-range responses, protected checks, and known river payoffs. These checks do not establish equilibrium or empirical calibration. The UI adapter does not replace browser layout QA.

## Source map

- `dist/index.html`, `dist/style.css`: responsive working surface.
- `dist/app.js`: import/export, replay, range editor, memory and EV UI.
- `dist/poker.js`: parser, ledger, hand evaluator, ranges and simulation.
- `dist/live.js`, `dist/live-ui.js`: validated manual hand state and live-entry interface.
- `dist/policy.js`, `dist/learning.js`: normalized policy family, public Bayesian filters, observer images and predictive scoring.
- `dist/tree.js`: heads-up terminal rollouts, range updates, route probabilities and payoff accounting.
- `dist/practice.js`, `dist/learning-ui.js`: private practice deal, bot gameplay, tree and posterior views.
- `dist/sample.txt`: supplied GG sample.
- `tests.mjs`: validation.

Browser imports remain in memory unless device saving is enabled. No analytics or external data services are called. A Google Fonts stylesheet may be requested; system-font fallbacks are provided. Optional browser WebMCP tools expose read-only session inspection and validated replay navigation when the browser supports that API.

## v0.20.0 — CFR case analysis

The default Live hand and replay Top 5 panel now calls the practice bot's CFR
solver with the same fresh-solve budgets. Action EV, average-policy frequency,
public Hero range reach, outcome probabilities and continuation branches all
come from that single sampled game. All legal root actions remain visible,
including check when outside the top five. No heuristic fallback is substituted
for unsupported analysis cases. Earlier scenario models are explicitly separate.

Immediate cost is separated from total net additional investment. Terminal
outcomes split zero-investment paths from paid paths; returned uncalled chips
are excluded from net investment. Summed route contributions reproduce action EV.
These are exact aggregations of the sampled abstraction, not extra rollouts or
Monte Carlo confidence intervals.

Exact current-board blockers remove impossible combinations and renormalize
beliefs, including modeled public Hero images. Hero's private cards additionally
block their opponent-belief view; the public game instead samples compatible
pairs and conditions action values on Hero's six-way bucket. It does not reveal
Hero's exact cards to the opposing policy. Future boards in a solve remain grouped
by texture and private buckets remain fixed; the retained practice plan still
conditions on those groups, not exact future-card identity. Case analysis freshly
rebuilds from the exact board at the selected decision and ignores later replay
cards. This is a baseline fresh solve, not reproduction of a retained bot plan or
its exploration adjustment. Learned response coefficients inform observational
ranges but are not directly exploited by CFR.

Validation: `npm run test:cfr-analysis` checks probability/payoff identities,
zero-cost checking continuations, uncalled-bet refunds, exact board blocking,
range normalization, cancellation, and future-card isolation in replay.
`node learning-ui-tests.mjs` exercises the actual comparison UI and practice flow.

## v0.21.0 — wager-conditioned ranges and hand-specific all-in responses

New practice CFR actions record their full combination-to-action likelihoods
from the actual average policy (including any exploration adjustment). These
weights are applied once to observational ranges and preserved in project and
compact-session JSON. They contain no actual private holding. Existing `.txt`
histories do not carry this policy evidence.

Live/replay analysis facing an immediately preceding wager uses recorded
likelihoods when available. Otherwise it solves the opponent's pre-wager public
node, maps the observed wager to its legal menu, and replaces that wager's
heuristic likelihood with the inferred CFR likelihood. Nearest-size mappings
are labeled. Earlier unrecorded history retains heuristic observational updates;
this is not a reconstruction of the opponent's true strategy or of an old bot
plan. A range is never multiplied by both likelihoods for the same wager.

When calling ends all betting, analysis and practice responses evaluate the
actual two cards against the action-conditioned, blocker-filtered opponent
range. Turn and river enumerate legal remaining boards; preflop/flop sample
30,000 legal runouts. Call EV uses actual pot accounting, uncalled-chip refunds,
rake and odd-chip split rules. The panel shows a best response to that fixed
range, not a CFR frequency or certainty score. Sampling uncertainty is displayed
separately from the unquantified opponent-model uncertainty. Opponent actual
cards and future replay events are excluded.

Other decisions still use six fixed private-hand buckets and public texture
groups. This update does not implement dynamic exact-combination CFR, remove
all abstraction error, or establish full-game equilibrium.

Validation: `npm run test:all-in` covers Bayes weights, pot/fee/EV accounting,
exact river results, recorded versus inferred conditioning, hidden/future-card
isolation, cancellation, and actual practice save/restore of policy evidence.
