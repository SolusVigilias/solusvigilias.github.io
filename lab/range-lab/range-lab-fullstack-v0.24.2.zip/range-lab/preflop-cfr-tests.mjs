import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {newBelief} from './dist/learning.js';
import {buildRiverGame,trainRiver,measureRiver,advanceCfrPlan,cfrPlanDecision,solveRiverCfr} from './dist/river-cfr.js';
import {advancePracticeAdaptive,botDecisionInput} from './dist/practice.js';
import {RESPONSE_PRIOR} from './dist/adaptation.js';
import {legalActions,publicContext} from './dist/policy.js';
const h=createLiveHand({players:[{name:'Bot',stack:1000},{name:'Hero',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Js']}),rows=newBelief(),input={hand:h,step:h.events.length,beliefState:{filters:{Bot:rows,Hero:rows}},config:{rakePct:5,rakeCap:1,extraFee:0}},start=Date.now();
const game=buildRiverGame(input,{samples:2048,runouts:32}),initial=measureRiver(game);assert(game.preflop);assert(game.flopGroups===4);assert.deepEqual(game.root.actions.map(a=>a.id),legalActions(publicContext(h,h.events.length,h.hero)).map(a=>a.id));
// Folding before the flop must incur no rake or extra deduction.
const fold=game.root.children[game.root.actions.findIndex(a=>a.kind==='fold')];fold.values[0].forEach((v,k)=>assert(Math.abs(v+fold.values[1][k]-1.5)<1e-12));
let depths=new Set();function chance(node,reach=game.mass){if(node.chance){depths.add(node.boardLength);reach.forEach((m,k)=>{if(m>0)assert(Math.abs(node.probs.reduce((s,p)=>s+p[k],0)-1)<1e-10);});node.children.forEach((c,i)=>chance(c,reach.map((m,k)=>m*node.probs[i][k])));}else node.children?.forEach(c=>chance(c,reach));}chance(game.root);assert.deepEqual([...depths].sort(),[3,4,5]);
const firstRaise=game.root.actions.findIndex(a=>a.kind==='bet'&&!a.allIn);assert(game.root.children[firstRaise].actions.some(a=>a.kind==='bet'),'Opponent must be able to re-raise an opening bet.');
trainRiver(game,400);const d=measureRiver(game);assert(d.nashConv<initial.nashConv/5);assert(d.policy.find(a=>a.allIn).prob<.05,'Default-fee 100 BB AJs fixture must not revert to frequent open shoves.');assert(Math.abs(d.policy.reduce((s,a)=>s+a.prob,0)-1)<1e-12);
let plan={game,node:game.root,mass:game.mass,steps:0};for(const event of [{type:'action',actor:'Bot',action:'calls'},{type:'action',actor:'Hero',action:'checks'},{type:'street',board:['Qh','8d','4s']}])plan=advanceCfrPlan(plan,event);assert(plan);
for(const board of [['Qh','8d','4s'],['Qh','8d','4s','2c'],['Qh','8d','4s','2c','9h']]){if(board.length>3)plan=advanceCfrPlan(plan,{type:'street',board});plan=advanceCfrPlan(plan,{type:'action',actor:'Hero',action:'checks'});assert(cfrPlanDecision(plan)?.reused);plan=advanceCfrPlan(plan,{type:'action',actor:'Bot',action:'checks'});}assert(plan.node.values);assert.equal(game.iterations,400);
const other=structuredClone(input);other.hand.players[0].cards=['2c','2d'];assert.deepEqual(buildRiverGame(other,{samples:2048,runouts:32}).mass,game.mass,'Public training range must not depend on actual own cards.');assert.equal(await solveRiverCfr(input,{cancel:()=>true}),null);
console.log('PASS: preflop full-street tree, chance normalization, re-raises, no-flop-no-drop, normalized legal strategy, public range isolation and retained continuation.',{ms:Date.now()-start,nodes:game.nodeCount,initialGap:initial.nashConv,finalGap:d.nashConv,ajsPolicy:d.policy.map(a=>({action:a.label,p:a.prob}))});
// Actual bot faces a blind open, calls and checks through its retained plan.
let live=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['Ac','Ad']});live=appendLiveAction(live,{actor:'Hero',kind:'bet',to:25});
const p={hand:live,type:0,botCards:['As','Js'],deck:['Qh','8d','4s','2c','9h'],filters:{Hero:rows,Bot:rows},responses:{Hero:RESPONSE_PRIOR(),Bot:RESPONSE_PRIOR()},learning:{sharedHands:0},config:{rakePct:5,rakeCap:1,extraFee:0}};
const changed=structuredClone(p);changed.hand.players[0].cards=['7c','6c'];changed.deck.reverse();assert.deepEqual(botDecisionInput(p),botDecisionInput(changed));
const passive=()=>{const policy=p.lastDecision.policy;const index=policy.findIndex(a=>a.kind==='call'||a.kind==='check');return policy.slice(0,index).reduce((s,a)=>s+a.prob,0)+policy[index].prob/2;};
await advancePracticeAdaptive(p,null,passive);assert.equal(p.lastDecision.engine,'preflop-river-cfr');const trained=p.cfrPlan.game;assert(p.lastDecision.reused);for(let n=0;!p.hand.live.complete&&n<4;n++){await advancePracticeAdaptive(p,{kind:'check'},passive);assert.equal(p.cfrPlan.game,trained);}assert(p.hand.live.complete);assert.equal(p.exploration.observations,0);
console.log('PASS: actual blind defense uses preflop CFR, retains the same plan through showdown, excludes hidden cards and keeps preflop exploration off.');
