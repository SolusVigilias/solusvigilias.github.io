import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createLiveHand} from './dist/live.js';

// Exercise app events and persistence with a DOM adapter; this is not layout QA.
const handlers={},registered={},downloads=[],storage=new Map(),app={innerHTML:'',addEventListener:(t,f)=>handlers[t]=f};
globalThis.window={addEventListener(){}};
globalThis.document={getElementById:id=>id==='app'?app:{click(){},focus(){},setSelectionRange(){}},addEventListener(){},body:{classList:{add(){},remove(){}}},createElement:()=>({click(){}}),modelContext:{registerTool:t=>registered[t.name]=t}};
globalThis.fetch=async()=>({text:async()=>fs.readFileSync('dist/sample.txt','utf8')});
globalThis.URL.createObjectURL=blob=>{downloads.push(blob);return 'blob:test';};globalThis.URL.revokeObjectURL=()=>{};
globalThis.localStorage={getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
await import('./dist/app.js');
const click=(action,value,id)=>handlers.click({target:{closest:()=>({dataset:{action,value,id}})},preventDefault(){}}),change=(id,value,extra={})=>handlers.change({target:{id,value,classList:{contains:()=>false},...extra}}),session=()=>registered.read_imported_session.execute();
const wait=async predicate=>{for(let i=0;i<1000&&!predicate();i++)await new Promise(r=>setTimeout(r,20));assert(predicate(),'UI did not settle');};

await click('kuhn-open');assert(app.innerHTML.includes('Kuhn poker · CFR'));
await click('kuhn-train','1000');await wait(()=>app.innerHTML.includes('1,000 iterations'));
await click('kuhn-export');const result=JSON.parse(await downloads.at(-1).text());assert.equal(result.iterations,1000);assert(result.nashConv<.02);
await click('kuhn-reset');assert(app.innerHTML.includes('0 iterations'));
await click('kuhn-train','10000');await click('kuhn-stop');await click('kuhn-train','1000');await wait(()=>app.innerHTML.includes('1,000 iterations'));
await click('kuhn-export');assert.equal(JSON.parse(await downloads.at(-1).text()).iterations,1000);
await click('home');assert(!app.innerHTML.includes('<h1>Kuhn poker'));
console.log('PASS: equilibrium lab open, train, reset, pause/restart race, export and workspace return.');
