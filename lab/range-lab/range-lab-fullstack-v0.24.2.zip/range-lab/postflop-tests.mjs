import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {analyze,rangeAt,prior,DEFAULT_RESPONSE,postflopResponseRanges,postflopBetRange,postflopEquity,snapshot,actionCandidates,rankActionResults} from './dist/poker.js';
const config={preflopModel:'cash',postflopModel:'range',postflopBluffFactor:.5,populationTightness:0,rakePct:5,rakeCap:1,extraFee:0,futureMin:-1,futureBet:1,response:DEFAULT_RESPONSE};
const act=(h,kind,to)=>appendLiveAction(h,{kind,actor:h.live.actor,...(to===undefined?{}:{to})});
const fixtures=[{name:'Q4 turn',cards:'Qd 4d',stacks:[1780,2220],board:'7d 3s 2s',turn:'Qh',max:17.4},{name:'KQ flop',cards:'Kc Qc',stacks:[1895,2105],board:'4c 2c 9d',max:18.75},{name:'J8 flop',cards:'Js 8d',stacks:[1995,2005],board:'2c 4s Jh',max:19.75}];
function fixture(spec){
 let h=createLiveHand({players:spec.stacks.map((stack,i)=>({name:i?'Villain':'Hero',stack})),heroSeat:1,button:1,sb:5,bb:10,cards:spec.cards,id:'LIVEpost',date:'2026/09/28 07:12:00'});
 h=act(h,'bet',20);h=act(h,'call');h=appendLiveAction(h,{kind:'board',cards:spec.board});h=act(h,'check');
 if(spec.turn){h=act(h,'bet',20);h=act(h,'call');h=appendLiveAction(h,{kind:'board',cards:spec.turn});h=act(h,'check');}return h;
}
function invariant(result){
 for(const [line,routes] of Object.entries(result.routes)){assert(Math.abs(routes.reduce((n,r)=>n+r.p,0)-1)<1e-8);assert(Math.abs(routes.reduce((n,r)=>n+r.contribution,0)-result.ev[line])<1e-8);for(const r of routes){assert(Number.isFinite(r.payoff));assert(r.p>=0);assert(Math.abs(r.contribution-r.p*r.payoff)<1e-8);}}
 const info=result.responseRanges;assert(Math.abs(Object.values(info.mix).reduce((a,b)=>a+b,0)-1)<1e-8);
 for(const combo of info.combos)assert(Math.abs(combo.fold+combo.call+combo.raise-1)<1e-8);
 for(const [a,branch] of Object.entries(info.branches)){if(branch.probability)assert(Math.abs(branch.rows.reduce((n,p)=>n+p.prob,0)-1)<1e-8);assert(Math.abs(branch.rows.reduce((n,p)=>n+p.joint,0)-info.mix[a])<1e-8);for(const p of branch.rows)assert(Math.abs(p.prob*branch.probability-p.reach*p.frequency)<1e-9);}
 assert(Math.abs(result.routes.aggressive.filter(r=>r.name==='Villain folds now').reduce((n,r)=>n+r.p,0)-info.mix.fold)<1e-9);
}
for(const spec of fixtures){
 const h=fixture(spec),step=h.events.length,range=rangeAt(h,step,'Villain',prior('all'),true,false,config),heroRange=rangeAt(h,step,'Hero',prior('all'),true,true,config),results=[];
 for(const betTo of [.1,.4,spec.max]){const r=analyze({hand:h,step,range,heroRange,config:{...config,betTo},iterations:3000});invariant(r);results.push(r);}
 const [small,normal,shove]=results;assert(shove.mix.call<small.mix.call);assert(shove.calledEquity<small.calledEquity);assert.equal(shove.mix.raise,0);
 assert(shove.ev.aggressive<1,'The old multi-dollar shove advantage must disappear in these reported cases.');
 const blockers=new Set([...h.players[0].cards,...snapshot(h,step).board]);assert(shove.responseRanges.combos.every(p=>p.cards.every(c=>!blockers.has(c))));
 console.log(JSON.stringify({hand:spec.name,scenarios:results.map(r=>({bet:r.betTo,call:r.mix.call,fold:r.mix.fold,eqCalled:r.calledEquity,EV:r.ev.aggressive,heroCallRaise:r.heroCallRaise}))}));
 if(spec.name==='J8 flop')assert(small.ev.aggressive>shove.ev.aggressive,'Top pair must not inherit the old shove bonus.');
}
// Exact independent river payoffs, including a sensible call of a raise with the best hand.
let river=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Villain',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:'As Ah'});
river=act(river,'call');river=act(river,'check');for(const cards of ['2c 3d 7s','8c','9h']){river=appendLiveAction(river,{kind:'board',cards});river=act(river,'check');if(cards!=='9h')river=act(river,'check');}
const step=river.events.length,range={rows:[{cards:['Ks','Kd'],prob:1}]},heroRange={rows:[{cards:['Qs','Qd'],prob:1}]},zeroFees={...config,rakePct:0,rakeCap:0};
const small=analyze({hand:river,step,range,heroRange,config:{...zeroFees,betTo:.2},iterations:20});invariant(small);assert.equal(small.heroCallRaise,1);assert(small.mix.raise>0);assert(!small.routes.aggressive.some(r=>r.name==='Villain raises → Hero folds'));
const jam=analyze({hand:river,step,range,heroRange,config:{...zeroFees,betTo:9.9},iterations:20});invariant(jam);assert(Math.abs(jam.ev.aggressive-10.1)<1e-9);assert(Math.abs(jam.ev.passive-.2)<1e-9);
assert.equal(postflopEquity(['As','Ah'],snapshot(river,step).board,range.rows),1);
// Policy inference cannot read Hero's real cards, later boards, or later outcomes.
const altered=structuredClone(river);altered.heroNet=-999;altered.players[0].cards=['Ac','Ad'];
const other=analyze({hand:altered,step,range,heroRange,config:{...zeroFees,betTo:.2},iterations:20});assert.deepEqual(other.responseRanges,small.responseRanges);
const later=act(river,'bet',20);assert.deepEqual(analyze({hand:later,step,range,heroRange,config:{...zeroFees,betTo:.2},iterations:20}),small);
// Edited Hero mixes are used, including rejection of an empty action range.
const publicRange={rows:[{cards:['Qs','Qd'],prob:.5},{cards:['5s','6s'],prob:.5}]};
const mixed=postflopBetRange(publicRange,snapshot(river,step).board,1,.2,{postflopUseMix:true,heroMix:{QQ:100,'65s':0}});assert.equal(mixed.rows.length,1);assert.equal(mixed.rows[0].cls,'QQ');
assert.throws(()=>postflopBetRange(publicRange,snapshot(river,step).board,1,.2,{postflopUseMix:true,heroMix:{QQ:0,'65s':0}}),/empty/);
// A check preserves strong hands in the default historical model.
const checked=rangeAt(river,step,'Villain',prior('all'),true,false,config),beforeCheck=rangeAt(river,step-1,'Villain',prior('all'),true,false,config);
for(const p of checked.rows)assert(Math.abs(p.prob-beforeCheck.rows.find(x=>x.key===p.key).prob)<1e-10);
console.log('PASS: combination-level action ranges, Bayes normalization, size-sensitive calls, conditional equity, raise/call payoff accounting, checks retaining strong hands, blockers, private/future-card isolation, edited betting mixes, and all three reported hands.');
