import {DECK,evaluate} from './reference-poker.mjs';
import {publicContext,legalActions,actionPolicy,seeded} from './reference-policy.mjs';
import {conditionCards,comboMass,beliefSummary} from './reference-learning.mjs';
import {advanceState} from './reference-tree.mjs';

const copy=s=>({...s,board:[...s.board],players:s.players.map(p=>({...p})),acted:structuredClone(s.acted),pending:[...s.pending]});
export const exactHandKey=cards=>cards.slice().sort().join('');
export const exactInfoKey=(actor,cards,board,history)=>actor+'|'+exactHandKey(cards)+'|'+board.join(',')+'|'+history;
const sum=x=>x.reduce((s,v)=>s+v,0);
function normalized(x,fallback){const z=sum(x);return z>0?x.map(v=>v/z):[...fallback];}
function distribution(rows){const cumulative=[];let total=0;rows.forEach(r=>{total+=r.prob;cumulative.push(total);});return {rows,cumulative,total};}
function pickDistribution(d,random){const x=random()*d.total;let lo=0,hi=d.rows.length-1;while(lo<hi){const m=(lo+hi)>>1;if(d.cumulative[m]<x)lo=m+1;else hi=m;}return d.rows[lo];}
function sampler(rows){const d=distribution(rows);return random=>pickDistribution(d,random);}
export function exactMenu(ctx,wagers=0,root=false){
 let actions=legalActions(ctx);if(root)return actions;
 const limit=ctx.board.length?1:2;if(wagers>=limit)return actions.filter(a=>a.kind!=='bet');
 const bets=actions.filter(a=>a.kind==='bet'),p=ctx.players.find(p=>p.name===ctx.actor),call=Math.min(p.stack,Math.max(0,ctx.level-p.streetContribution));
 const targets=ctx.board.length?[p.streetContribution+call+.5*(ctx.pot+call),p.streetContribution+call+(ctx.pot+call)]:[3*ctx.level];
 const keep=new Set(targets.map(to=>[...bets].sort((a,b)=>Math.abs(a.to-to)-Math.abs(b.to-to))[0]?.id));if(bets.length){keep.add(bets[0].id);keep.add(bets.at(-1).id);}return actions.filter(a=>a.kind!=='bet'||keep.has(a.id));
}
export function buildExactGame(input){
 const h=input.hand,ctx=publicContext(h,input.step,h.hero);if(ctx.players.length!==2||ctx.players.some(p=>p.folded)||!ctx.actor)throw Error('Hand-specific CFR requires an active heads-up decision.');
 const names=[h.hero,ctx.players.find(p=>p.name!==h.hero).name],rows=names.map(n=>comboMass(conditionCards(input.beliefState.filters[n],ctx.board)));
 const own=h.players.find(p=>p.name===h.hero).cards;if(own.length!==2||new Set(own).size!==2||own.some(c=>ctx.board.includes(c)))throw Error('Enter two distinct legal Hero cards.');
 // Joint chance is proportional to the product of public ranges, excluding
 // overlapping cards. Sampling/training never conditions on the queried hand.
 const cardMass=rows[1].reduce((m,r)=>{r.cards.forEach(c=>m[c]=(m[c]||0)+r.prob);return m;},{}),byKey=new Map(rows[1].map(r=>[exactHandKey(r.cards),r.prob]));
 const compatible=rows[0].map(r=>Math.max(0,1-(cardMass[r.cards[0]]||0)-(cardMass[r.cards[1]]||0)+(byKey.get(exactHandKey(r.cards))||0)));
 const total=rows[0].reduce((s,r,i)=>s+r.prob*compatible[i],0);if(total<=1e-12)throw Error('The two ranges have no compatible joint deals.');
 const marginals=rows[0].map((r,i)=>r.prob*compatible[i]/total);
 const eligible=rows[0].map((_,i)=>i).filter(i=>compatible[i]>1e-12),shuffle=seeded(937);for(let i=eligible.length-1;i>0;i--){const j=Math.floor(shuffle()*(i+1));[eligible[i],eligible[j]]=[eligible[j],eligible[i]];}
 return {exact:true,ctx,names,rows,compatible,total,marginals,own:[...own],ownKey:exactHandKey(own),bb:h.bb,config:input.config||{},models:input.beliefState.responses||{},nodes:new Map(),iterations:0,regretUpdates:0,averageUpdates:0,transientVisits:0,maxNodes:input.maxNodes||60000,draws:rows.map(distribution),startStacks:names.map(n=>ctx.players.find(p=>p.name===n).stack),randomState:190531,fallbacks:0,lookups:0,summaryCache:new Map(),eligible};
}
function baseline(game,ctx,cards,actions){
 const other=1-game.names.indexOf(ctx.actor),cache=other+'|'+ctx.board.join(',');let summary=game.summaryCache.get(cache);
 if(!summary){const rows=game.rows[other],step=Math.max(1,Math.floor(rows.length/32));summary=beliefSummary(rows.filter((_,i)=>i%step===0),ctx.board);if(game.summaryCache.size>=2000)game.summaryCache.delete(game.summaryCache.keys().next().value);game.summaryCache.set(cache,summary);}
 return actionPolicy({...ctx,actions,responseModel:game.models[ctx.actor]},cards,0,summary).map(a=>a.prob);
}
function info(game,ctx,cards,history,wagers,root,create){
 const actor=game.names.indexOf(ctx.actor),key=exactInfoKey(actor,cards,ctx.board,history);let node=game.nodes.get(key);
 if(!node){const actions=exactMenu(ctx,wagers,root),base=baseline(game,ctx,cards,actions);node={key,actor,actions,base,regret:actions.map(()=>0),sum:actions.map(()=>0),updates:0,averageVisits:0};if(create&&game.nodes.size<game.maxNodes)game.nodes.set(key,node);else if(create)game.transientVisits++;}
 return node;
}
// Sparse exact states are unstable after only one or two sampled outcomes.
// Keep the raw CFR accumulators; the played/evaluated policy explicitly shrinks
// their average toward the learned baseline by 16 pseudo-visits.
function strategy(node,average=false){const policy=normalized(average?node.sum:node.regret.map(v=>Math.max(0,v)),node.base);if(!average)return policy;const trained=node.averageVisits/(node.averageVisits+16);return policy.map((p,i)=>trained*p+(1-trained)*node.base[i]);}
function drawDeal(game,random){
 // Randomly shuffled cycles over first-player hands give each combination
 // training opportunities; importance weights recover the public joint prior.
 const eligible=game.eligible,i=eligible[game.iterations%eligible.length],a=game.rows[0][i];let b;
 for(let n=0;n<100000;n++){b=pickDistribution(game.draws[1],random);if(!a.cards.some(c=>b.cards.includes(c)))break;b=null;}if(!b)throw Error('Could not sample a compatible deal.');
 return {hands:[a.cards,b.cards],weight:eligible.length*game.marginals[i]};
}
function nextBoard(ctx,hands,random){
 const deck=DECK.filter(c=>!ctx.board.includes(c)&&!hands.some(h=>h.includes(c))),s=copy(ctx),count=s.board.length?1:3;
 for(let i=0;i<count;i++){const j=i+Math.floor(random()*(deck.length-i));[deck[i],deck[j]]=[deck[j],deck[i]];s.board.push(deck[i]);}
 s.street=({3:'Flop',4:'Turn',5:'River'})[s.board.length];s.level=0;s.minRaise=s.bb;s.raises=0;s.acted={};s.players.forEach(p=>p.streetContribution=0);s.pending=s.players.filter(p=>!p.folded&&p.stack>0).map(p=>p.name);
 s.actor=s.pending.length<2?null:[...s.players].sort((a,b)=>Number(a.seat<=s.button)-Number(b.seat<=s.button)||a.seat-b.seat).find(p=>s.pending.includes(p.name)).name;return s;
}
function terminal(game,ctx,hands){
 const alive=ctx.players.filter(p=>!p.folded),scores=alive.map(p=>({name:p.name,value:evaluate([...hands[game.names.indexOf(p.name)],...ctx.board]).score})),best=Math.max(...scores.map(s=>s.value)),winners=scores.filter(s=>s.value===best).map(s=>s.name);
 const cfg=game.config,fees=ctx.board.length?Math.min(ctx.pot,Math.min(Math.round(ctx.pot*(cfg.rakePct??5)/100),Math.round((cfg.rakeCap??1)*100))+Math.round((cfg.extraFee??0)*100)):0,net=ctx.pot-fees;
 const order=[...ctx.players].sort((a,b)=>Number(a.seat<=ctx.button)-Number(b.seat<=ctx.button)||a.seat-b.seat).filter(p=>winners.includes(p.name)).map(p=>p.name);
 const awards=game.names.map(n=>{const i=order.indexOf(n);return i<0?0:Math.floor(net/order.length)+Number(i<net%order.length);}),investments=game.names.map((n,i)=>game.startStacks[i]-ctx.players.find(p=>p.name===n).stack);
 return {values:awards.map((a,i)=>(a-investments[i])/game.bb),award:awards[0]/100,investment:investments[0]/100,payoff:(awards[0]-investments[0])/100,outcome:alive.length===1?(winners.includes(game.names[0])?'Opponent folds':'Hero folds'):winners.includes(game.names[0])?winners.length>1?'Split showdown':'Hero wins showdown':'Hero loses showdown'};
}
function descend(game,ctx,hands,history,wagers,root,updating,random,weight){
 if(!ctx.actor){if(ctx.players.filter(p=>!p.folded).length===1||ctx.board.length===5)return terminal(game,ctx,hands).values[updating];const next=nextBoard(ctx,hands,random);return descend(game,next,hands,history+'/B'+next.board.join(','),0,false,updating,random,weight);}
 const actor=game.names.indexOf(ctx.actor),node=info(game,ctx,hands[actor],history,wagers,root,true),policy=strategy(node);
 function child(i){const next=copy(ctx),a=node.actions[i];advanceState(next,a);return descend(game,next,hands,history+'/'+actor+':'+a.id,wagers+Number(a.kind==='bet'),false,updating,random,weight);}
 if(actor!==updating){node.averageVisits++;game.averageUpdates++;policy.forEach((p,i)=>node.sum[i]+=weight*p);return child(sampleIndex(policy,random));}
 const values=node.actions.map((_,i)=>child(i)),v=values.reduce((s,x,i)=>s+x*policy[i],0);values.forEach((x,i)=>node.regret[i]+=weight*(x-v));node.updates++;game.regretUpdates++;return v;
}
function sampleIndex(prob,random){let x=random()*sum(prob);for(let i=0;i<prob.length;i++){x-=prob[i];if(x<=0)return i;}return prob.length-1;}
export function trainExact(game,iterations=1){const random=()=>{game.randomState=(Math.imul(game.randomState,1664525)+1013904223)>>>0;return game.randomState/4294967296;};for(let t=0;t<iterations;t++){for(let player=0;player<2;player++){const deal=drawDeal(game,random);descend(game,copy(game.ctx),deal.hands,'',0,true,player,random,deal.weight);}game.iterations++;}return game;}
export function exactPolicyFor(plan,cards){const n=info(plan.game,plan.ctx,cards,plan.history,plan.wagers,plan.root,false);return {policy:n.actions.map((a,i)=>({...a,prob:strategy(n,true)[i]})),updates:n.updates,averageVisits:n.averageVisits};}
export function exactActionLikelihood(plan,action){
 if(!plan?.game.exact||!plan.ctx.actor)return null;
 const index=plan.game.names.indexOf(plan.ctx.actor),rows=conditionCards(plan.game.rows[index],plan.ctx.board);
 return Object.fromEntries(rows.map(r=>{const policy=exactPolicyFor(plan,r.cards).policy,a=policy.find(a=>a.kind===action.kind&&(a.kind!=='bet'||a.to===action.to));return [r.key,a?.prob||0];}));
}
export function advanceExactPlan(plan,event){
 if(!plan)return null;let ctx=copy(plan.ctx),history=plan.history,wagers=plan.wagers;
 if(event.type==='action'){
  if(ctx.actor!==event.actor)return null;const kind=({folds:'fold',checks:'check',calls:'call',bets:'bet',raises:'bet'})[event.action]||event.kind;
  const a=exactMenu(ctx,wagers,plan.root).find(a=>a.kind===kind&&(kind!=='bet'||a.to===(event.to??ctx.players.find(p=>p.name===ctx.actor).streetContribution+event.amount)));if(!a)return null;
  const actor=plan.game.names.indexOf(ctx.actor);advanceState(ctx,a);history+='/'+actor+':'+a.id;wagers+=Number(a.kind==='bet');
 }else if(event.type==='street'){
  if(ctx.actor||event.board.length!==(ctx.board.length?ctx.board.length+1:3)||!ctx.board.every((c,i)=>c===event.board[i]))return null;
  ctx.board=[...event.board];ctx.street=event.street;ctx.level=0;ctx.minRaise=ctx.bb;ctx.raises=0;ctx.acted={};ctx.players.forEach(p=>p.streetContribution=0);ctx.pending=ctx.players.filter(p=>!p.folded&&p.stack>0).map(p=>p.name);ctx.actor=ctx.pending.length<2?null:[...ctx.players].sort((a,b)=>Number(a.seat<=ctx.button)-Number(b.seat<=ctx.button)||a.seat-b.seat).find(p=>ctx.pending.includes(p.name)).name;history+='/B'+ctx.board.join(',');wagers=0;
 }else return plan;
 return {...plan,ctx,history,wagers,root:false};
}
export function exactPlanDecision(plan){
 if(!plan?.game.exact||plan.ctx.actor!==plan.game.names[0])return null;
 const own=exactPolicyFor(plan,plan.game.own);if(own.averageVisits<4)return null;
 return {engine:'exact-hand-cfr',policy:own.policy,iterations:plan.game.iterations,informationSets:plan.game.nodes.size,rootUpdates:own.updates,averageVisits:own.averageVisits,trainedPolicyWeight:own.averageVisits/(own.averageVisits+16),reused:!plan.root,scope:EXACT_SCOPE};
}
export const EXACT_SCOPE='Hand-specific external-sampling CFR: exact two-card information sets and exact revealed boards, sampled compatible private deals and chance cards, restricted future bet sizes and raise counts. Played policies shrink the average strategy toward the continuous baseline by 16 pseudo-visits; unvisited information sets use that baseline. Finite sampling and sparse coverage remain limitations; no full-game Nash or exploitability guarantee.';
export const solveExactCfr=async (input,{iterations=4000,onProgress=()=>{},cancel=()=>false,maxNodes=60000}={})=>{
 if(cancel())return null;const game=buildExactGame({...input,maxNodes});for(const r of game.rows[0])info(game,game.ctx,r.cards,'',0,true,true);let last=performance.now();
 for(let i=0;i<iterations;i++){if(cancel())return null;trainExact(game,1);if(performance.now()-last>=40||i+1===iterations){onProgress('Exact-hand CFR · '+(i+1)+' / '+iterations+' iterations · '+game.nodes.size.toLocaleString()+' information sets');await new Promise(r=>setTimeout(r,0));last=performance.now();}}
 if(cancel())return null;const plan={game,ctx:copy(game.ctx),history:'',wagers:0,root:true},own=exactPolicyFor(plan,game.own);
 return {engine:'exact-hand-cfr',policy:own.policy,iterations:game.iterations,informationSets:game.nodes.size,rootUpdates:own.updates,averageVisits:own.averageVisits,trainedPolicyWeight:own.averageVisits/(own.averageVisits+16),memoryLimited:game.transientVisits>0,transientVisits:game.transientVisits,scope:EXACT_SCOPE,plan};
};
function rollout(plan,hands,first,random,stats){
 const game=plan.game,path=[];let ctx=copy(plan.ctx),history=plan.history,wagers=plan.wagers,root=plan.root,action=first,initial=true;
 for(let n=0;n<120;n++){
  if(!ctx.actor){if(ctx.board.length===5||ctx.players.filter(p=>!p.folded).length===1)return {...terminal(game,ctx,hands),path};ctx=nextBoard(ctx,hands,random);if(path.length<3)path.push('Board · '+ctx.board.join(' '));history+='/B'+ctx.board.join(',');wagers=0;root=false;continue;}
  const actor=game.names.indexOf(ctx.actor);if(!action){const node=info(game,ctx,hands[actor],history,wagers,root,false);stats.lookups++;if(!node.averageVisits)stats.fallbacks++;const policy=strategy(node,true);action=node.actions[sampleIndex(policy,random)];}
  if(!initial&&path.length<3)path.push(ctx.street+' · '+ctx.actor+' '+action.label);initial=false;advanceState(ctx,action);history+='/'+actor+':'+action.id;wagers+=Number(action.kind==='bet');root=false;action=null;
 }
 throw Error('Exact-hand rollout exceeded legal action bound.');
}
export const inspectExact=async (solved,input,{samples=1000,onProgress=()=>{},cancel=()=>false}={})=>{
 const {plan,...diagnostics}=solved,game=plan.game,h=input.hand,own=h.players.find(p=>p.name===h.hero).cards,opponents=comboMass(conditionCards(input.beliefState.filters[game.names[1]],[...plan.ctx.board,...own])),pick=sampler(opponents),stats={lookups:0,fallbacks:0},allActions=[];
 for(const action of solved.policy){const random=seeded(81821),routes=new Map(),tree={n:0,value:0,children:new Map()};let value=0,sq=0;
  for(let i=0;i<samples;i++){if(cancel())return null;const result=rollout(plan,[own,pick(random).cards],action,random,stats),zero=Math.abs(result.investment)<1e-9,name=result.outcome+(zero?' · 0 BB further':' · paid continuation'),r=routes.get(name)||{name,p:0,award:0,investment:0,contribution:0,zeroInvestment:zero};r.p++;r.award+=result.award;r.investment+=result.investment;r.contribution+=result.payoff;routes.set(name,r);let branch=tree;branch.n++;branch.value+=result.payoff;for(const label of result.path){if(!branch.children.has(label))branch.children.set(label,{label,n:0,value:0,children:new Map()});branch=branch.children.get(label);branch.n++;branch.value+=result.payoff;}value+=result.payoff;sq+=result.payoff**2;if(i%200===199){onProgress('Evaluating '+action.label+' · '+(i+1)+' / '+samples);await new Promise(r=>setTimeout(r,0));}}
  const map=exactActionLikelihood(plan,action),reach=game.rows[0].reduce((s,r,i)=>s+game.marginals[i]*(map[r.key]||0),0),heroActionRange=reach>0?game.rows[0].map((r,i)=>({cards:r.cards,probability:game.marginals[i]*(map[r.key]||0)/reach})).filter(r=>r.probability>0).sort((a,b)=>b.probability-a.probability):[];
  const outcomeRows=[...routes.values()].map(r=>({...r,p:r.p/samples,award:r.award/r.p,investment:r.investment/r.p,payoff:r.contribution/r.p,contribution:r.contribution/samples}));
  const exportBranch=(b,parent)=>({label:b.label||action.label,probability:b.n/samples,conditionalProbability:b.n/parent,ev:b.value/b.n,children:[...b.children.values()].sort((a,b)=>b.n-a.n).map(c=>exportBranch(c,b.n))});
  allActions.push({...action,tree:exportBranch(tree,samples),policy:action.prob,reach,heroActionRange,ev:value/samples,se:Math.sqrt(Math.max(0,(sq-value*value/samples)/(samples-1))/samples),routes:outcomeRows,immediateInvestment:action.cost/100,expectedInvestment:outcomeRows.reduce((s,r)=>s+r.p*r.investment,0),zeroInvestmentProbability:outcomeRows.filter(r=>r.zeroInvestment).reduce((s,r)=>s+r.p,0)});
 }
 const sorted=[...allActions].sort((a,b)=>b.ev-a.ev),rootCoverage=game.rows[0].reduce((s,r,i)=>s+(exactPolicyFor(plan,r.cards).averageVisits?game.marginals[i]:0),0);
 return {model:'exact-hand-cfr',...diagnostics,board:[...plan.ctx.board],cards:[...own],conditioning:input.conditioning,samples,allActions,actions:sorted.slice(0,5).map((a,i)=>({...a,rank:i+1,gap:sorted[0].ev-a.ev})),tested:allActions.length,rootCoverage,fallbackRate:stats.lookups?stats.fallbacks/stats.lookups:0,opponentRange:opponents};
};
