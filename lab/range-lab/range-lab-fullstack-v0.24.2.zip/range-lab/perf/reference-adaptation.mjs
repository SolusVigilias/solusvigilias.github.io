// Online, player-specific action calibration. No private cards or rewards enter
// this model. Sparse contexts share four action categories across legal sizes.
export const MEMORY_HALF_LIFE=8;
export const MEMORY_DECAY=2**(-1/MEMORY_HALF_LIFE);
export const RESPONSE_PRIOR=()=>({version:2,contexts:{},actions:0,logLoss:0});
export const RESPONSE_FEATURES=['strength','draw','paired board','suited board','connected board','call price','stack pressure','range advantage','perceived aggression','strength × price','draw × price','strength × texture','strength × range','bet size'];
// Features use only the candidate holding and public state, never actual hidden cards.
export function responseFeatures(ctx,signal,draw,range,image){
 const p=ctx.players.find(p=>p.name===ctx.actor),owed=Math.max(0,ctx.level-p.streetContribution),call=Math.min(owed,p.stack),pot=Math.max(1,ctx.pot-(ctx.players.length===2?Math.max(0,owed-call):0));
 const ranks=[...new Set(ctx.board.map(c=>'23456789TJQKA'.indexOf(c[0])+2))];if(ranks.includes(14))ranks.push(1);
 let connected=0;for(let low=1;low<=10;low++)connected=Math.max(connected,ranks.filter(r=>r>=low&&r<low+5).length);
 const suits={};for(const c of ctx.board)suits[c[1]]=(suits[c[1]]||0)+1;
 const paired=Number(new Set(ctx.board.map(c=>c[0])).size<ctx.board.length),suited=Math.max(0,Math.max(0,...Object.values(suits))-1)/4,connect=Math.max(0,connected-1)/4;
 const strength=2*signal-1,price=call/(pot+call),commit=call/Math.max(1,p.stack),advantage=signal-range,texture=(paired+suited+connect)/3;
 return [strength,Number(draw),paired,suited,connect,price,commit,advantage,Math.max(-1,Math.min(1,image-1)),strength*price,Number(draw)*price,strength*texture,strength*advantage,0].map(v=>v*.5);
}
export function actionFeatures(features,ctx,action){
 const x=[...features],p=ctx.players.find(p=>p.name===ctx.actor),owed=Math.max(0,ctx.level-p.streetContribution),call=Math.min(owed,p.stack);
 const pot=Math.max(ctx.bb,ctx.pot-(ctx.players.length===2?Math.max(0,owed-call):0)+call);
 x[x.length-1]=action.kind==='bet'?.5*Math.tanh(Math.max(0,action.cost-call)/pot):0;return x;
}
export function actionGroup(a){return a.kind==='bet'?'bet':a.kind;}
export function responseContext(ctx){
 const p=ctx.players.find(p=>p.name===ctx.actor),owed=Math.max(0,ctx.level-p.streetContribution),call=Math.min(owed,p.stack);
 const excess=ctx.players.length===2?Math.max(0,owed-call):0,pot=Math.max(1,ctx.pot-excess),size=call/pot;
 const facing=owed?(size<=.35?'small':size<=.8?'medium':'large'):'free';
 return ctx.street==='Preflop'?'Preflop/'+(ctx.raises?ctx.raises===1?'open':'reraise':p.position) :ctx.street+'/'+facing;
}
export function responseCell(model,ctx){return model?.contexts?.[responseContext(ctx)];}
export function responseOffset(model,ctx,action,features=[]){const cell=responseCell(model,ctx),group=actionGroup(action);return (cell?.theta?.[group]||0)+features.reduce((n,x,i)=>n+x*(cell?.weights?.[group]?.[i]||0),0);}
// Diagonal Gaussian assumed posterior over continuous contextual coefficients.
// Four fixed antithetic draws integrate predictive action probabilities. This is
// an approximate online Laplace/ADF model, not a calibrated exact posterior.
const normals=Array.from({length:2},(_,sample)=>Array.from({length:60},(_,i)=>{const a=Math.sin((i+1)*12.9898+(sample+1)*78.233)*43758.5453,b=Math.sin((i+1)*39.346+(sample+1)*11.135)*24634.6345,u=Math.max(1e-8,a-Math.floor(a)),v=b-Math.floor(b);return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}));
export function responseEnsemble(model,ctx,rows){
 const cell=responseCell(model,ctx),groups=['fold','check','call','bet'];
 return Array.from({length:4},(_,sample)=>{
  const logits=rows.map(a=>{const group=actionGroup(a),g=groups.indexOf(group),features=[1,...a.features],means=[cell?.theta?.[group]||0,...(cell?.weights?.[group]||RESPONSE_FEATURES.map(()=>0))],precision=cell?.precision?.[group]||features.map(()=>4),sign=sample%2?1:-1;
   return Math.log(Math.max(1e-300,a.prob))+features.reduce((s,x,i)=>s+x*(means[i]+sign*normals[Math.floor(sample/2)][g*15+i]/Math.sqrt(precision[i])),0);
  });const max=Math.max(...logits),weights=logits.map(x=>Math.exp(x-max)),total=weights.reduce((s,v)=>s+v,0);return weights.map(v=>v/total);
 });
}
export function trainResponse(model,ctx,update,event){
 if(!model)return;
 const key=responseContext(ctx),cell=model.contexts[key]??={n:0,counts:{fold:0,check:0,call:0,bet:0},theta:{fold:0,check:0,call:0,bet:0},logLoss:0};
 const kind=event.kind||({folds:'fold',checks:'check',calls:'call',bets:'bet',raises:'bet'})[event.action],group=actionGroup({kind});
 if(!(group in cell.counts))return;
 // EMA sufficient statistics: an observation halves its weight after eight
 // further opportunities in this context, not eight unrelated actions.
 cell.recent??={fold:0,check:0,call:0,bet:0};cell.weight=MEMORY_DECAY*(cell.weight||0)+1;
 cell.recentLoss=MEMORY_DECAY*(cell.recentLoss||0)+update.logLoss;
 for(const name of Object.keys(cell.theta)){
  cell.recent[name]=MEMORY_DECAY*cell.recent[name]+Number(name===group);
  // Forget stale coefficients and keep a constant step size so a long session
  // does not become less responsive. This is discounted online gradient fitting,
  // not an exact batch minimizer of exponentially weighted likelihood.
  cell.precision??={};cell.precision[name]??=Array(RESPONSE_FEATURES.length+1).fill(4);
  cell.precision[name]=cell.precision[name].map((v,i)=>Math.max(4,Math.min(10000,4+MEMORY_DECAY*(v-4)+(update.fisher?.[name]?.[i]||0))));
  cell.theta[name]=Math.max(-4,Math.min(4,MEMORY_DECAY*cell.theta[name]+.4*(update.gradient?.[name]||0)/Math.sqrt(cell.precision[name][0]/4)));
  cell.weights??={};cell.weights[name]??=RESPONSE_FEATURES.map(()=>0);
  cell.weights[name]=cell.weights[name].map((w,i)=>Math.max(-4,Math.min(4,MEMORY_DECAY*w+.4*(update.featureGradient?.[name]?.[i]||0)/Math.sqrt(cell.precision[name][i+1]/4))));
 }
 cell.n++;cell.counts[group]++;cell.logLoss+=update.logLoss;model.actions++;model.logLoss+=update.logLoss;model.version=2;
}
