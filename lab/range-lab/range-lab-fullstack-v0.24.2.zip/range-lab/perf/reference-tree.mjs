import {DECK,snapshot,evaluate} from './reference-poker.mjs';
import {publicContext,legalActions,actionPolicy,drawWeighted,seeded,TYPE_PRIOR} from './reference-policy.mjs';
import {nodeBeliefs,compactBelief,conditionCards,beliefSummary,updateBelief,sampleHolding,typeMass} from './reference-learning.mjs';

export function treeAvailability(h,step){
 const s=snapshot(h,step),hero=s.players.find(p=>p.name===h.hero),alive=s.players.filter(p=>!p.folded);
 if(h.warnings.length)return 'Resolve the hand’s accounting warnings first.';
 if(alive.length!==2)return 'The learning tree currently requires two active players. The existing six-player preflop model remains available below.';
 if(hero.folded||!hero.stack)return 'Move to a decision where Hero has chips and is active.';
 const actor=h.live&&step===h.events.length?h.live.actor:h.events[step]?.type==='action'?h.events[step].actor:null;
 if(actor!==h.hero)return 'Move to a Hero decision.';
 if(hero.cards.length!==2)return 'Enter Hero’s two cards.';
 return '';
}
function cloneContext(ctx){return {...ctx,board:[...ctx.board],players:ctx.players.map(p=>({...p})),acted:structuredClone(ctx.acted),pending:[...ctx.pending]};}
function clockwise(a,b,seat){return Number(a.seat<=seat)-Number(b.seat<=seat)||a.seat-b.seat;}
function afterSeat(ctx,seat){return [...ctx.players].sort((a,b)=>clockwise(a,b,seat)).find(p=>ctx.pending.includes(p.name))?.name;}
export function advanceState(ctx,action){
 const p=ctx.players.find(p=>p.name===ctx.actor),owed=Math.max(0,ctx.level-p.streetContribution),old=ctx.level;
 if(action.kind==='fold'){if(!owed)throw Error('Illegal fold.');p.folded=true;}
 else if(action.kind==='check'){if(owed)throw Error('Illegal check.');}
 else {
  const delta=action.kind==='call'?Math.min(owed,p.stack):action.to-p.streetContribution;
  if(delta<0||delta>p.stack||action.kind==='bet'&&!legalActions(ctx).some(a=>a.id===action.id))throw Error('Illegal wager in tree.');
  p.stack-=delta;p.committed+=delta;p.streetContribution+=delta;ctx.pot+=delta;
  if(action.kind==='bet'){ctx.minRaise=Math.max(ctx.minRaise,p.streetContribution-old);ctx.level=p.streetContribution;ctx.raises++;ctx.pending=ctx.players.filter(v=>v.name!==p.name&&!v.folded&&v.stack>0&&v.streetContribution<ctx.level).map(v=>v.name);}
 }
 if(action.kind!=='bet')ctx.pending=ctx.pending.filter(n=>n!==p.name);
 ctx.acted[p.name]={level:ctx.level,minRaise:ctx.minRaise,checked:action.kind==='check'};
 const alive=ctx.players.filter(p=>!p.folded),funded=alive.filter(p=>p.stack>0);
 ctx.pending=ctx.pending.filter(n=>funded.some(p=>p.name===n));
 if(funded.length<2){const v=funded[0],level=Math.max(...alive.map(p=>p.streetContribution));ctx.level=level;ctx.pending=v&&v.streetContribution<level?[v.name]:[];}
 if(alive.length===1||!ctx.pending.length){
  const ranked=[...ctx.players].sort((a,b)=>b.streetContribution-a.streetContribution),amount=ranked[0].streetContribution-ranked[1].streetContribution;
  if(amount>0){ranked[0].stack+=amount;ranked[0].committed-=amount;ranked[0].streetContribution-=amount;ctx.pot-=amount;}
  ctx.actor=null;return alive.length===1||ctx.board.length===5?'terminal':'board';
 }
 ctx.actor=afterSeat(ctx,p.seat);return 'action';
}
function dealStreet(ctx,deck,random){
 const count=ctx.board.length?1:3;for(let j=0;j<count;j++){const i=Math.floor(random()*deck.length);ctx.board.push(deck[i]);deck[i]=deck.at(-1);deck.pop();}
 ctx.street=({3:'Flop',4:'Turn',5:'River'})[ctx.board.length];ctx.level=0;ctx.minRaise=ctx.bb;ctx.raises=0;ctx.acted={};ctx.players.forEach(p=>p.streetContribution=0);ctx.pending=ctx.players.filter(p=>!p.folded&&p.stack>0).map(p=>p.name);
 if(ctx.pending.length<2){ctx.actor=null;return ctx.board.length===5?'terminal':'board';}
 ctx.actor=afterSeat(ctx,ctx.button);return 'action';
}
export function terminalPayoff(ctx,holdings,hero,startStack,config={}){
 const alive=ctx.players.filter(p=>!p.folded),scores=alive.map(p=>({name:p.name,score:evaluate([...holdings[p.name],...ctx.board]).score})),best=Math.max(...scores.map(p=>p.score));
 const winners=scores.filter(p=>p.score===best).map(p=>p.name),rake=ctx.board.length?Math.min(ctx.pot,Math.min(Math.round(ctx.pot*(config.rakePct??5)/100),Math.round((config.rakeCap??1)*100))+Math.round((config.extraFee??0)*100)):0;
 const amount=ctx.pot-rake,sorted=ctx.players.filter(p=>winners.includes(p.name)).sort((a,b)=>clockwise(a,b,ctx.button)),heroIndex=sorted.findIndex(p=>p.name===hero),award=heroIndex<0?0:Math.floor(amount/winners.length)+(heroIndex<amount%winners.length?1:0),p=ctx.players.find(p=>p.name===hero);
 return {payoff:(p.stack+award-startStack)/100,award:award/100,pot:ctx.pot/100,invested:(startStack-p.stack)/100,outcome:alive.length===1?(winners.includes(hero)?'Opponent folds':'Hero folds'):winners.includes(hero)?winners.length>1?'Split showdown':'Hero wins showdown':'Hero loses showdown'};
}
function track(root,path,result,holding){let node=root;for(const label of ['Root',...path]){if(label!=='Root')node=node.children[label]??={count:0,sum:0,award:0,invested:0,children:{}};node.count++;node.sum+=result.payoff;node.award+=result.award;node.invested+=result.invested;node.range??={};const row=node.range[holding.key]??={cards:holding.cards,count:0};row.count++;}}
function exportTree(node,parentCount,total){return {visits:node.count,probability:node.count/total,conditionalProbability:node.count/parentCount,ev:node.sum/node.count,expectedAward:node.award/node.count,expectedInvestment:node.invested/node.count,opponentRange:Object.values(node.range||{}).map(r=>({cards:r.cards,samples:r.count,probability:r.count/node.count})).sort((a,b)=>b.probability-a.probability),children:Object.entries(node.children).map(([label,n])=>({label,...exportTree(n,node.count,total)}))};}
export const analyzeTree=async ({hands,hand:h,step,priors={},config={},iterations=400,onProgress=()=>{},cancel=()=>false,beliefState=null})=>{
 const unavailable=treeAvailability(h,step);if(unavailable)throw Error(unavailable);
 const ctx=publicContext(h,step,h.hero),hero=ctx.players.find(p=>p.name===h.hero),villain=ctx.players.find(p=>!p.folded&&p.name!==h.hero),heroCards=h.players.find(p=>p.name===h.hero).cards;
 const beliefs=beliefState||nodeBeliefs(hands,h,step,priors),vRange=beliefs.ranges[villain.name],publicHero=beliefs.views[villain.name]?.rows||beliefs.filters[h.hero],publicVillain=beliefs.filters[villain.name],candidates=legalActions(ctx),oppSummary=beliefSummary(publicVillain,ctx.board);
 const responseModels={...beliefs.responses,[h.hero]:beliefs.views[villain.name]?.model||beliefs.responses?.[h.hero]};ctx.responseModel=responseModels[h.hero];
 const heroTypes=typeMass(conditionCards(publicHero,[],heroCards)),rootPolicy=candidates.map(a=>({...a,prob:0,reach:0})),heroBranches=candidates.map(()=>new Map());
 for(const r of publicHero){const policy=actionPolicy({...ctx,actions:candidates},r.cards,r.type,oppSummary);policy.forEach((a,i)=>{const weight=r.prob*a.prob;rootPolicy[i].reach+=weight;const old=heroBranches[i].get(r.key);if(old)old.weight+=weight;else heroBranches[i].set(r.key,{cards:r.cards,weight});});}
 // Hero's future policy mixes the same hypotheses. Root action EV is a counterfactual,
 // so opponents condition on its likelihood under their public model of Hero.
 for(let t=0;t<heroTypes.length;t++)actionPolicy({...ctx,actions:candidates},heroCards,t,oppSummary).forEach((a,i)=>rootPolicy[i].prob+=heroTypes[t]*a.prob);
 const n=Math.max(100,Math.min(2000,Math.round(iterations))),results=[];
 for(let ai=0;ai<candidates.length;ai++){
  const action=candidates[ai],routes=new Map(),tree={count:0,sum:0,award:0,invested:0,children:{}},random=seeded(83871),counts={fold:0,call:0,raise:0};let sum=0,sq=0,supportRecoveries=0;
  for(let k=0;k<n;k++){
   if(cancel())return null;
   const s=cloneContext(ctx),vr=sampleHolding(vRange,[...heroCards,...ctx.board],random),ht=drawWeighted(heroTypes.map((prob,type)=>({prob,type})),random).type,holdings={[h.hero]:heroCards,[villain.name]:vr.cards},styles={[h.hero]:ht,[villain.name]:vr.type};
   const bases={[h.hero]:publicHero,[villain.name]:publicVillain},filters={[h.hero]:compactBelief(publicHero,32,117+k),[villain.name]:compactBelief(publicVillain,32,227+k)},trail={[h.hero]:[],[villain.name]:[]},deck=DECK.filter(c=>![...heroCards,...vr.cards,...s.board].includes(c)),path=[];
   let chosen=action,phase='action',actionsTaken=0,firstResponse=true;
   while(phase!=='terminal'){
    if(phase==='board'){
     phase=dealStreet(s,deck,random);
     for(const name of Object.keys(filters)){
      if(filters[name].some(r=>r.cards.every(c=>!s.board.includes(c))))filters[name]=conditionCards(filters[name],s.board);
      else {let exact=conditionCards(bases[name],s.board);for(const observed of trail[name])exact=updateBelief(exact,observed.ctx,observed.action,observed.opposing).rows;filters[name]=compactBelief(exact,32,327+k);supportRecoveries++;}
     }
     continue;
    }
    if(++actionsTaken>120)throw Error('A rollout exceeded the action limit; no truncated EV was returned.');
    const actor=s.actor,other=actor===h.hero?villain.name:h.hero,context={...s,actions:legalActions(s),responseModel:responseModels[actor]},opposing=beliefSummary(filters[other],s.board),own=holdings[actor];
    if(actionsTaken>1)chosen=drawWeighted(actionPolicy(context,own,styles[actor],opposing),random);
    if(actor===villain.name&&firstResponse){counts[chosen.kind==='fold'?'fold':chosen.kind==='bet'?'raise':'call']++;firstResponse=false;}
    // Counterfactual public beliefs: never condition this on the sampled actual cards.
    filters[actor]=updateBelief(filters[actor],context,chosen,opposing).rows;trail[actor].push({ctx:{...context,players:context.players.map(p=>({...p})),board:[...context.board]},action:chosen,opposing});
    if(actionsTaken>1&&path.length<3)path.push(s.street+' · '+(actor===h.hero?'Hero':'Opponent')+' '+chosen.label);
    phase=advanceState(s,chosen);
   }
   const result=terminalPayoff(s,holdings,h.hero,hero.stack,config),v=routes.get(result.outcome)||{name:result.outcome,count:0,sum:0,award:0,invested:0};v.count++;v.sum+=result.payoff;v.award+=result.award;v.invested+=result.invested;routes.set(result.outcome,v);sum+=result.payoff;sq+=result.payoff**2;if(path.length<3)path.push('Terminal · '+result.outcome);track(tree,path,result,vr);
   if(k%50===49){onProgress('Action '+(ai+1)+' / '+candidates.length+' · '+(k+1)+' / '+n+' rollouts');await new Promise(resolve=>setTimeout(resolve,0));}
  }
  const ev=sum/n,se=Math.sqrt(Math.max(0,(sq-sum*sum/n)/(n-1))/n),denom=counts.fold+counts.call+counts.raise;
  results.push({...action,order:ai,ev,se,supportRecoveries,policy:rootPolicy[ai].prob,reach:rootPolicy[ai].reach,heroActionRange:[...heroBranches[ai].values()].map(r=>({cards:r.cards,probability:r.weight/rootPolicy[ai].reach})).sort((a,b)=>b.probability-a.probability),routes:[...routes.values()].map(r=>({name:r.name,p:r.count/n,payoff:r.sum/r.count,contribution:r.sum/n,award:r.award/r.count,investment:r.invested/r.count})),mix:denom?Object.fromEntries(Object.entries(counts).map(([key,v])=>[key,v/denom])):null,tree:exportTree(tree,n,n)});
 }
 const sorted=[...results].sort((a,b)=>b.ev-a.ev||a.order-b.order),best=sorted[0].ev;
 return {model:'belief-tree',iterations:n,tested:results.length,actions:sorted.slice(0,5).map((a,i)=>({...a,rank:i+1,gap:best-a.ev})),allActions:results,opponent:villain.name,beliefs:{types:typeMass(vRange),range:vRange.length,combos:new Set(vRange.map(r=>r.key)).size,heroImage:typeMass(publicHero),priorHands:beliefs.learned.hands},scope:'Heads-up policy rollouts through terminal payoff; first three subsequent decisions shown, chance boards integrated. Factored ranges, 32-particle continuation beliefs; four heuristic style models, no equilibrium solve.'};
};
