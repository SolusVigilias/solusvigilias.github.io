import {ALL_COMBOS,playerKey,snapshot,handClass} from './reference-poker.mjs';
import {TYPES,TYPE_PRIOR,publicContext,legalActions,actionPolicy,observedAction,handSignal,drawWeighted,seeded} from './reference-policy.mjs';
import {RESPONSE_PRIOR,RESPONSE_FEATURES,actionGroup,trainResponse,MEMORY_DECAY} from './reference-adaptation.mjs';

export function normalize(rows){const total=rows.reduce((n,r)=>n+r.prob,0);if(!(total>0))throw Error('No compatible probability mass remains. Widen the edited prior.');return rows.filter(r=>r.prob>0).map(r=>({...r,prob:r.prob/total}));}
export function newBelief(types=TYPE_PRIOR,weights=null){
 return normalize(ALL_COMBOS.map(c=>({cards:c.cards,key:c.key,cls:c.cls,type:0,prob:weights?(weights[c.cls]??0)/100:1}))); // Legacy style weights are retained only for save migration.
}
export function conditionCards(rows,blocked=[],shown=null){const set=new Set(blocked);return normalize(rows.filter(r=>r.cards.every(c=>!set.has(c))&&(!shown||shown.every(c=>r.cards.includes(c)))));}
export function typeMass(rows){return rows.reduce((p,r)=>(p[r.type]+=r.prob,p),[0,0,0,0]);}
export function beliefSummary(rows,board,own=[]){
 const valid=rows.filter(r=>r.cards.every(c=>!board.includes(c)&&!own.includes(c))),total=valid.reduce((n,r)=>n+r.prob,0);
 if(!total)return {strength:board.length?.54:.62,aggression:1};
 const out={strength:0,aggression:0,byCard:Object.create(null),byCombo:Object.create(null)};
 for(const r of valid){const mass=r.prob/total,strength=mass*handSignal(r.cards,board),aggression=mass*(TYPES[r.type]?.agg??1);out.strength+=strength;out.aggression+=aggression;
  for(const c of [...r.cards,r.cards.slice().sort().join('')]){const map=c.length===2?out.byCard:out.byCombo,value=map[c]??=[0,0,0];value[0]+=mass;value[1]+=strength;value[2]+=aggression;}
 }
 return out;
}
export function updateBelief(rows,ctx,event,opposing){
 if(event.rangeLikelihood){const next=conditionAction(rows,event.rangeLikelihood),evidence=rows.reduce((s,r)=>s+r.prob*(event.rangeLikelihood[r.key]||0),0);return {rows:next,evidence,logLoss:-Math.log(Math.max(1e-300,evidence)),gradient:{fold:0,check:0,call:0,bet:0},featureGradient:Object.fromEntries(['fold','check','call','bet'].map(k=>[k,RESPONSE_FEATURES.map(()=>0)])),recordedPolicy:true};}
 const actions=ctx.actions||legalActions(ctx),context={...ctx,actions},groups=['fold','check','call','bet'],gradient=Object.fromEntries(groups.map(k=>[k,0])),featureGradient=Object.fromEntries(groups.map(k=>[k,RESPONSE_FEATURES.map(()=>0)])),fisher=Object.fromEntries(groups.map(k=>[k,Array(RESPONSE_FEATURES.length+1).fill(0)]));let evidence=0;
 const next=rows.map(r=>{
  const policy=actionPolicy(context,r.cards,0,opposing),a=observedAction(policy,event),index=policy.indexOf(a),prob=r.prob*(a?.prob??.000001);evidence+=prob;
  if(a&&ctx.responseModel){
   for(const member of a.ensemble){
    const weight=r.prob*.999*member[index]/a.ensemble.length,mass=Object.fromEntries(groups.map(g=>[g,0]));policy.forEach((p,i)=>mass[actionGroup(p)]+=member[i]);
    for(const g of groups){gradient[g]+=weight*(Number(g===actionGroup(a))-mass[g]);fisher[g][0]+=r.prob/a.ensemble.length*mass[g]*(1-mass[g]);}
    policy.forEach((p,i)=>{const g=actionGroup(p),factor=weight*(Number(i===index)-member[i]);p.features.forEach((x,j)=>{featureGradient[g][j]+=factor*x;});});
    for(const g of groups)for(let j=0;j<RESPONSE_FEATURES.length;j++){let mean=0,square=0;policy.forEach((p,i)=>{if(actionGroup(p)===g){mean+=member[i]*p.features[j];square+=member[i]*p.features[j]**2;}});fisher[g][j+1]+=r.prob/a.ensemble.length*Math.max(0,square-mean*mean);}
   }
  }
  return {...r,prob};
 });
 for(const g of groups){gradient[g]/=Math.max(1e-300,evidence);featureGradient[g]=featureGradient[g].map(v=>v/Math.max(1e-300,evidence));}
 return {rows:normalize(next),evidence,logLoss:-Math.log(Math.max(1e-300,evidence)),gradient,featureGradient,fisher};
}
export function conditionAction(rows,likelihood){return normalize(rows.map(r=>({...r,prob:r.prob*(likelihood[r.key]||0)})));}
export function restoreActionEvidence(value,h){
 if(value==null)return {};
 if(typeof value!=='object'||Array.isArray(value)||Object.keys(value).length>500)throw Error('Invalid action-policy evidence.');
 const valid=new Set(ALL_COMBOS.map(r=>r.key)),out={};
 for(const [index,e] of Object.entries(value)){
  const event=h.events[Number(index)];if(!/^\d+$/.test(index)||event?.type!=='action'||e.actor!==event.actor||e.action!==event.action||e.to!==(event.to??null))throw Error('Action-policy evidence does not match the hand.');
  if(!e.likelihood||typeof e.likelihood!=='object'||Array.isArray(e.likelihood)||Object.keys(e.likelihood).length>1326)throw Error('Invalid action likelihoods.');
  const likelihood={};for(const [key,p] of Object.entries(e.likelihood)){if(!valid.has(key)||!Number.isFinite(p)||p<0||p>1)throw Error('Invalid hand action probability.');likelihood[key]=p;}
  if(!Object.values(likelihood).some(p=>p>0))throw Error('Empty action likelihoods.');
  out[index]={actor:e.actor,action:e.action,to:e.to,likelihood,source:'Recorded bot strategy'};
 }
 return out;
}
export function comboMass(rows){const map=new Map();for(const r of rows){const old=map.get(r.key);if(old)old.prob+=r.prob;else map.set(r.key,{cards:r.cards,key:r.key,cls:r.cls||handClass(...r.cards),prob:r.prob});}return [...map.values()].sort((a,b)=>b.prob-a.prob);}
export function compactBelief(rows,count=40,seed=314){
 // Systematic resampling preserves weighted support for inexpensive continuation rollouts.
 const random=seeded(seed),offset=random()/count,out=[];let i=0,sum=rows[0].prob;
 for(let j=0;j<count;j++){const x=offset+j/count;while(sum<x&&i<rows.length-1)sum+=rows[++i].prob;out.push({...rows[i],prob:1/count});}return out;
}
export function beforeHand(a,b){if(a.id===b.id)return false;return a.live?.spec.sessionId&&a.live.spec.sessionId===b.live?.spec.sessionId?a.live.spec.handNumber<b.live.spec.handNumber:a.date<b.date||a.date===b.date&&a.id<b.id;}
const empty=()=>({posterior:[...TYPE_PRIOR],hands:0,actions:0,logLoss:0,response:RESPONSE_PRIOR()});
function record(map,key){if(!map[key])map[key]=empty();return map[key];}
function finalize(rec,rows,count,loss,response){rec.posterior=[1,0,0,0];rec.hands++;rec.actions+=count;rec.logLoss+=loss;rec.response=response;}
function summaries(filters,ctx,actor){const opponents=ctx.players.filter(p=>!p.folded&&p.name!==actor&&filters[p.name]);if(!opponents.length)return {};if(opponents.length===1)return beliefSummary(filters[opponents[0].name],ctx.board);const summaries=opponents.map(p=>beliefSummary(filters[p.name],ctx.board));return {strength:summaries.reduce((n,s)=>n+s.strength,0)/summaries.length,aggression:summaries.reduce((n,s)=>n+s.aggression,0)/summaries.length};}
function processHand(h,limit,profiles,images,priors=null){
 const filters=Object.create(null),views=Object.create(null),counts=Object.create(null),losses=Object.create(null),responses=Object.create(null);
 for(const p of h.players){const key=playerKey(h,p);filters[p.name]=newBelief(profiles[key]?.posterior||TYPE_PRIOR,priors?.[key]);counts[p.name]=0;losses[p.name]=0;
  responses[p.name]=structuredClone(profiles[key]?.response||RESPONSE_PRIOR());
  if(p.name!==h.hero){const heroKey=playerKey(h,h.players.find(p=>p.name===h.hero)),imageKey=key+' → '+heroKey;views[p.name]={key:imageKey,rows:newBelief(images[imageKey]?.posterior||TYPE_PRIOR,priors?.[heroKey]),model:structuredClone(images[imageKey]?.response||RESPONSE_PRIOR()),count:0,loss:0};}
 }
 for(let i=0;i<limit;i++){
  const event=h.actionEvidence?.[i]?{...h.events[i],rangeLikelihood:h.actionEvidence[i].likelihood}:h.events[i];
  if(event.type==='street'){
   for(const name of Object.keys(filters))filters[name]=conditionCards(filters[name],event.board);
   for(const view of Object.values(views))view.rows=conditionCards(view.rows,event.board);
  }
  if(event.type==='action'&&filters[event.actor]){
   const ctx=publicContext(h,i,event.actor);ctx.actions=legalActions(ctx);ctx.responseModel=responses[event.actor];const perceived=event.actor!==h.hero?{...filters,[h.hero]:views[event.actor].rows}:filters,opposing=summaries(perceived,ctx,event.actor);
   const update=updateBelief(filters[event.actor],ctx,event,opposing);filters[event.actor]=update.rows;counts[event.actor]++;losses[event.actor]+=update.logLoss;
   trainResponse(responses[event.actor],ctx,update,event);
   if(event.actor===h.hero)for(const view of Object.values(views)){const vc={...ctx,responseModel:view.model},u=updateBelief(view.rows,vc,event,opposing);view.rows=u.rows;view.count++;view.loss+=u.logLoss;trainResponse(view.model,vc,u,event);}
  }
  if(event.type==='show'&&event.cards?.length===2){
   for(const name of Object.keys(filters))filters[name]=conditionCards(filters[name],name===event.actor?[]:event.cards,name===event.actor?event.cards:null);
   for(const view of Object.values(views))view.rows=conditionCards(view.rows,event.actor===h.hero?[]:event.cards,event.actor===h.hero?event.cards:null);
  }
 }
 return {filters,views,counts,losses,responses};
}
const memoryCache=new Map(),identities=new WeakMap();let nextIdentity=1;
function learningJob(hands,before){
 if(before?.memoryStart)return {selected:[],keys:[],start:0,value:structuredClone(before.memoryStart)};
 const selected=hands.filter(h=>(!h.live||h.live.complete)&&!h.warnings.length&&(!before||beforeHand(h,before))).sort((a,b)=>beforeHand(a,b)?-1:beforeHand(b,a)?1:0).slice(-200);
 const keys=selected.map(h=>{if(!identities.has(h))identities.set(h,nextIdentity++);return identities.get(h);}),job={selected,keys,start:0,value:{profiles:Object.create(null),images:Object.create(null),hands:0}};
 for(let i=selected.length;i>0;i--){const cached=memoryCache.get(keys.slice(0,i).join(','));if(cached){job.start=i;job.value=structuredClone(cached);break;}}return job;
}
export function freshMemory(){return {profiles:Object.create(null),images:Object.create(null),hands:0};}
export function restoreMemory(value){
 if(!value||!Number.isInteger(value.hands)||value.hands<0||value.hands>1000000)throw Error('Invalid compact memory.');
 const out=freshMemory();out.hands=value.hands;
 for(const kind of ['profiles','images']){
  if(!value[kind]||typeof value[kind]!=='object'||Array.isArray(value[kind])||Object.keys(value[kind]).length>500)throw Error('Invalid memory profiles.');
  for(const [key,r] of Object.entries(value[kind])){
   if(key.length>520||!Array.isArray(r.posterior)||r.posterior.length!==4||r.posterior.some(p=>!Number.isFinite(p)||p<0)||Math.abs(r.posterior.reduce((a,b)=>a+b,0)-1)>1e-6||![r.hands,r.actions].every(n=>Number.isInteger(n)&&n>=0)||!Number.isFinite(r.logLoss)||r.logLoss<0)throw Error('Invalid memory record.');
   const model=r.response;if(!model||!Number.isInteger(model.actions)||model.actions<0||!Number.isFinite(model.logLoss)||!model.contexts||Object.keys(model.contexts).length>64)throw Error('Invalid response memory.');
   for(const [context,c] of Object.entries(model.contexts)){
    if(!/^(Preflop\/(open|reraise|UTG|HJ|CO|BTN|BTN\/SB|SB|BB)|(Flop|Turn|River)\/(free|small|medium|large))$/.test(context))throw Error('Invalid response situation.');
    if(!Number.isInteger(c.n)||c.n<0||!Number.isFinite(c.logLoss)||!c.theta||!c.counts)throw Error('Invalid response context.');
    for(const group of ['fold','check','call','bet'])if(!Number.isFinite(c.theta[group])||Math.abs(c.theta[group])>4||!Number.isFinite(c.counts[group])||c.counts[group]<0||c.recent&&(!Number.isFinite(c.recent[group])||c.recent[group]<0))throw Error('Invalid response weights.');
    if(c.weights!==undefined&&(!c.weights||typeof c.weights!=='object'||Object.keys(c.weights).some(k=>!['fold','check','call','bet'].includes(k))||['fold','check','call','bet'].some(k=>!Array.isArray(c.weights[k])||c.weights[k].length!==RESPONSE_FEATURES.length||c.weights[k].some(v=>!Number.isFinite(v)||Math.abs(v)>4))))throw Error('Invalid response feature weights.');
    if(c.precision!==undefined&&(!c.precision||typeof c.precision!=='object'||['fold','check','call','bet'].some(g=>!Array.isArray(c.precision[g])||c.precision[g].length!==RESPONSE_FEATURES.length+1||c.precision[g].some(v=>!Number.isFinite(v)||v<4||v>10000))))throw Error('Invalid behavioral posterior precision.');
    if(c.weight!==undefined&&(!Number.isFinite(c.weight)||c.weight<0)||c.recentLoss!==undefined&&(!Number.isFinite(c.recentLoss)||c.recentLoss<0))throw Error('Invalid recent memory.');
   }
   out[kind][key]=structuredClone(r);
  }
 }
 return out;
}
function absorbHand(value,h){
 const {profiles,images}=value,observed=processHand(h,h.events.length,profiles,images);
 for(const p of h.players)finalize(record(profiles,playerKey(h,p)),observed.filters[p.name],observed.counts[p.name],observed.losses[p.name],observed.responses[p.name]);
 for(const v of Object.values(observed.views))finalize(record(images,v.key),v.rows,v.count,v.loss,v.model);
 value.hands++;
}
export function completeMemory(h,hands=[]){
 if(h.live&&!h.live.complete||h.warnings.length)throw Error('Complete and reconcile this hand before carrying memory forward.');
 const value=learnMemory(hands,h);absorbHand(value,h);return value;
}
function learnOne(job,i){
 absorbHand(job.value,job.selected[i]);memoryCache.set(job.keys.slice(0,i+1).join(','),structuredClone(job.value));if(memoryCache.size>256)memoryCache.delete(memoryCache.keys().next().value);
}
export function learnMemory(hands,before){const job=learningJob(hands,before);for(let i=job.start;i<job.selected.length;i++)learnOne(job,i);return job.value;}
export const learnMemoryAsync=async (hands,before,onProgress=()=>{},cancel=()=>false)=>{const job=learningJob(hands,before);for(let i=job.start;i<job.selected.length;i++){if(cancel())return null;onProgress('Fitting player responses · hand '+(i+1)+' / '+job.selected.length);await new Promise(r=>setTimeout(r,0));learnOne(job,i);}return job.value;};
export function nodeBeliefs(hands,h,step,priors={}){
 const learned=learnMemory(hands,h),node=processHand(h,step,learned.profiles,learned.images,priors),board=snapshot(h,step).board,heroCards=h.players.find(p=>p.name===h.hero).cards;
 const ranges=Object.create(null);for(const p of h.players)ranges[p.name]=conditionCards(node.filters[p.name],[...board,...(p.name===h.hero?[]:heroCards)]);
 return {...node,ranges,learned};
}
export function sampleHolding(rows,blocked,random){const valid=rows.filter(r=>r.cards.every(c=>!blocked.includes(c)));if(!valid.length)throw Error('No compatible sampled holding.');return drawWeighted(valid,random);}
