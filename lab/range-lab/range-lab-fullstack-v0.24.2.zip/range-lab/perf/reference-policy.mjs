import {snapshot,cashStrength,evaluate,bucket,RANKS} from './reference-poker.mjs';
import {responseFeatures,actionFeatures,responseEnsemble} from './reference-adaptation.mjs';

// Legacy saved-memory labels. Active inference uses continuous coefficients.
export const POLICY_VERSION=5;
export const TYPES=[
 {id:'neutral',label:'Neutral',tight:0,agg:1,bluff:1},
 {id:'tight',label:'Tight',tight:.065,agg:.85,bluff:.45},
 {id:'loose',label:'Loose / passive',tight:-.085,agg:.45,bluff:.6},
 {id:'aggressive',label:'Aggressive',tight:-.025,agg:1.65,bluff:1.9}
];
export const TYPE_PRIOR=[.55,.15,.15,.15];
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const sigmoid=x=>1/(1+Math.exp(-clamp(x,-30,30)));
export function seeded(seed=719){let n=seed>>>0;return ()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};}
export function drawWeighted(rows,random=Math.random,key='prob'){let x=random()*rows.reduce((n,r)=>n+r[key],0);for(const r of rows){x-=r[key];if(x<=0)return r;}return rows.at(-1);}

// Extract only the public prefix. Never inspect a future event or a player's cards.
export function publicContext(h,step,actor){
 const s=snapshot(h,step),acted={},pending=new Set(h.players.map(p=>p.name));let level=h.bb,minRaise=h.bb,street='Preflop';
 const contrib=Object.fromEntries(h.players.map(p=>[p.name,0]));let raises=0;
 for(const e of h.events.slice(0,step)){
  if(e.type==='street'){street=e.street;level=0;minRaise=h.bb;raises=0;for(const k of Object.keys(contrib))contrib[k]=0;for(const k of Object.keys(acted))delete acted[k];pending.clear();s.players.forEach(p=>pending.add(p.name));}
  if(e.type==='post'&&!/ante/.test(e.kind||'')){contrib[e.actor]+=e.amount;level=Math.max(level,contrib[e.actor]);if(/straddle/.test(e.kind||''))minRaise=Math.max(minRaise,e.amount);}
  if(e.type==='action'){
   if(e.action==='raises'||e.action==='bets'){const to=e.action==='raises'?e.to:contrib[e.actor]+e.amount;const increment=to-level;minRaise=Math.max(minRaise,increment);level=Math.max(level,to);contrib[e.actor]=to;pending.clear();s.players.forEach(p=>{if(p.name!==e.actor)pending.add(p.name);});raises++;}
   else{if(e.action==='calls')contrib[e.actor]+=e.amount;pending.delete(e.actor);}
   acted[e.actor]={level,minRaise,checked:e.action==='checks'};
  }
  if(e.type==='return')contrib[e.actor]-=e.amount;
 }
 const players=s.players.map(p=>({name:p.name,seat:p.seat,position:p.position,stack:p.stack,streetContribution:p.streetContribution,committed:p.committed,folded:p.folded}));
 return {players,board:[...s.board],pot:s.pot,street,bb:h.bb,button:h.button,actor,level,minRaise,raises,acted,pending:[...pending].filter(n=>players.some(p=>p.name===n&&!p.folded&&p.stack>0))};
}
export function legalActions(ctx){
 const p=ctx.players.find(p=>p.name===ctx.actor);if(!p||p.folded||!p.stack)return [];
 const others=ctx.players.filter(v=>v.name!==p.name&&!v.folded),level=ctx.level,owed=Math.max(0,level-p.streetContribution),call=Math.min(owed,p.stack),max=p.streetContribution+p.stack,previous=ctx.acted[p.name];
 const canRaise=(!previous||previous.checked||level-previous.level>=previous.minRaise)&&max>level&&others.some(v=>v.stack>0);
 const out=owed?[{id:'fold',kind:'fold',label:'Fold',cost:0},{id:'call',kind:'call',label:'Call '+(call/ctx.bb).toFixed(2)+' BB',cost:call}]:[{id:'check',kind:'check',label:'Check',cost:0}];
 if(!canRaise)return out;
 const min=level+ctx.minRaise,cover=Math.max(...others.map(v=>v.stack+v.streetContribution)),cap=Math.min(max,Math.max(min,cover));
 const desired=ctx.street==='Preflop'?(ctx.raises?[2.5,3,4].map(n=>n*level):[2,2.5,3,4].map(n=>n*ctx.bb)):[.33,.5,.75,1,1.5].map(n=>p.streetContribution+call+n*(ctx.pot+call));
 const seen=new Set();for(const request of [min,...desired,cap]){const to=Math.min(cap,Math.max(Math.min(min,max),Math.round(request)));if(seen.has(to))continue;seen.add(to);out.push({id:'bet-'+to,kind:'bet',to,cost:to-p.streetContribution,label:(level?'Raise':'Bet')+' to '+(to/ctx.bb).toFixed(2)+' BB',allIn:to===max});}
 return out;
}
const signals=new Map();
export function handSignal(cards,board){
 if(!board.length)return cashStrength(cards);
 const key=cards.slice().sort().join('')+'|'+board.slice().sort().join('');if(signals.has(key))return signals.get(key);
 const e=evaluate([...cards,...board]),be=evaluate(board),b=bucket(cards,board),ranks=cards.map(c=>14-RANKS.indexOf(c[0]));
 let value=[.23,.59,.76,.86,.91,.95,.98,.995,.999][e.category];
 // A shared board hand is not private value. Top pair and overpairs differ from bottom pair.
 if(e.category<=be.category&&b!=='made'&&b!=='strong')value=.28+.012*Math.max(...ranks);
 if(e.category===1&&b==='made'){const boardRanks=board.map(c=>14-RANKS.indexOf(c[0]));const paired=Math.max(...ranks.filter(r=>boardRanks.includes(r)),cards[0][0]===cards[1][0]?ranks[0]:0);value=.48+.22*clamp((paired-Math.min(...boardRanks)+2)/(Math.max(...boardRanks)-Math.min(...boardRanks)+2));}
 if(b==='draw')value=Math.max(value,.48);
 value=clamp(value);if(signals.size>60000)signals.clear();signals.set(key,value);return value;
}

// A single normalized distribution over all available actions for each holding.
// The range summary and image are public beliefs, never the other actual holding.
export function actionPolicy(ctx,cards,type=0,belief={}){
 const actions=ctx.actions||legalActions(ctx),p=ctx.players.find(p=>p.name===ctx.actor),t=ctx.legacyStyles?(TYPES[type]||TYPES[0]):TYPES[0];if(!actions.length)return [];
 const signal=handSignal(cards,ctx.board),owed=Math.max(0,ctx.level-p.streetContribution),call=Math.min(owed,p.stack),uncalled=ctx.players.length===2?Math.max(0,owed-call):0,price=call/Math.max(1,ctx.pot-uncalled+call),commit=call/Math.max(1,p.stack),pre=ctx.street==='Preflop',unopened=pre&&!ctx.raises;
 let range=belief.strength??(pre?.62:.54),image=belief.aggression??1;
 if(belief.byCard){const a=belief.byCard[cards[0]]||[0,0,0],b=belief.byCard[cards[1]]||[0,0,0],both=belief.byCombo[cards.slice().sort().join('')]||[0,0,0],mass=1-a[0]-b[0]+both[0];if(mass>1e-10){range=(range-a[1]-b[1]+both[1])/mass;image=(image-a[2]-b[2]+both[2])/mass;}}
 const pressure=.26*(range-(pre?.62:.54))-.018*(image-1);
 const position=({UTG:.76,HJ:.73,CO:.66,BTN:.57,'BTN/SB':.47,SB:.61,BB:.52})[p.position]??.72;
 let threshold=unopened?position:pre?.63+.20*Math.max(0,price-.2)+.10*commit+.22*(1-Math.exp(-Math.max(0,Math.log(Math.max(1,ctx.level/ctx.bb)/2.5)))):.31+.75*price+.15*commit;
 // Heads-up BB defense of a first open is a distinct price/position situation.
 // The earlier generic continuation cutoff discarded cheap defenses against a
 // wide SB range. Use the added call price, commitment and large-size pressure;
 // do not change six-player inference, re-raises or postflop rules. Coefficients
 // remain explicit heuristics, not equilibrium frequencies or measured pool data.
 const headsUpBlindDefense=pre&&ctx.players.length===2&&p.position==='BB'&&ctx.raises===1&&owed>0;
 if(headsUpBlindDefense)threshold=.24+.60*price+.20*commit+.22*(1-Math.exp(-Math.max(0,ctx.level/ctx.bb-3)/8));
 threshold+=t.tight+pressure;
 const continuation=owed?sigmoid((signal-threshold)/(pre?.052:.095)):1;
 const aggression=clamp((unopened?continuation*.91:sigmoid((signal-(pre?.88:.76)-pressure-t.tight)/.065)*.79)*t.agg+(signal<(pre?.68:.48)?.025*t.bluff:0),.001,.97);
 const bets=actions.filter(a=>a.kind==='bet');
 const sizeWeights=bets.map(a=>{
  const ratio=pre?a.to/ctx.bb:(a.cost-owed)/Math.max(ctx.bb,ctx.pot+owed),ideal=pre?(unopened?2.5:3*ctx.level/ctx.bb):signal>.85?.85:.5;
  const stackFrac=a.cost/Math.max(1,p.stack),excess=pre?Math.max(0,Math.log(ratio/ideal)):Math.max(0,ratio-1);
  const sizePenalty=pre?excess*(signal>.965?1.2:signal>.9?3:6):excess*(signal>.91?1.3:5);
  return Math.exp(-1.9*Math.abs(Math.log(Math.max(.01,ratio)/ideal))-sizePenalty-3*Math.max(0,stackFrac-.5)*Math.max(0,.93-signal)*5)+1e-9;
 });
 const z=sizeWeights.reduce((n,x)=>n+x,0),betMass=bets.length?Math.min(continuation,aggression):0;let j=0;
 const rows=actions.map(a=>({...a,prob:a.kind==='fold'?1-continuation:a.kind==='call'||a.kind==='check'?continuation-betMass:betMass*sizeWeights[j++]/z}));
 // A small explicit lapse likelihood prevents one observation eliminating a hand.
 const features=responseFeatures(ctx,signal,ctx.board.length>0&&bucket(cards,ctx.board)==='draw',range,image);
 const featured=rows.map(a=>({...a,features:actionFeatures(features,ctx,a)})),ensemble=responseEnsemble(ctx.responseModel,ctx,featured);
 return featured.map((a,i)=>{const modelProb=ensemble.reduce((s,row)=>s+row[i],0)/ensemble.length;return {...a,modelProb,prob:.999*modelProb+.001/rows.length,ensemble};});
}
export function observedAction(rows,event){
 const kind=({folds:'fold',checks:'check',calls:'call',bets:'bet',raises:'bet'})[event.action]||event.kind;
 const candidates=rows.filter(a=>a.kind===kind);if(kind!=='bet')return candidates[0];
 const to=event.to??event.amount;return candidates.sort((a,b)=>Math.abs(Math.log(a.to/to))-Math.abs(Math.log(b.to/to)))[0];
}
