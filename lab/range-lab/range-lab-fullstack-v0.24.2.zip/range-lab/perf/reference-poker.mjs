export const RANKS='AKQJT98765432', SUITS='shdc';
export const CLASSES=Array.from(RANKS,(r,i)=>Array.from(RANKS,(s,j)=>i===j?r+s:i<j?r+s+'s':s+r+'o')).flat();
export const DECK=Array.from(RANKS,r=>Array.from(SUITS,s=>r+s)).flat();
export const cents=s=>Math.round(Number(String(s).replace(/[$€,]/g,''))*100);
const clone=o=>JSON.parse(JSON.stringify(o));
export function handClass(a,b){const i=RANKS.indexOf(a[0]),j=RANKS.indexOf(b[0]);return i===j?a[0]+b[0]:(i<j?a[0]+b[0]:b[0]+a[0])+(a[1]===b[1]?'s':'o');}
export const ALL_COMBOS=DECK.flatMap((a,i)=>DECK.slice(i+1).map(b=>({cards:[a,b],key:a+b,cls:handClass(a,b)})));
function positions(players,button){
 const sorted=[...players].sort((a,b)=>a.seat-b.seat),i=sorted.findIndex(p=>p.seat===button);
 const clockwise=sorted.slice(i<0?0:i).concat(sorted.slice(0,i<0?0:i));
 const n=clockwise.length;
 const early={2:[],3:[],4:['CO'],5:['HJ','CO'],6:['UTG','HJ','CO'],7:['UTG','LJ','HJ','CO'],8:['UTG','UTG+1','LJ','HJ','CO']}[n]||[];
 const labels=n===2?['BTN/SB','BB']:['BTN','SB','BB',...early];
 clockwise.forEach((p,j)=>p.position=labels[j]||'EP');
}
export function parseHistory(text,source='Imported history'){
 if(typeof text!=='string'||text.length>25_000_000)throw Error('Choose a text history smaller than 25 MB.');
 const chunks=text.replace(/^\uFEFF/,'').split(/(?=^Poker Hand #)/m).filter(s=>s.trim());
 const hands=[],errors=[];
 for(const raw of chunks){try{hands.push(parseHand(raw.trim(),source));}catch(e){errors.push(e.message);}}
 if(!hands.length)throw Error(errors[0]||'No GG Poker Hand headers found. Import an exported GG .txt file.');
 return {hands,errors};
}
export function parseHand(raw,source){
 const lines=raw.split(/\r?\n/),header=lines[0].match(/^Poker Hand #([^:]+): Hold'em No Limit \(\$([\d.,]+)\/\$([\d.,]+)\) - (.+)$/);
 if(!header)throw Error('Unsupported header. This prototype supports GG dollar-denominated NLH cash exports.');
 const table=raw.match(/^Table '(.+)' (\d+)-max Seat #(\d+) is the button/m);
 if(!table)throw Error(header[1]+': missing table or button.');
 if(/\*\*\* (?:FIRST|SECOND)|cashout|insurance|run it twice/i.test(raw))throw Error(header[1]+': multiple runouts, cashout, or insurance is not supported yet.');
 const h={id:header[1],date:header[4],table:table[1],maxSeats:+table[2],button:+table[3],sb:cents(header[2]),bb:cents(header[3]),source,raw,players:[],events:[],fees:{},warnings:[],hero:'Hero',totalPot:null};
 for(const l of lines){const m=l.match(/^Seat (\d+): (.+) \(\$([\d.,]+) in chips\)/);if(m)h.players.push({seat:+m[1],name:m[2],stack:cents(m[3]),cards:[]});}
 if(h.players.length<2)throw Error(h.id+': fewer than two seated players.');
 positions(h.players,h.button);
 let street='Preflop',summary=false;
 for(const l of lines.slice(1)){
  let m;
  if(l.startsWith('*** SUMMARY')){summary=true;continue;}
  if(summary){
   if((m=l.match(/^Total pot \$([\d.,]+)/))) {h.totalPot=cents(m[1]);for(const f of l.matchAll(/\|\s*(\w+)\s+\$([\d.,]+)/g))h.fees[f[1]]=cents(f[2]);}
   continue;
  }
  if((m=l.match(/^\*\*\* (FLOP|TURN|RIVER) \*\*\*/))){street=m[1][0]+m[1].slice(1).toLowerCase();const cards=[...l.matchAll(/\[([^\]]+)\]/g)].flatMap(x=>x[1].split(' '));h.events.push({type:'street',street,board:cards,text:l});continue;}
  if((m=l.match(/^Dealt to (.+) \[([^\]]+)\]/))){const p=h.players.find(p=>p.name===m[1]);if(p){p.cards=m[2].split(' ');h.hero=p.name;}continue;}
  if((m=l.match(/^(.+): (posts small blind|posts big blind|posts the ante|posts ante|straddle|posts straddle) \$([\d.,]+)/))){h.events.push({type:'post',actor:m[1],amount:cents(m[3]),kind:m[2],street,text:l});continue;}
  if((m=l.match(/^Uncalled bet \(\$([\d.,]+)\) returned to (.+)$/))){h.events.push({type:'return',actor:m[2],amount:cents(m[1]),street,text:l});continue;}
  if((m=l.match(/^(.+) collected \$([\d.,]+) from (.+)$/))){h.events.push({type:'collect',actor:m[1],amount:cents(m[2]),street,text:l});continue;}
  if((m=l.match(/^(.+): shows \[([^\]]+)\]/))){h.events.push({type:'show',actor:m[1],cards:m[2].split(' '),street,text:l});continue;}
  if((m=l.match(/^(.+): (folds|checks|calls|bets|raises)(.*)$/))){
   const amount=m[3].match(/\$([\d.,]+)/),to=m[3].match(/ to \$([\d.,]+)/);
   h.events.push({type:'action',actor:m[1],action:m[2],amount:amount?cents(amount[1]):0,to:to?cents(to[1]):null,allIn:/all-in/.test(l),street,text:l});continue;
  }
  if(/^.+: (posts|straddle|calls|bets|raises)/.test(l))h.warnings.push('Unrecognized action: '+l);
 }
 if(h.totalPot===null)throw Error(h.id+': incomplete hand; summary total is missing.');
 if(h.warnings.length)throw Error(h.id+': '+h.warnings[0]);
 const snap=initialState(h);let cumulative=0,collected=0;
 for(const [i,event] of h.events.entries()){
  const before=clone(snap);applyEvent(snap,event);
  const p=before.players.find(p=>p.name===event.actor),after=snap.players.find(p=>p.name===event.actor);
  event.index=i;event.potBefore=before.pot;event.facing=p?Math.max(0,...before.players.map(p=>p.streetContribution))-p.streetContribution:0;
  event.contribution=event.type==='post'||event.type==='action'?(after?.committed||0)-(p?.committed||0):event.type==='return'?-event.amount:0;
  cumulative+=event.contribution;if(event.type==='collect')collected+=event.amount;
  if(event.contribution<0&&event.type!=='return')h.warnings.push('Negative contribution at action '+i);
  if(after?.stack<0)h.warnings.push('Negative stack at action '+i);
 }
 h.totalFees=Object.values(h.fees).reduce((a,b)=>a+b,0);h.collected=collected;
 if(cumulative!==h.totalPot)h.warnings.push(`Pot mismatch: ledger ${cumulative/100}, summary ${h.totalPot/100}.`);
 if(collected+h.totalFees!==h.totalPot)h.warnings.push('Awards plus deductions do not match the summary pot.');
 h.heroNet=snap.players.find(p=>p.name===h.hero)?.stack-(h.players.find(p=>p.name===h.hero)?.stack||0);
 h.showdown=h.events.some(e=>e.type==='show');h.vpip=h.events.some(e=>e.street==='Preflop'&&e.type==='action'&&e.actor===h.hero&&['calls','raises','bets'].includes(e.action));
 return h;
}
export function initialState(h){return {street:'Preflop',board:[],pot:0,players:h.players.map(p=>({...clone(p),known:p.name===h.hero?p.cards:[],stack:p.stack,committed:0,streetContribution:0,folded:false,lastAction:''})),lastRaise:h.bb};}
export function applyEvent(s,e){
 const p=s.players.find(p=>p.name===e.actor);
 if(e.type==='street'){s.street=e.street;s.board=[...e.board];s.lastRaise=0;s.players.forEach(p=>{p.streetContribution=0;p.lastAction='';});return;}
 if(!p)return;
 if(e.type==='post'||e.type==='action'){
  let delta=0;
  if(e.type==='post')delta=e.amount;
  else if(e.action==='raises')delta=e.to-p.streetContribution;
  else if(['bets','calls'].includes(e.action))delta=e.amount;
  const top=Math.max(...s.players.map(p=>p.streetContribution));
  p.stack-=delta;p.committed+=delta;s.pot+=delta;
  if(!/ante/.test(e.kind||''))p.streetContribution+=delta;
  if(p.streetContribution>top&&e.action!=='calls')s.lastRaise=Math.max(s.lastRaise,p.streetContribution-top);
  if(e.action==='folds')p.folded=true;
  p.lastAction=e.type==='post'?(/straddle/.test(e.kind)?'Straddle':'Blind'):(e.action+(e.allIn?' · all-in':''));
 }else if(e.type==='return'){p.stack+=e.amount;p.committed-=e.amount;p.streetContribution-=e.amount;s.pot-=e.amount;p.lastAction='Uncalled bet returned';}
 else if(e.type==='collect'){p.stack+=e.amount;s.pot-=e.amount;p.lastAction='Collected';}
 else if(e.type==='show'){p.known=e.cards;}
}
export function snapshot(h,step){const s=initialState(h);h.events.slice(0,step).forEach(e=>applyEvent(s,e));if(step>=h.events.length)s.pot=Math.max(0,s.pot-(h.totalFees||0));return s;}
export function decisionIndices(h){const ds=h.events.flatMap((e,i)=>e.type==='action'&&e.actor===h.hero?[i]:[]);if(h.live?.actor===h.hero&&!h.live.complete)ds.push(h.events.length);return ds;}
export function playerKey(h,p){return p.memoryKey||(p.name===h.hero?`${p.name} [${h.source}]`:p.name);}
export function memory(hands,before=null){
 const stats=Object.create(null);
 for(const h of [...hands].sort((a,b)=>a.live?.spec.sessionId&&a.live.spec.sessionId===b.live?.spec.sessionId?a.live.spec.handNumber-b.live.spec.handNumber:a.date.localeCompare(b.date)||a.id.localeCompare(b.id))){
  if(h.live&&!h.live.complete)continue;
  if(before){const sameSession=h.live?.spec.sessionId&&h.live.spec.sessionId===before.live?.spec.sessionId;if(sameSession?h.live.spec.handNumber>=before.live.spec.handNumber:h.date>before.date||(h.date===before.date&&h.id>=before.id))continue;}
  for(const p of h.players){
   const key=playerKey(h,p);
   const v=stats[key]??={key,name:p.name,hero:p.name===h.hero,hands:0,vpip:0,pfr:0,threeBet:0,threeBetOpp:0,cbet:0,cbetOpp:0,foldCbet:0,foldCbetOpp:0,net:0,shows:[],source:h.source};
   v.hands++;const acts=h.events.filter(e=>e.type==='action'&&e.actor===p.name&&e.street==='Preflop');
   if(acts.some(e=>['calls','bets','raises'].includes(e.action)))v.vpip++;
   if(acts.some(e=>e.action==='raises'))v.pfr++;
   let raises=0,seen3=false;
   for(const e of h.events.filter(e=>e.type==='action'&&e.street==='Preflop')){if(e.actor===p.name&&raises===1&&!seen3){v.threeBetOpp++;if(e.action==='raises')v.threeBet++;seen3=true;}if(e.action==='raises')raises++;}
   const pfRaise=h.events.filter(e=>e.street==='Preflop'&&e.action==='raises').at(-1);
   const flop=h.events.filter(e=>e.street==='Flop'&&e.type==='action');
   const firstBet=flop.find(e=>['bets','raises'].includes(e.action));
   if(pfRaise?.actor===p.name){const own=flop.find(e=>e.actor===p.name);if(own&&(!firstBet||own.index<=firstBet.index)){v.cbetOpp++;if(own.action==='bets')v.cbet++;}}
   if(firstBet&&firstBet.actor===pfRaise?.actor&&firstBet.actor!==p.name){const faced=flop.find(e=>e.actor===p.name&&e.index>firstBet.index);const interveningRaise=flop.some(e=>e.action==='raises'&&e.index>firstBet.index&&e.index<(faced?.index??0));if(faced&&!interveningRaise){v.foldCbetOpp++;if(faced.action==='folds')v.foldCbet++;}}
   const end=snapshot(h,h.events.length).players.find(x=>x.name===p.name);v.net+=end.stack-p.stack;
   const show=h.events.find(e=>e.type==='show'&&e.actor===p.name);if(show)v.shows.push({hand:h.id,date:h.date,cards:show.cards,board:snapshot(h,show.index).board,line:h.events.filter(e=>e.type==='action'&&e.actor===p.name).map(e=>e.street+': '+e.action).join(' → ')});
  }
 }
 return Object.values(stats).sort((a,b)=>b.hands-a.hands);
}
function straightHigh(ranks){const set=new Set(ranks);if(set.has(14))set.add(1);for(let n=14;n>=5;n--)if([0,1,2,3,4].every(d=>set.has(n-d)))return n;return 0;}
export function evaluate(cards){
 const ranks=cards.map(c=>14-RANKS.indexOf(c[0])).sort((a,b)=>b-a),counts=new Map(),suits={};
 for(let i=0;i<cards.length;i++){const r=14-RANKS.indexOf(cards[i][0]);counts.set(r,(counts.get(r)||0)+1);(suits[cards[i][1]]??=[]).push(r);}
 const groups=[...counts].sort((a,b)=>b[1]-a[1]||b[0]-a[0]),flush=Object.values(suits).find(s=>s.length>=5)?.sort((a,b)=>b-a),st=straightHigh(ranks);
 let cat=0,k=ranks.slice(0,5);
 if(flush&&straightHigh(flush)){cat=8;k=[straightHigh(flush)];}
 else if(groups[0]?.[1]===4){cat=7;k=[groups[0][0],...ranks.filter(r=>r!==groups[0][0]).slice(0,1)];}
 else if(groups[0]?.[1]>=3&&groups[1]?.[1]>=2){cat=6;k=[groups[0][0],groups[1][0]];}
 else if(flush){cat=5;k=flush.slice(0,5);}
 else if(st){cat=4;k=[st];}
 else if(groups[0]?.[1]===3){cat=3;k=[groups[0][0],...ranks.filter(r=>r!==groups[0][0]).slice(0,2)];}
 else if(groups[0]?.[1]===2&&groups[1]?.[1]===2){cat=2;const pairs=groups.filter(g=>g[1]===2).map(g=>g[0]).sort((a,b)=>b-a).slice(0,2);k=[...pairs,...ranks.filter(r=>!pairs.includes(r)).slice(0,1)];}
 else if(groups[0]?.[1]===2){cat=1;k=[groups[0][0],...ranks.filter(r=>r!==groups[0][0]).slice(0,3)];}
 let score=cat;for(let i=0;i<5;i++)score=score*15+(k[i]||0);
 return {score,category:cat,name:['High card','One pair','Two pair','Three of a kind','Straight','Flush','Full house','Four of a kind','Straight flush'][cat]};
}
export function bucket(cards,board){
 if(board.length<3){const a=14-RANKS.indexOf(cards[0][0]),b=14-RANKS.indexOf(cards[1][0]);if(a===b&&a>=10||Math.min(a,b)>=12)return 'strong';if(a===b||Math.min(a,b)>=9||Math.max(a,b)===14)return 'made';if(cards[0][1]===cards[1][1]&&Math.abs(a-b)<=3)return 'draw';return 'air';}
 const all=[...cards,...board],e=evaluate(all),be=evaluate(board);
 if(e.category>=2&&e.category>be.category)return 'strong';
 const counts={};all.forEach(c=>counts[c[1]]=(counts[c[1]]||0)+1);
 const r=[...new Set(all.map(c=>14-RANKS.indexOf(c[0])))];if(r.includes(14))r.push(1);
 let straightDraw=false;for(let n=1;n<=10;n++)if(r.filter(x=>x>=n&&x<n+5).length>=4)straightDraw=true;
 if(board.length<5&&(Object.entries(counts).some(([s,n])=>n===4&&cards.some(c=>c[1]===s))||straightDraw&&cards.some(c=>!board.some(b=>b[0]===c[0]))))return 'draw';
 if(e.category>be.category||cards.some(c=>board.some(b=>b[0]===c[0])))return 'made';
 return 'air';
}
export function prior(kind='wide'){
 return Object.fromEntries(CLASSES.map(c=>{const a=14-RANKS.indexOf(c[0]),b=14-RANKS.indexOf(c[1]),pair=c.length===2,suited=c[2]==='s';let w=0;
 if(kind==='all')w=100;else if(kind==='empty')w=0;else if(kind==='tight')w=pair&&a>=7||a===14&&b>=10||a>=12&&b>=11?100:suited&&(a===14||a>=10&&b>=9)?50:0;
 else w=pair||a===14&&suited||a>=11&&b>=9||suited&&Math.abs(a-b)<=2&&b>=5?100:a===14||suited&&a>=12||a>=10&&b>=8?50:0;
 return [c,w];}));
}
export const DEFAULT_RESPONSE={strong:[5,70,25],made:[35,60,5],draw:[25,65,10],air:[70,25,5]};
export function response(bucket_,matrix=DEFAULT_RESPONSE){const row=matrix[bucket_]||DEFAULT_RESPONSE[bucket_],sum=row.reduce((a,b)=>a+b,0);return sum?row.map(x=>x/sum):[1,0,0];}
// Explicit, uncalibrated hand-strength ordering for the general cash baseline.
// These scores are NOT equities, solver frequencies, or measured pool statistics.
export function cashStrength(cards){
 const [a,b]=cards.map(c=>14-RANKS.indexOf(c[0])).sort((x,y)=>y-x),suited=cards[0][1]===cards[1][1];
 if(a===b)return ({14:1,13:.98,12:.955,11:.915,10:.875,9:.835,8:.795,7:.755,6:.715,5:.675,4:.64,3:.61,2:.58})[a];
 if(a===14)return ({13:.94,12:.90,11:.85,10:.79,9:.74,8:.70,7:.665,6:.64,5:.66,4:.64,3:.63,2:.62})[b]-(suited?0:b>=12?.03:.06);
 const broadway=({KQ:.87,KJ:.80,KT:.74,QJ:.81,QT:.75,JT:.77})[RANKS[14-a]+RANKS[14-b]];
 if(broadway!==undefined)return broadway-(suited?0:.07);
 return Math.max(.05,Math.min(.8,.13+.032*a+.021*b+(suited?.065:0)-Math.max(0,a-b-1)*.035));
}
const cashRamp=(value,threshold,width)=>Math.max(0,Math.min(1,(value-threshold+width)/(2*width)));
export function cashResponse({cards,position,aggressorPosition,owed,pot,level,bb,effective,raises=0,canRaise=true,tightness=0,rakePct=5}){
 const strength=cashStrength(cards),size=Math.max(1,level/bb),price=owed/Math.max(1,pot+owed),commit=Math.min(1,owed/Math.max(1,effective));
 const defender=position==='BB'?-.06:position?.includes('SB')?.025:0;
 const opener=['UTG','LJ','HJ'].includes(aggressorPosition)?.04:['BTN','BTN/SB','CO'].includes(aggressorPosition)?-.02:0;
 // Wager size, pot odds and fraction of the effective stack increase the cost
 // of continuing. No coefficients are fitted to a particular stake or room.
 const sizePressure=.28*(1-Math.exp(-Math.max(0,Math.log(size/2.5))/1.2));
 const threshold=Math.min(.965,Math.min(.925,.64+defender+opener+sizePressure+.10*commit+.20*Math.max(0,price-.30)+.015*Math.min(2,raises)+.002*(rakePct-5))+tightness);
 const continuing=owed?cashRamp(strength,threshold,.035):1;
 const valueRaise=cashRamp(strength,Math.min(.99,threshold+.19),.035)*.65;
 const wheelBluff=cards.some(c=>c[0]==='A')&&cards[0][1]===cards[1][1]&&cards.some(c=>'2345'.includes(c[0]))&&size<=4?.04:0;
 const raising=canRaise?Math.min(continuing,Math.max(valueRaise,wheelBluff)):0;
 return [1-continuing,continuing-raising,raising];
}
function cashHistoryLikelihood(h,e,cards,options,context){
 const {s,past}=context,p=s.players.find(p=>p.name===e.actor),aggressor=s.players.find(p=>p.name===past.at(-1)?.actor);
 let likelihood;
 if(!past.length&&e.facing>0){
  const threshold=({UTG:.78,LJ:.77,HJ:.75,CO:.68,BTN:.59,'BTN/SB':.59,SB:.66,BB:.58})[p.position]??.75;
  const opening=cashRamp(cashStrength(cards),threshold+(options.populationTightness||0),.055),limping=opening*.06;
  likelihood=e.action==='raises'?opening*.94:e.action==='calls'?limping:e.action==='folds'?1-opening:1;
 }else{
  const level=Math.max(h.bb,...s.players.map(x=>x.streetContribution)),other=s.players.filter(x=>!x.folded&&x.name!==p.name),effective=Math.min(p.stack+p.streetContribution,Math.max(...other.map(x=>x.stack+x.streetContribution)));
  const row=cashResponse({cards,position:p.position,aggressorPosition:aggressor?.position,owed:e.facing,pot:s.pot,level,bb:h.bb,effective,raises:Math.max(0,past.length-1),tightness:options.populationTightness||0,rakePct:options.rakePct??5});
  likelihood=e.action==='folds'?row[0]:e.action==='raises'||e.action==='bets'?row[2]:e.action==='checks'?row[0]+row[1]:row[1];
 }
 return Math.max(.005,likelihood);
}
export function rangeAt(h,step,actor,weights,useLine=true,forHero=false,options={}){
 const s=snapshot(h,step),hero=h.players.find(p=>p.name===h.hero),blocked=new Set([...s.board,...(forHero?[]:hero.cards)]);
 const relevant=h.events.slice(0,step).filter(e=>e.type==='action'&&e.actor===actor);
 const actionContexts=new Map(relevant.map(e=>[e.index,{s:snapshot(h,e.index),past:h.events.slice(0,e.index).filter(x=>x.street==='Preflop'&&x.type==='action'&&['bets','raises'].includes(x.action))}]));
 const postHistory=new Map();
 if(options.postflopModel==='range')for(const e of relevant.filter(e=>e.street!=='Preflop'))postHistory.set(e.index,memoizedPostflopHistory(h,e,options,actionContexts.get(e.index)));
 const rows=[];
 for(const c of ALL_COMBOS){if(c.cards.some(x=>blocked.has(x)))continue;let w=(weights[c.cls]??0)/100;if(!w)continue;
  if(useLine)for(const e of relevant){if(options.preflopModel==='cash'&&e.street==='Preflop'){w*=cashHistoryLikelihood(h,e,c.cards,options,actionContexts.get(e.index));continue;}if(postHistory.has(e.index)){w*=postHistory.get(e.index)(c);continue;}const b=bucket(c.cards,actionContexts.get(e.index).s.board);const facing=e.facing>0;let likelihood;
   if(facing){const v=response(b);likelihood=e.action==='folds'?v[0]:e.action==='calls'?v[1]:e.action==='raises'?v[2]:1;}
   else {const bet={strong:.8,made:.45,draw:.6,air:.2}[b];likelihood=e.action==='checks'?1-bet:['bets','raises'].includes(e.action)?bet:1;}
   w*=likelihood;
  }
  if(w>0)rows.push({...c,weight:w,bucket:bucket(c.cards,s.board)});
 }
 const total=rows.reduce((a,c)=>a+c.weight,0);rows.forEach(c=>c.prob=total?c.weight/total:0);return {rows,total};
}
function rng(seed=20260925){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296;};}
function choose(rows,r){let c=0;const x=r();for(const row of rows){c+=row.prob;if(x<=c)return row;}return rows.at(-1);}
export function evDecision(hand,step){
 const s=snapshot(hand,step),hero=s.players.find(p=>p.name===hand.hero),live=s.players.filter(p=>!p.folded&&p.name!==hand.hero),villain=live[0];
 if(!hero?.cards?.length)throw Error('Hero cards are missing.');
 if(hero.folded)throw Error('Choose a decision before Hero folds.');
 const preflop=s.street==='Preflop';
 if(!live.length||(!preflop&&live.length!==1))throw Error('Postflop EV comparison needs a heads-up decision. Preflop supports up to six players.');
 if(preflop&&live.length>5)throw Error('Preflop EV supports up to six active players.');
 const liveDecision=!!hand.live&&!hand.live.complete&&step===hand.events.length&&hand.live.actor===hero.name;
 if(!liveDecision&&(hand.events[step]?.type!=='action'||hand.events[step]?.actor!==hero.name))throw Error('Select a Hero decision using “Next decision”.');
 if(hand.warnings.length)throw Error('This hand has an accounting warning; EV comparison is disabled.');
 if(!hero.stack)throw Error('Hero is already all-in.');
 const history=initialState(hand),acted=Object.create(null);let previous=null,minRaise=hand.bb,pending=new Set(hand.players.map(p=>p.name));
 for(const event of hand.events.slice(0,step)){
  const oldLevel=Math.max(...history.players.map(p=>p.streetContribution));
  applyEvent(history,event);
  const newLevel=Math.max(...history.players.map(p=>p.streetContribution));
  if(event.type==='street'){previous=null;minRaise=hand.bb;for(const name of Object.keys(acted))delete acted[name];pending=new Set(history.players.filter(p=>!p.folded&&p.stack).map(p=>p.name));}
  if(event.type==='post'&&/straddle/.test(event.kind||''))minRaise=Math.max(minRaise,event.amount);
  if(event.type==='action'){
   if(newLevel>oldLevel&&['bets','raises'].includes(event.action)){minRaise=Math.max(minRaise,newLevel-Math.max(oldLevel,history.street==='Preflop'?hand.bb:0));pending=new Set(history.players.filter(p=>p.name!==event.actor&&!p.folded&&p.stack&&p.streetContribution<newLevel).map(p=>p.name));}
   else pending.delete(event.actor);
   acted[event.actor]={checked:event.action==='checks',level:newLevel,minRaise};
   if(event.actor===hero.name)previous=acted[event.actor];
  }
 }
 const bringIn=preflop&&[hero,...live].filter(p=>p.stack>0).length>1?Math.max(hand.bb,...hand.events.slice(0,step).filter(e=>e.type==='post'&&/straddle/.test(e.kind||'')).map(e=>e.amount)):0;
 const level=liveDecision?hero.streetContribution+hand.live.toCall:Math.max(bringIn,...s.players.map(p=>p.streetContribution));
 const minTo=liveDecision?hand.live.minTo:level+minRaise,maxTo=hero.streetContribution+hero.stack;
 const reopened=!previous||previous.checked||level-previous.level>=previous.minRaise;
 const canRaise=liveDecision?hand.live.canRaise:reopened&&maxTo>level&&live.some(p=>p.stack>0);
 const P=s.pot/100,H=hero.stack/100,V=villain.stack/100,facing=Math.max(0,level-hero.streetContribution)/100,C=preflop?Math.min(H,facing):facing;
 if(C>H+1e-8)throw Error('Short all-in calls with unmatched contributions are not modeled postflop.');
 const raises=hand.events.slice(0,step).filter(e=>e.street==='Preflop'&&e.type==='action'&&['raises','bets'].includes(e.action)).length;
 return {s,hero,villain,opponents:live,P,H,V,C,facing,level,minTo,maxTo,canRaise,pending,acted,minRaise,preflop,raises,aggressiveName:preflop?(raises===0?'Open raise':raises===1?'3-bet':raises===2?'4-bet':(raises+2)+'-bet'):level?'Raise':'Bet'};
}
export function actionCandidates({hand,step,config}){
 const d=evDecision(hand,step),{hero,opponents,P,C,minTo,maxTo,canRaise,aggressiveName}=d,actions=[];
 if(C)actions.push({id:'fold',line:'fold',label:'Fold',detail:'No further investment'});
 actions.push({id:'passive',line:'passive',label:C?(d.preflop&&!d.raises?(hero.streetContribution?'Complete':'Limp'):'Call')+' $'+C.toFixed(2):'Check',detail:C===d.H?'All-in call':'Current continuation rule'});
 if(!canRaise)return actions;
 // A covering wager may need to exceed the opponent's stack to be a legal full raise.
 // Deduplicate by matched investment: returned chips do not create a new EV route.
 const cover=Math.max(...opponents.map(p=>p.streetContribution+p.stack)),cap=Math.min(maxTo,Math.max(minTo,cover)),seen=new Set();
 const preflopSizes=d.raises?[2.5,3,3.5,4].map(m=>[Math.round(d.level*m),m+'× current raise']):[2,2.2,2.5,3,4].map(m=>[Math.round(hand.bb*m),m+' BB open']);
 const sizes=[[minTo,'Minimum'],...(d.preflop?preflopSizes:[]),...[1/3,.5,.75,1,1.5].map(f=>[hero.streetContribution+Math.round(100*(C+f*(P+C))),Math.round(f*100)+'% pot'+(C?' after calling':'')]),[cents(config.betTo),'Custom size'],[cap,'Effective stack']];
 for(const [requested,source] of sizes){
  const to=Math.min(cap,Math.max(Math.min(minTo,maxTo),requested));
  const matched=Math.min(to-hero.streetContribution,hero.stack,cover-hero.streetContribution);
  if(!Number.isFinite(to)||seen.has(matched))continue;seen.add(matched);
  actions.push({id:'wager-'+to,line:'aggressive',betTo:to/100,investment:matched/100,label:aggressiveName+' to $'+(to/100).toFixed(2),detail:to===maxTo?'All-in':to>=cover?'Covers field':source});
 }
 return actions;
}
export function rankActionResults(results){
 const all=[...results].sort((a,b)=>b.ev-a.ev||a.order-b.order),best=all[0]?.ev||0;
 return {tested:all.length,actions:all.slice(0,5).map((a,i)=>({...a,rank:i+1,gap:best-a.ev}))};
}
// Range-conditioned postflop scenario model. These policies are explicit assumptions,
// not an equilibrium solve or a fit to player-pool data. All policy information is
// the player's own cards, public board/action line, and a hypothetical opposing range.
const postClamp=x=>Math.max(0,Math.min(1,x));
function normalizedRows(rows){
 const total=rows.reduce((n,p)=>n+Math.max(0,p.weight??p.prob??0),0);
 return total?rows.map(p=>({...p,key:p.key||p.cards.join(''),cls:p.cls||handClass(...p.cards),prob:Math.max(0,p.weight??p.prob??0)/total})).filter(p=>p.prob>0):[];
}
function postSeed(cards,board){let seed=719;for(const c of [...cards,...board].join(''))seed=(Math.imul(seed,31)+c.charCodeAt(0))>>>0;return seed;}
function rangeSampler(rows){
 const cumulative=[];let sum=0;for(const row of rows){sum+=row.prob;cumulative.push(sum);}
 return random=>{let lo=0,hi=rows.length-1,x=random()*sum;while(lo<hi){const m=(lo+hi)>>1;if(x<cumulative[m])hi=m;else lo=m+1;}return rows[lo];};
}
function runoutShare(cards,other,visible,random){
 const blocked=new Set([...cards,...other,...visible]),available=DECK.filter(c=>!blocked.has(c)),board=[...visible];
 while(board.length<5){const i=Math.floor(random()*available.length);board.push(available[i]);available[i]=available.at(-1);available.pop();}
 const a=evaluate([...cards,...board]).score,b=evaluate([...other,...board]).score;return a>b?1:a===b?.5:0;
}
export function postflopEquity(cards,board,rows,samples=128){
 const blocked=new Set([...cards,...board]),legal=normalizedRows(rows.filter(p=>p.cards.every(c=>!blocked.has(c))).map(p=>({...p,weight:p.prob})));
 if(!legal.length)throw Error('The assumed opposing range has no compatible hands. Adjust the range or betting mix.');
 if(board.length===5){const a=evaluate([...cards,...board]).score;return legal.reduce((q,p)=>{const b=evaluate([...p.cards,...board]).score;return q+p.prob*(a>b?1:a===b?.5:0);},0);}
 const random=rng(postSeed(cards,board)),pick=rangeSampler(legal);let equity=0;
 for(let i=0;i<samples;i++)equity+=runoutShare(cards,pick(random).cards,board,random)/samples;
 return equity;
}
export function postflopBetRange(range,board,bet,pot,config={}){
 const rows=normalizedRows(range.rows),size=bet/Math.max(.01,pot);
 if(!rows.length)throw Error('Add hands to Hero’s public range before estimating opponent responses.');
 if(config.postflopUseMix){
  const mixed=normalizedRows(rows.map(p=>({...p,weight:p.prob*(config.heroMix?.[p.cls]??50)/100})));
  if(!mixed.length)throw Error('Hero’s edited betting mix is empty. Add betting hands or use the automatic assumption.');
  return {rows:mixed,source:'edited',bluffShare:null};
 }
 // Top made-hand mass narrows as sizing grows. Equal-strength combos share the
 // boundary weight. Draws/weak hands supply an explicitly adjustable bluff mass.
 const sorted=rows.map(p=>({...p,score:evaluate([...p.cards,...board]).score})).sort((a,b)=>b.score-a.score);
 const target=Math.max(.025,Math.min(.45,.5/(1+size))),values=new Map();let above=0;
 for(let i=0;i<sorted.length;){let j=i+1;while(j<sorted.length&&sorted[j].score===sorted[i].score)j++;
  const mass=sorted.slice(i,j).reduce((n,p)=>n+p.prob,0),frequency=postClamp((target-above)/mass);
  for(let k=i;k<j;k++)values.set(sorted[k].key,{frequency,percentile:1-above-mass/2});above+=mass;i=j;
 }
 const prepared=rows.map(p=>{const v=values.get(p.key),draw=bucket(p.cards,board)==='draw';return {...p,value:v.frequency,bluff:(1-v.frequency)*(v.percentile<.6||draw?draw?1:.25:0)};});
 const valueMass=prepared.reduce((n,p)=>n+p.prob*p.value,0),bluffMass=prepared.reduce((n,p)=>n+p.prob*p.bluff,0);
 const factor=Math.max(0,Math.min(1,config.postflopBluffFactor??.5)),wanted=valueMass*factor*bet/Math.max(.01,pot+bet),scale=bluffMass?Math.min(1,wanted/bluffMass):0;
 const totalBluffs=bluffMass*scale;
 return {rows:normalizedRows(prepared.map(p=>({...p,weight:p.prob*(p.value+p.bluff*scale)}))),source:'automatic',bluffShare:totalBluffs/(valueMass+totalBluffs)};
}
function postflopPolicy(equity,price,canRaise,draw,tightness=0){
 const continuing=postClamp((equity-price-tightness+.04)/.08);
 const valueRaise=continuing*postClamp((equity-.72)/.24)*.55;
 const semiBluff=draw&&equity>.25&&equity<.65?.035:0;
 const raise=canRaise?Math.min(continuing,valueRaise+semiBluff):0;
 return [1-continuing,continuing-raise,raise];
}
export function postflopResponseRanges({range,heroRange,board,bet,pot,callAmount,canRaise,config,fee=0}){
 const betting=postflopBetRange(heroRange,board,callAmount,pot+bet-callAmount,config),rows=normalizedRows(range.rows),price=callAmount/Math.max(.01,pot+bet+callAmount-fee),mix={fold:0,call:0,raise:0};
 const combos=rows.map(p=>{const equity=postflopEquity(p.cards,board,betting.rows),rates=postflopPolicy(equity,price,canRaise,bucket(p.cards,board)==='draw',config.populationTightness||0);
  const row={cards:p.cards,key:p.key,cls:p.cls,reach:p.prob,equity};for(const [i,a] of ['fold','call','raise'].entries()){row[a]=rates[i];mix[a]+=p.prob*rates[i];}return row;
 });
 const branches=Object.fromEntries(['fold','call','raise'].map(action=>[action,{probability:mix[action],rows:combos.filter(p=>p[action]>0).map(p=>({cards:p.cards,key:p.key,cls:p.cls,reach:p.reach,frequency:p[action],joint:p.reach*p[action],prob:p.reach*p[action]/mix[action]})).sort((a,b)=>b.prob-a.prob)}]));
 return {mix,combos,branches,bettingRange:{source:betting.source,bluffShare:betting.bluffShare,combos:betting.rows.length},price,policySamples:128};
}
// Hand records are immutable in the app: live edits create a new hand object.
// Reuse per-combination past-action likelihoods while replaying the same record.
const postflopHistoryCache=new WeakMap();
function memoizedPostflopHistory(hand,event,config,context){
 let cache=postflopHistoryCache.get(hand);if(!cache){cache=new Map();postflopHistoryCache.set(hand,cache);}
 const key=JSON.stringify([event.index,config.preflopModel,config.populationTightness,config.postflopBluffFactor,config.rakePct,config.rakeCap,config.extraFee]);
 if(!cache.has(key)){
  const model=postflopHistoryModel(hand,event,config,context),combos=new Map();
  cache.set(key,combo=>{if(!combos.has(combo.key))combos.set(combo.key,model(combo));return combos.get(combo.key);});
 }
 return cache.get(key);
}
function postflopHistoryModel(hand,event,config,{s}){
 // A check alone does not remove strong hands: the default preserves protected
 // checking ranges. Public action ranges below use earlier evidence only.
 if(event.action==='checks')return ()=>.8;
 const priorActions=hand.events.slice(0,event.index),aggression=[...priorActions].reverse().find(e=>e.street===event.street&&e.type==='action'&&['bets','raises'].includes(e.action));
 // Bounded historical inference: earlier evidence uses the legacy likelihoods
 // inside this public reference range, avoiding a recursively solved game tree.
 const publicBefore=(name,step)=>rangeAt(hand,step,name,prior('all'),true,true,{...config,postflopModel:'manual'});
 if(event.facing>0&&aggression){
  const publicRange=publicBefore(aggression.actor,aggression.index),increment=Math.max(hand.bb,aggression.contribution-aggression.facing)/100,pot=(aggression.potBefore+aggression.facing)/100;
  const betting=postflopBetRange(publicRange,s.board,increment,pot,{...config,postflopUseMix:false}),p=s.players.find(p=>p.name===event.actor),v=s.players.find(p=>p.name===aggression.actor),total=(s.pot+event.facing)/100;
  const fee=Math.min(config.rakeCap??1,total*(config.rakePct??5)/100)+(config.extraFee||0),price=event.facing/100/Math.max(.01,total-fee),canRaise=p.stack>event.facing&&v.stack>0;
  return combo=>{const q=postflopEquity(combo.cards,s.board,betting.rows,64),row=postflopPolicy(q,price,canRaise,bucket(combo.cards,s.board)==='draw',config.populationTightness||0);return Math.max(.005,row[event.action==='folds'?0:event.action==='calls'?1:2]);};
 }
 if(['bets','raises'].includes(event.action)){
  const publicRange=publicBefore(event.actor,event.index),betting=postflopBetRange(publicRange,s.board,event.contribution/100,s.pot/100,{...config,postflopUseMix:false}),base=new Map(publicRange.rows.map(p=>[p.key,p.prob]));
  const likelihood=new Map(betting.rows.map(p=>[p.key,p.prob/(base.get(p.key)||1)])),max=Math.max(...likelihood.values());
  return combo=>Math.max(.005,(likelihood.get(combo.key)||0)/max);
 }
 return ()=>1;
}

export function analyzePostflop({hand,step,range,heroRange,config,iterations=5000}){
 const d=evDecision(hand,step),{s,hero,villain,P,H,V,C,minTo,maxTo}=d;
 if(!Number.isInteger(iterations)||iterations<1||iterations>20000)throw Error('Choose 1–20,000 simulation samples.');
 if(config.opponent&&config.opponent!==villain.name)throw Error('Choose the remaining live opponent.');
 const blocked=new Set([...hero.cards,...s.board]),rows=normalizedRows(range.rows.filter(p=>p.cards.every(c=>!blocked.has(c))));
 if(!rows.length)throw Error('Add at least one legal combination to the opponent range.');
 const betTo=Math.min(maxTo,Math.max(Math.min(minTo,maxTo),cents(config.betTo)))/100;
 const maxInvest=Math.min(H,C+V),minInvest=(minTo-hero.streetContribution)/100,B=Math.min(maxInvest,betTo-hero.streetContribution/100),canRaise=d.canRaise&&B>C+1e-8;
 const fee=pot=>Math.min(pot,Math.min(config.rakeCap??1,pot*(config.rakePct??5)/100)+Math.max(0,config.extraFee||0));
 const routes={passive:[],aggressive:[]};
 function showdown(which,label,mass,opponents,cost,pot,seed){
  if(!mass)return 0;const random=rng(seed),pick=rangeSampler(opponents),counts=[0,0,0];let q=0;
  for(let i=0;i<iterations;i++){const share=runoutShare(hero.cards,pick(random).cards,s.board,random);counts[share===1?0:share===0?1:2]++;q+=share/iterations;}
  for(let i=0;i<3;i++)if(counts[i]){const p=mass*counts[i]/iterations,payoff=[1,0,.5][i]*(pot-fee(pot))-cost;routes[which].push({name:label+' → '+['win','lose','split'][i],p,payoff,contribution:p*payoff});}return q;
 }
 const equity=showdown('passive',C?'Call, checkdown':'Checkdown',1,rows,C,P+C,1927+step);
 let responseRanges=null,calledEquity=0,raiseCallEquity=null,heroCallRaise=0,raiseTo=null,mix={fold:0,call:0,raise:0};
 if(canRaise){
  // This range deliberately does not reveal Hero's actual cards to Villain.
  const publicHero=heroRange||rangeAt(hand,step,hero.name,prior('all'),true,true,config);
  const canReraise=H-B>1e-8&&V-(B-C)>1e-8;
  responseRanges=postflopResponseRanges({range:{rows},heroRange:publicHero,board:s.board,bet:B,pot:P,callAmount:B-C,canRaise:canReraise,config,fee:fee(P+2*B-C)});mix=responseRanges.mix;
  if(mix.fold)routes.aggressive.push({name:'Villain folds now',p:mix.fold,payoff:P-fee(P+C),contribution:mix.fold*(P-fee(P+C))});
  calledEquity=showdown('aggressive','Villain calls, checkdown',mix.call,responseRanges.branches.call.rows,B,P+2*B-C,1927+step);
  if(mix.raise){
   // One legal further raise, then Hero folds/calls against the entire raising
   // range, never against the sampled hidden hand or a sampled future board.
   const R=Math.min(H,C+V,Math.round(Math.max(2*B-C,3*B)*100)/100),price=(R-B)/Math.max(.01,P+2*R-C-fee(P+2*R-C));raiseTo=R+hero.streetContribution/100;
   raiseCallEquity=postflopEquity(hero.cards,s.board,responseRanges.branches.raise.rows,512);
   heroCallRaise=postflopPolicy(raiseCallEquity,price,false,false)[1];
   const folds=mix.raise*(1-heroCallRaise);if(folds)routes.aggressive.push({name:'Villain raises → Hero folds',p:folds,payoff:-B,contribution:-folds*B});
   showdown('aggressive','Villain raises → Hero calls, checkdown',mix.raise*heroCallRaise,responseRanges.branches.raise.rows,R,P+2*R-C,1931+step);
  }
 }
 const ev=Object.fromEntries(Object.entries(routes).map(([k,rs])=>[k,rs.reduce((n,r)=>n+r.contribution,0)]));
 return {P,C,B,betTo,canRaise,minInvest,maxInvest,equity,calledEquity,mix,ev,routes,iterations,passiveName:C?'Call':'Check',aggressiveName:d.aggressiveName,future:false,model:'postflop-range',responseRanges,heroCallRaise,raiseCallEquity,raiseTo};
}

export function analyze({hand,step,range,ranges,heroRange,config,iterations=5000}){
 if(snapshot(hand,step).street==='Preflop')return analyzePreflop({hand,step,range,ranges,config,iterations});
 if(config.postflopModel!=='manual')return analyzePostflop({hand,step,range,heroRange,config,iterations});
 const d=evDecision(hand,step),{s,hero,villain,P,H,V,C,minTo,maxTo}=d;
 if(!range.rows.length)throw Error('Add at least one legal combination to the opponent range.');
 if(config.opponent&&config.opponent!==villain.name)throw Error('Choose the remaining live opponent.');
 const betTo=Math.min(maxTo,Math.max(Math.min(minTo,maxTo),cents(config.betTo)))/100;
 const maxInvest=Math.min(H,C+V),minInvest=(minTo-hero.streetContribution)/100;
 const B=Math.min(maxInvest,betTo-hero.streetContribution/100),canRaise=d.canRaise&&B>C+1e-8;
 const fee=(pot,hasFlop)=>hasFlop?Math.min(config.rakeCap,Math.max(0,pot*config.rakePct/100))+Math.min(config.extraFee,Math.max(0,pot-Math.min(config.rakeCap,pot*config.rakePct/100))):0;
 const sum={},r=rng(1927+step),routes={passive:{},aggressive:{}},mix={fold:0,call:0,raise:0},e={all:0,called:0,calledMass:0};
 const add=(which,name,p,net)=>{const x=routes[which][name]??={name,p:0,contribution:0};x.p+=p/iterations;x.contribution+=p*net/iterations;};
 function continuation(which,p0,cost,pot,remaining,opp,board,share){
  const W=Math.min(Math.max(0,config.futureBet),Math.max(0,remaining));
  if(s.board.length===4&&config.futureMin>=0&&evaluate([...hero.cards,...board]).category>=config.futureMin&&W>0){
   const [f,c,rr]=response(bucket(opp,board),config.response),canRaise=remaining-W>1e-8;add(which,'River bet → villain folds',p0*f,pot-fee(pot,true)-cost);
   add(which,share===1?'River bet called → win':share===0?'River bet called → lose':'River bet called → split',p0*(c+(canRaise?0:rr)),share*(pot+2*W-fee(pot+2*W,true))-W-cost);
   if(canRaise)add(which,'River raise → Hero folds',p0*rr,-cost-W);
  }else add(which,share===1?'Checkdown → win':share===0?'Checkdown → lose':'Checkdown → split',p0,share*(pot-fee(pot,true))-cost);
 }
 for(let n=0;n<iterations;n++){
  const opp=choose(range.rows,r),blocked=new Set([...hero.cards,...opp.cards,...s.board]),available=DECK.filter(c=>!blocked.has(c)),board=[...s.board];
  while(board.length<5){const i=Math.floor(r()*available.length);board.push(available[i]);available[i]=available.at(-1);available.pop();}
  const hs=evaluate([...hero.cards,...board]).score,vs=evaluate([...opp.cards,...board]).score,share=hs>vs?1:hs===vs?.5:0;e.all+=share/iterations;
  continuation('passive',1,C,P+C,Math.min(H-C,V),opp.cards,board,share);
  if(canRaise){
   const [f,c,rr]=response(opp.bucket,config.response);
   add('aggressive','Villain folds now',f,P-fee(P+C,s.board.length>=3));
   // A re-raise is possible only when both players retain chips after a call.
   const canReraise=H-B>1e-8&&V-(B-C)>1e-8;
   if(canReraise)add('aggressive','Villain raises → Hero folds',rr,-B);
   const continueMass=c+(canReraise?0:rr);mix.fold+=f/iterations;mix.call+=continueMass/iterations;mix.raise+=(canReraise?rr:0)/iterations;e.called+=continueMass*share/iterations;e.calledMass+=continueMass/iterations;
   continuation('aggressive',continueMass,B,P+2*B-C,Math.min(H-B,V-(B-C)),opp.cards,board,share);
  }
 }
 for(const name of ['passive','aggressive'])sum[name]=Object.values(routes[name]).reduce((a,x)=>a+x.contribution,0);
 return {P,C,B,betTo,canRaise,minInvest,maxInvest,equity:e.all,calledEquity:e.calledMass?e.called/e.calledMass:0,mix,ev:sum,routes:Object.fromEntries(Object.entries(routes).map(([k,v])=>[k,Object.values(v).filter(r=>r.p>.00001).map(r=>({...r,payoff:r.contribution/r.p}))])),iterations,passiveName:C?'Call':'Check',aggressiveName:d.aggressiveName,future:s.board.length===4&&config.futureMin>=0};
}

// Bounded preflop policies: general cash baseline allows one further raise and
// fold/call responses; legacy manual mode folds Hero to any raise. Then checkdown.
// Opponent ranges are sampled jointly by rejecting whole colliding proposals.
export function analyzePreflop({hand,step,range,ranges,config,iterations=5000}){
 const d=evDecision(hand,step),{s,hero,opponents,P,H,C,minTo,maxTo}=d,useCash=config.preflopModel!=='manual';
 if(!d.preflop)throw Error('Select a preflop decision.');
 if(!Number.isInteger(iterations)||iterations<1||iterations>20000)throw Error('Choose 1–20,000 simulation samples.');
 const prepared=opponents.map(p=>{
  const source=ranges?.[p.name]||(opponents.length===1?range:null);
  if(!source?.rows?.length)throw Error('Add a legal range for '+p.name+'.');
  let total=0;const rows=source.rows.filter(row=>row.prob>0&&Number.isFinite(row.prob)&&row.cards?.length===2&&row.cards[0]!==row.cards[1]&&row.cards.every(c=>DECK.includes(c)&&!hero.cards.includes(c))).map(row=>({...row,end:total+=row.prob}));
  if(!total)throw Error('No unblocked combinations for '+p.name+'.');
  return {player:p,rows,total};
 });
 const r=rng(8017+step),pick=source=>{const x=r()*source.total;let lo=0,hi=source.rows.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(source.rows[mid].end<x)lo=mid+1;else hi=mid;}return source.rows[lo];};
 const betTo=Math.min(maxTo,Math.max(Math.min(minTo,maxTo),cents(config.betTo)))/100;
 const wager=Math.round(betTo*100)-hero.streetContribution,call=Math.round(C*100);
 const cover=Math.max(...opponents.map(p=>p.streetContribution+p.stack));
 const B=Math.min(wager,cover-hero.streetContribution)/100,canRaise=d.canRaise&&wager>call;
 const routes={passive:new Map(),aggressive:new Map()},mix={fold:0,call:0,raise:0};let equity=0,calledEquity=0,calledMass=0;
 const add=(line,name,payoff)=>{const x=routes[line].get(name)||{name,p:0,contribution:0};x.p+=1/iterations;x.contribution+=payoff/iterations;routes[line].set(name,x);};
 const lastAggressor=hand.events.slice(0,step).filter(e=>e.street==='Preflop'&&e.type==='action'&&['bets','raises'].includes(e.action)).at(-1)?.actor;
 const maxSeat=Math.max(...s.players.map(p=>p.seat));
 const order=[...opponents].sort((a,b)=>((a.seat-hero.seat+maxSeat)%maxSeat)-((b.seat-hero.seat+maxSeat)%maxSeat));
 const fee=(pot,flop)=>flop?Math.min(pot,Math.min(config.rakeCap,Math.max(0,pot*config.rakePct/100))+Math.max(0,config.extraFee)):0;
 for(let n=0;n<iterations;n++){
  let deal,used,accepted=false;
  for(let attempt=0;attempt<2000;attempt++){
   deal=new Map(prepared.map(p=>[p.player.name,pick(p).cards]));used=new Set(hero.cards);accepted=true;
   for(const cards of deal.values())for(const card of cards){if(used.has(card))accepted=false;used.add(card);}
   if(accepted)break;
  }
  if(!accepted)throw Error('Opponent ranges overlap too heavily to sample a legal joint deal. Widen the conflicting ranges.');
  const board=[],available=DECK.filter(c=>!used.has(c));
  while(board.length<5){const i=Math.floor(r()*available.length);board.push(available[i]);available[i]=available.at(-1);available.pop();}
  const scores=new Map([[hero.name,evaluate([...hero.cards,...board]).score],...opponents.map(p=>[p.name,evaluate([...deal.get(p.name),...board]).score])]);
  const draws=new Map(opponents.map(p=>[p.name,r()])),secondDraws=useCash?new Map([hero,...opponents].map(p=>[p.name,r()])):null;
  const share=players=>{const best=Math.max(...players.map(p=>scores.get(p.name)));return scores.get(hero.name)===best?1/players.filter(p=>scores.get(p.name)===best).length:0;};
  equity+=share([hero,...opponents])/iterations;
  for(const line of ['passive',...(canRaise?['aggressive']:[])]){
   const players=s.players.map(p=>({...p})),hp=players.find(p=>p.name===hero.name),cost=line==='passive'?call:wager;
   hp.stack-=cost;hp.streetContribution+=cost;hp.committed+=cost;
   let level=Math.max(d.level,hp.streetContribution),raised=false,raiser=null;
   const policy=(p,owed,canRaise,aggressor)=>cashResponse({cards:p.name===hero.name?hero.cards:deal.get(p.name),position:p.position,aggressorPosition:aggressor?.position,owed,pot:players.reduce((sum,q)=>sum+q.committed,0),level,bb:hand.bb,effective:Math.min(p.stack+p.streetContribution,aggressor?aggressor.stack+aggressor.streetContribution:hero.stack+hero.streetContribution),raises:Math.max(0,d.raises+(line==='aggressive'?1:0)+(raiser?1:0)-1),tightness:config.populationTightness||0,rakePct:config.rakePct,canRaise});
   const pay=(p,amount)=>{const paid=Math.min(p.stack,amount);p.stack-=paid;p.streetContribution+=paid;p.committed+=paid;};
   for(const before of order){
    const p=players.find(x=>x.name===before.name);
    if(!p.stack||p.folded)continue;
    const owed=Math.max(0,level-p.streetContribution);
    if(!owed&&!d.pending.has(p.name))continue;
    const prior=d.acted[p.name],reopened=!prior||prior.checked||level-prior.level>=prior.minRaise;
    const canReraise=hp.stack>0&&p.stack>owed&&reopened;
    const [fold,callWeight,raise]=useCash?policy(p,owed,canReraise,line==='aggressive'?hp:players.find(x=>x.name===lastAggressor)||hp):response(bucket(deal.get(p.name),[]),config.response),u=draws.get(p.name);
    if(owed&&u<fold){p.folded=true;continue;}
    // No folding when checking is free. The cash policy recomputes a
    // fold/call response to a shove; legacy mode merges raise weight into call.
    if(canReraise&&u>=fold+callWeight&&raise>0){
     raised=true;
     if(useCash){
      const increment=Math.max(d.minRaise,level-d.level),to=Math.min(p.streetContribution+p.stack,Math.max(level+increment,Math.round(level*(p.position==='BTN'?3:3.5))));
      pay(p,to-p.streetContribution);level=to;raiser=p;
     }
     break;
    }
    pay(p,owed);
   }
   if(raised&&!useCash){add(line,'Raise behind → Hero folds',-cost/100);if(line==='aggressive')mix.raise+=1/iterations;continue;}
   if(raiser){
    // No second raise in this bounded tree. Each player responds using only
    // their own cards and the visible wager, never the sampled board/other cards.
    const responding=players.filter(p=>!p.folded&&p.stack>0&&p.name!==raiser.name).sort((a,b)=>((a.seat-raiser.seat+maxSeat)%maxSeat)-((b.seat-raiser.seat+maxSeat)%maxSeat));
    for(const p of responding){
     const owed=Math.max(0,level-p.streetContribution);if(!owed)continue;
     const [fold]=policy(p,owed,false,raiser);
     if(secondDraws.get(p.name)<fold)p.folded=true;else pay(p,owed);
    }
    if(hp.folded){add(line,'Raise behind → Hero folds',(hp.stack-hero.stack)/100);if(line==='aggressive')mix.raise+=1/iterations;continue;}
   }
   // Return an unmatched street wager before constructing main and side pots.
   const highest=[...players].sort((a,b)=>b.streetContribution-a.streetContribution),refund=highest[0].streetContribution-highest[1].streetContribution;
   if(refund>0){highest[0].streetContribution-=refund;highest[0].committed-=refund;highest[0].stack+=refund;}
   const alive=players.filter(p=>!p.folded),villains=alive.filter(p=>p.name!==hero.name),pot=players.reduce((a,p)=>a+p.committed,0)/100;
   let deductions=fee(pot,alive.length>1),award=0,previous=0;
   const levels=[...new Set(players.map(p=>p.committed).filter(Boolean))].sort((a,b)=>a-b);
   for(const cap of levels){
    const contributors=players.filter(p=>p.committed>=cap),eligible=contributors.filter(p=>!p.folded),amount=(cap-previous)*contributors.length/100;previous=cap;
    const deducted=Math.min(amount,deductions);deductions-=deducted;
    if(eligible.some(p=>p.name===hero.name))award+=(amount-deducted)*share(eligible);
   }
   const net=award+(hp.stack-hero.stack)/100;
   const contestShare=villains.length?share(alive):1;
   const name=raiser?'Raise behind → Hero calls → '+(contestShare===1?'win':contestShare>0?'split':award>0?'side-pot return':'lose'):!villains.length?'Everyone folds → win preflop':villains.length+' opponent'+(villains.length>1?'s':'')+' → checkdown → '+(contestShare===1?'win':contestShare>0?'split':award>0?'side-pot return':'lose');
   add(line,name,net);
   if(line==='aggressive'){
    mix[raiser?'raise':villains.length?'call':'fold']+=1/iterations;
    if(villains.length){calledMass+=1/iterations;calledEquity+=contestShare/iterations;}
   }
  }
 }
 const routeLists=Object.fromEntries(Object.entries(routes).map(([key,map])=>[key,[...map.values()].map(x=>({...x,payoff:x.contribution/x.p}))]));
 return {P,C,B,betTo,canRaise,minInvest:(minTo-hero.streetContribution)/100,maxInvest:Math.min(hero.stack,cover-hero.streetContribution)/100,equity,calledEquity:calledMass?calledEquity/calledMass:0,mix,ev:Object.fromEntries(Object.entries(routeLists).map(([k,rs])=>[k,rs.reduce((a,x)=>a+x.contribution,0)])),routes:routeLists,iterations,passiveName:C?(d.raises?'Call':'Limp / complete'):'Check',aggressiveName:d.aggressiveName,future:false,preflop:true,opponents:opponents.length,model:useCash?'cash':'manual'};
}
