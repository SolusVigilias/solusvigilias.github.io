# v0.24.2 — revealed-hand memory fitting

Hidden-hand actions continue to train the response model by marginalizing over
the current range. The uniform compatible-combination deal prior is unchanged.

Completed-hand memory now starts from the pre-hand checkpoint and reconstructs
that hand once. For players with explicit public show events, action gradients
and curvature use the revealed holding at each historical public context.
They replace the uncertain-hand training contribution; action counts and EMA
opportunities are not doubled. Unrevealed cards in player metadata are ignored.
Recorded bot policy evidence retains its previous special handling.

Current-hand inference and rewind do not receive future reveals. Public boards
and actions are replayed chronologically. This is an approximate supervised
replay update, not exact inference over the joint hand/strategy posterior.
Showdown selection bias is not fully modeled. No equilibrium, playing-strength,
or universal speed improvement is claimed.

Existing compact checkpoints cannot recover old revealed-hand corrections
without their history. New completed hands benefit immediately; importing old
history into analysis rebuilds learning from those available hands.

Tests cover future-reveal isolation, hidden-card isolation, changed parameter
fitting, unchanged action counts, deterministic rebuild, serialization and
multiple-hand accumulation. Existing recency and server tests also apply.

Deploy by uploading and unzipping the release in the server home directory, then
running `sudo docker compose --profile public up -d --build --wait` in ~/range-lab.
The package excludes .env and databases. Do not delete Docker volumes.
