import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction,restoreLiveHand,undoLiveAction,livePots,readCards} from './dist/live.js';
import {snapshot,parseHistory,memory,prior,rangeAt,analyze,DEFAULT_RESPONSE} from './dist/poker.js';

const make=(stacks=[1000,1000],heroSeat=1)=>createLiveHand({players:stacks.map((stack,i)=>({name:i?'P'+(i+1):'Hero',stack})),heroSeat,button:1,sb:5,bb:10,cards:'As Ah',id:'LIVEtest',date:'2026/09/28 05:00:00'});
const act=(h,kind,to)=>appendLiveAction(h,{kind,actor:h.live.actor,...(to===undefined?{}:{to})});
const board=(h,cards)=>appendLiveAction(h,{kind:'board',cards});
const finish=(h,extra={})=>appendLiveAction(h,{kind:'settle',fee:0,winners:[],...extra});
const ledger=h=>{
 const s=snapshot(h,h.events.length);
 assert.equal(s.players.reduce((n,p)=>n+p.stack,0)+s.pot+h.totalFees,h.players.reduce((n,p)=>n+p.stack,0));
 assert(s.players.every(p=>p.stack>=0));
 if(h.live.complete){const parsed=parseHistory(h.raw).hands[0];assert.deepEqual(parsed.warnings,[]);assert.equal(parsed.heroNet,h.heroNet);assert.equal(s.pot,0);}
};

assert.deepEqual(readCards('a♠ 10♥',2),['As','Th']);
assert.throws(()=>make([1000]),/2–6/);
assert.throws(()=>readCards('As As',2),/twice/);
let h=make();assert.equal(h.live.actor,'Hero');assert.equal(h.live.toCall,5);assert.equal(h.live.minTo,20);
assert.throws(()=>appendLiveAction(h,{kind:'fold',actor:'P2'}),/turn/);
assert.throws(()=>act(h,'check'),/cannot check/);
assert.throws(()=>act(h,'bet',15),/Minimum/);
assert.throws(()=>act(h,'bet',1001),/cannot exceed/);
assert.throws(()=>board(h,'2c 3d 7s'),/Finish/);
h=act(h,'call');assert.equal(h.live.actor,'P2');assert.equal(h.live.toCall,0);h=act(h,'check');assert.equal(h.live.phase,'board');ledger(h);
assert.throws(()=>board(h,'As 2c 3d'),/duplicates/);
assert.throws(()=>board(h,'2c 2c 3d'),/twice/);
const beforeFlop=structuredClone(h);h=board(h,'2c 3d 7s');assert.equal(h.live.actor,'P2');assert.deepEqual(undoLiveAction(h),beforeFlop);
h=act(h,'check');assert.equal(h.live.actor,'Hero');
const range=rangeAt(h,h.events.length,'P2',prior('wide'),true);
const ev=analyze({hand:h,step:h.events.length,range,config:{opponent:'P2',betTo:.2,rakePct:0,rakeCap:0,extraFee:0,futureMin:-1,futureBet:0,preflopModel:'manual',postflopModel:'manual',response:DEFAULT_RESPONSE},iterations:1000});
assert(Number.isFinite(ev.ev.passive));assert(ev.canRaise);
for(const routes of Object.values(ev.routes))assert(Math.abs(routes.reduce((n,r)=>n+r.p,0)-1)<1e-8);
assert.equal(memory([h]).length,0,'Unfinished hands must not be treated as final losses or observations.');
assert.deepEqual(restoreLiveHand(h.live.spec,JSON.parse(JSON.stringify(h.live.commands))),h);
h=act(h,'bet',30);assert.equal(h.events.at(-1).facing,0);h=act(h,'fold');assert.equal(h.live.phase,'settle');assert.equal(h.events.at(-1).type,'return');assert.equal(h.events.at(-1).amount,30);
h=finish(h);ledger(h);assert.equal(h.heroNet,10);assert.equal(memory([h]).length,2);assert.equal(undoLiveAction(h).live.phase,'settle');

// All-ins, side pots, automatic rankings, fees, and conservation.
h=make([100,200,500]);h=act(h,'all-in');h=act(h,'all-in');h=act(h,'call');ledger(h);
assert.equal(h.live.phase,'board');assert.deepEqual(livePots(h).map(p=>p.amount),[300,200]);
for(const cards of ['2c 3d 7s','8c','9h'])h=board(h,cards);
assert.equal(h.live.phase,'settle');
assert.throws(()=>finish(h,{winners:[['Hero'],['Hero']]}),/eligible/);
assert.throws(()=>finish(h,{auto:true}),/shown cards/);
assert.throws(()=>finish(h,{shown:{P2:'As Kd'},winners:[['Hero'],['P2']]}),/duplicate/);
h=finish(h,{fee:7,auto:true,shown:{Hero:'As Ah',P2:'Ks Kh',P3:'Qs Qh'}});ledger(h);
assert.deepEqual(snapshot(h,h.events.length).players.map(p=>p.stack),[293,200,300]);
assert.equal(h.heroNet,193);assert.equal(h.totalFees,7);

// A short raise cannot reopen an already acted player's betting.
h=make([1000,150,1000]);h=act(h,'bet',100);h=act(h,'all-in');h=act(h,'call');
assert.equal(h.live.actor,'Hero');assert.equal(h.live.toCall,50);assert.equal(h.live.canRaise,false);
assert.throws(()=>act(h,'bet',240),/not open/);h=act(h,'call');assert.equal(h.live.phase,'board');ledger(h);

// Cumulative short raises reaching a full raise do reopen betting.
h=make([150,190,1000,1000],4);h=act(h,'bet',100);h=act(h,'all-in');h=act(h,'all-in');h=act(h,'call');
assert.equal(h.live.actor,'P4');assert.equal(h.live.toCall,90);assert.equal(h.live.canRaise,true);assert.equal(h.live.minTo,280);
h=act(h,'bet',280);ledger(h);

// A short big blind cannot create a dry side pot against the sole player with chips.
h=make([1000,7]);assert.equal(h.live.toCall,2);assert.equal(h.live.canRaise,false);h=act(h,'call');assert.equal(h.live.phase,'board');assert.equal(snapshot(h,h.events.length).pot,14);

// Split pots, odd cents, and state restored from the exact saved commands.
h=make();h=act(h,'call');h=act(h,'check');
for(const cards of ['2c 3d 7s','8c','9h']){h=board(h,cards);h=act(h,'check');h=act(h,'check');}
h=finish(h,{fee:1,winners:[['Hero','P2']]});ledger(h);assert.deepEqual(snapshot(h,h.events.length).players.map(p=>p.stack),[999,1000]);
assert.deepEqual(restoreLiveHand(h.live.spec,h.live.commands),h);
console.log('PASS: live turn order, legal bets, duplicate cards, undo, heads-up EV, short and cumulative all-ins, side pots, fees, split pots, unfinished-memory exclusion, and JSON/text round trips.');
