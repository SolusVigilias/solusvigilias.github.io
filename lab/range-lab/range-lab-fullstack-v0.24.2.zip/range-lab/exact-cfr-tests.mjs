import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {newBelief,nodeBeliefs,conditionCards,updateBelief,beliefSummary,freshMemory,restoreMemory} from './dist/learning.js';
import {solveExactCfr,exactInfoKey,exactPolicyFor,exactActionLikelihood,inspectExact,advanceExactPlan,exactPlanDecision} from './dist/exact-cfr.js';
import {solveRiverCfr} from './dist/river-cfr.js';
import {RESPONSE_PRIOR,trainResponse,responseContext} from './dist/adaptation.js';
import {publicContext,actionPolicy} from './dist/policy.js';
const near=(a,b,e=1e-9)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
assert.equal(solveRiverCfr,solveExactCfr,'Production dispatch must use individual-hand CFR');
const cards=['Qh','Qs'],air=['Ah','4h'],villain=['Th','Ts'],board=['2c','3d','7s','9h','Jc'];
let hand=createLiveHand({players:[{name:'Hero',stack:100},{name:'Bot',stack:100}],heroSeat:1,button:1,sb:5,bb:10,cards});
for(const a of [{kind:'call',actor:'Hero'},{kind:'check',actor:'Bot'},{kind:'board',cards:board.slice(0,3)},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:[board[3]]},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:[board[4]]},{kind:'bet',actor:'Bot',to:90}])hand=appendLiveAction(hand,a);
const row=c=>({...newBelief().find(r=>c.every(x=>r.cards.includes(x))),prob:1});
const beliefState={filters:{Hero:[{...row(cards),prob:.5},{...row(air),prob:.5}],Bot:[row(villain)]}},input={hand,step:hand.events.length,beliefState,config:{rakePct:0,rakeCap:0,extraFee:0}};
assert.notEqual(exactInfoKey(0,cards,board,''),exactInfoKey(0,air,board,''));
assert.notEqual(exactInfoKey(0,cards,board,''),exactInfoKey(0,cards,[...board.slice(0,-1),'Jd'],''));
assert.equal(exactInfoKey(0,cards,board,''),exactInfoKey(0,[...cards].reverse(),board,''));
const solved=await solveExactCfr(input,{iterations:2000});
assert(exactPolicyFor(solved.plan,cards).policy.find(a=>a.kind==='call').prob>.98);
assert(exactPolicyFor(solved.plan,air).policy.find(a=>a.kind==='fold').prob>.98);
for(const n of solved.plan.game.nodes.values()){assert(Number.isFinite(n.regret.reduce((a,b)=>a+b,0)));assert(n.actions.length===n.sum.length);}
const result=await inspectExact(solved,input,{samples:20});near(result.allActions.find(a=>a.kind==='call').ev,1.1);near(result.allActions.find(a=>a.kind==='fold').ev,0);near(result.rootCoverage,1);
for(const a of result.allActions){near(a.routes.reduce((s,r)=>s+r.p,0),1);near(a.routes.reduce((s,r)=>s+r.contribution,0),a.ev);near(a.tree.ev,a.ev);}
// Only the requested policy row changes when selecting a different actual hand.
const alternate={...input,hand:{...hand,players:hand.players.map(p=>({...p,cards:p.name==='Hero'?air:['Ac','Ad']}))}};
const other=await solveExactCfr(alternate,{iterations:2000});const action=solved.policy.find(a=>a.kind==='call');
assert.deepEqual(exactActionLikelihood(solved.plan,action),exactActionLikelihood(other.plan,action));
assert.deepEqual([...solved.plan.game.nodes].map(([k,v])=>[k,v.regret,v.sum]),[...other.plan.game.nodes].map(([k,v])=>[k,v.regret,v.sum]));
assert(exactPlanDecision(solved.plan));assert.equal(advanceExactPlan(solved.plan,{type:'action',actor:'wrong',action:'calls'}),null);
assert.equal(await solveExactCfr(input,{cancel:()=>true}),null);
const sparse=await solveExactCfr(input,{iterations:0});assert.equal(sparse.averageVisits,0);assert.equal(exactPlanDecision(sparse.plan),null);near(sparse.policy.reduce((s,a)=>s+a.prob,0),1);
// Impossible combinations disappear immediately when a board card is exposed.
const blocked=conditionCards(newBelief(),[...board,...cards]);assert.equal(blocked.length,990);assert(blocked.every(r=>r.cards.every(c=>![...board,...cards].includes(c))));
// Legacy style weights no longer limit the range or action model.
assert.deepEqual(newBelief([1,0,0,0]),newBelief([0,0,0,1]));
const model=RESPONSE_PRIOR(),ctx={...publicContext(hand,hand.events.length,'Hero'),responseModel:model},rows=beliefState.filters.Hero,summary=beliefSummary(beliefState.filters.Bot,board),event={kind:'call'};
const p0=actionPolicy(ctx,air,0,summary).find(a=>a.kind==='call').prob;
for(let i=0;i<16;i++)trainResponse(model,ctx,updateBelief(rows,ctx,event,summary),event);
const cell=model.contexts[responseContext(ctx)];assert(cell.theta.call>0);assert(cell.precision.call[0]>4);assert(actionPolicy(ctx,air,0,summary).find(a=>a.kind==='call').prob>p0);
near(actionPolicy(ctx,air,0,summary).reduce((s,a)=>s+a.prob,0),1);assert.deepEqual(actionPolicy(ctx,air,0,summary),actionPolicy(ctx,air,3,summary));
const memory=freshMemory();memory.profiles.Hero={hands:1,actions:16,logLoss:1,posterior:[.55,.15,.15,.15],response:model};assert.deepEqual(restoreMemory(JSON.parse(JSON.stringify(memory))),memory);
const invalid=structuredClone(memory);invalid.profiles.Hero.response.contexts[responseContext(ctx)].precision.call[0]=NaN;assert.throws(()=>restoreMemory(invalid));
console.log('PASS: exact-hand separation and known river solution, exact-board keys, hidden-card isolation, production dispatch, normalized EV routes, untrained diagnostics, cancellation, blockers, continuous learning and precision persistence.');
