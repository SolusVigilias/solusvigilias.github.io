import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
export function openStore(path){
 if(path!==':memory:')mkdirSync(dirname(path),{recursive:true});
 const db=new DatabaseSync(path);db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS players(id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE, name TEXT NOT NULL, memory TEXT, created INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS games(player_id TEXT PRIMARY KEY REFERENCES players(id), version INTEGER NOT NULL, saved TEXT NOT NULL, view TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS hands(id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id), raw TEXT NOT NULL, created INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS idx_hands_player_created ON hands(player_id,created);
 CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id), request_id TEXT NOT NULL, fingerprint TEXT NOT NULL, status TEXT NOT NULL, message TEXT, error TEXT, created INTEGER NOT NULL, UNIQUE(player_id,request_id));
 CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_player_active ON jobs(player_id) WHERE status IN ('queued','running');
 CREATE TABLE IF NOT EXISTS usage(day TEXT NOT NULL, owner TEXT NOT NULL, seconds INTEGER NOT NULL, PRIMARY KEY(day,owner));
 PRAGMA optimize;`);
 // A crash never commits half an action. Reservations remain charged on crash;
 // this is intentionally conservative and prevents restarting to evade quotas.
 db.prepare("UPDATE jobs SET status='failed',error='Server restarted. The last committed game is safe; retry your action.' WHERE status IN ('queued','running')").run();
 return db;
}
export function transaction(db,fn){db.exec('BEGIN IMMEDIATE');try{const x=fn();db.exec('COMMIT');return x;}catch(e){db.exec('ROLLBACK');throw e;}}
