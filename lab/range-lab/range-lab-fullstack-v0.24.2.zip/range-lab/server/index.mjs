import http from 'node:http';
import {randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {Worker} from 'node:worker_threads';
import {openStore,transaction} from './store.mjs';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
const hash=x=>createHash('sha256').update(x).digest('hex');
const id=p=>p+randomBytes(18).toString('base64url');
const number=(x,d,min,max)=>{const n=Number(x??d);if(!Number.isInteger(n)||n<min||n>max)throw Error('Invalid server limit');return n;};
const error=(status,message)=>Object.assign(new Error(message),{status});
export function createApp(options={}){
 const env=options.env||process.env;
 if(env.NODE_ENV==='production'&&(!env.INVITE_CODE||env.INVITE_CODE.length<16||env.INVITE_CODE.startsWith('replace-')))throw Error('Set a private INVITE_CODE of at least 16 characters before starting in production.');
 const db=openStore(options.dbPath||env.DATA_FILE||'data/range-lab.sqlite');
 const config={maxQueue:number(env.MAX_QUEUE,8,1,100),maxPlayers:number(env.MAX_PLAYERS,100,1,10000),timeout:number(env.JOB_TIMEOUT_SECONDS,90,2,300),daily:number(env.DAILY_COMPUTE_SECONDS,3600,1,86400),playerDaily:number(env.PLAYER_DAILY_COMPUTE_SECONDS,600,1,86400),iterations:number(env.CFR_ITERATIONS,0,0,8000)};
 if(![0,150,600,2000,8000].includes(config.iterations))throw Error('CFR_ITERATIONS must be 0, 150, 600, 2000, or 8000');
 const origins=new Set((env.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean));
 const pending=[],previews=new Map(),rates=new Map();let active=null,worker=null,closing=false;
 const getGame=player=>db.prepare('SELECT * FROM games WHERE player_id=?').get(player);
 const publicPlayer=p=>({id:p.id,name:p.name});
 const quota=(day,owner)=>db.prepare('SELECT seconds FROM usage WHERE day=? AND owner=?').get(day,owner)?.seconds||0;
 const charge=(day,owner,n)=>db.prepare('INSERT INTO usage(day,owner,seconds) VALUES(?,?,?) ON CONFLICT(day,owner) DO UPDATE SET seconds=MAX(0,seconds+excluded.seconds)').run(day,owner,n);
 function limited(key,max,window=60000){const now=Date.now();let r=rates.get(key);if(!r||r.until<=now){r={n:0,until:now+window};rates.set(key,r);}if(++r.n>max)throw error(429,'Too many requests. Please wait a moment.');if(rates.size>10000){for(const [k,v]of rates)if(v.until<now)rates.delete(k);if(rates.size>10000)throw error(503,'Server busy. Please try again shortly.');}}
 function jobView(j){return {id:j.id,status:j.status,message:j.message||'',error:j.error||null,position:j.status==='queued'?pending.findIndex(v=>v.id===j.id)+1:0,preview:previews.get(j.id)||null};}
 function createWorker(){const w=options.workerFactory?options.workerFactory():new Worker(new URL('./solver-worker.mjs',import.meta.url),{execArgv:[],resourceLimits:{maxOldGenerationSizeMb:512}});worker=w;
  w.on('message',m=>{
   if(worker!==w||!active)return;
   if(m.type==='progress')db.prepare('UPDATE jobs SET message=? WHERE id=?').run(String(m.message).slice(0,180),active.id);
   else if(m.type==='preview')previews.set(active.id,m.view);
   else if(m.type==='done')finish(null,m);
   else if(m.type==='failed')finish(String(m.error).slice(0,300));
  });
  w.on('error',()=>{if(worker===w){worker=null;if(active)finish('Calculation failed. Your last committed game is unchanged.');}});
  w.on('exit',()=>{if(worker===w){worker=null;if(active)finish('Calculation stopped. Please retry.');}});
 }
 function finish(failure,result){
  const job=active;if(!job)return;clearTimeout(job.timer);active=null;previews.delete(job.id);
  const spent=Math.min(config.timeout,Math.max(1,Math.ceil((Date.now()-job.started)/1000)));
  try{transaction(db,()=>{
   charge(job.day,'global',spent-config.timeout);charge(job.day,job.player.id,spent-config.timeout);
   if(!failure){
    const saved=JSON.stringify(result.saved),view=JSON.stringify(result.view);if(saved.length>8_000_000)throw Error('Game state exceeds the server limit.');
    const current=getGame(job.player.id);if((current?.version||0)!==job.version)throw Error('Game changed during calculation.');
    db.prepare('INSERT INTO games VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET version=excluded.version,saved=excluded.saved,view=excluded.view').run(job.player.id,job.version+1,saved,view);
    if(result.memory)db.prepare('UPDATE players SET memory=? WHERE id=?').run(JSON.stringify(result.memory),job.player.id);
    if(result.history)db.prepare('INSERT OR IGNORE INTO hands VALUES(?,?,?,?)').run(result.history.id,job.player.id,result.history.raw,Date.now());
    db.prepare('DELETE FROM hands WHERE player_id=? AND id NOT IN (SELECT id FROM hands WHERE player_id=? ORDER BY created DESC LIMIT 1000)').run(job.player.id,job.player.id);
   }
   db.prepare('UPDATE jobs SET status=?,message=?,error=? WHERE id=?').run(failure?'failed':'done',failure?'':'Ready',failure||null,job.id);
  });}catch(e){failure='Could not save this action. Your previous game is safe.';db.prepare("UPDATE jobs SET status='failed',error=? WHERE id=?").run(failure,job.id);if(worker){const w=worker;worker=null;w.terminate();}}
  if(!closing)queueMicrotask(pump);
 }
 function pump(){if(active||!pending.length||closing)return;active=pending.shift();active.started=Date.now();db.prepare("UPDATE jobs SET status='running',message='Bot is thinking…' WHERE id=?").run(active.id);if(!worker)createWorker();active.timer=setTimeout(()=>{const w=worker;worker=null;w?.terminate();finish('Calculation time limit reached. Your last committed game is safe; retry.');},config.timeout*1000);worker.postMessage(active.payload);}
 function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
 async function body(req){let n=0;const chunks=[];for await(const c of req){n+=c.length;if(n>8192)throw error(413,'Request too large.');chunks.push(c);}try{return JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch{throw error(400,'Invalid JSON.');}}
 function auth(req){const m=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.headers.authorization||'');const p=m&&db.prepare('SELECT * FROM players WHERE token_hash=?').get(hash(m[1]));if(!p)throw error(401,'Enter your player recovery key or create a player.');return p;}
 const server=http.createServer(async(req,res)=>{
  try{
   res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','SAMEORIGIN');
   const url=new URL(req.url,'http://localhost'),path=url.pathname;
   if(path.startsWith('/api/')){
    const origin=req.headers.origin,host=req.headers.host;
    if(origin&&!origins.has(origin)&&origin!==`http://${host}`&&origin!==`https://${host}`)throw error(403,'This website is not allowed to connect to this server.');
    if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');}
    if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
    const ip=env.TRUST_PROXY==='1'?String(req.headers['x-forwarded-for']||req.socket.remoteAddress).split(',').at(-1).trim():req.socket.remoteAddress;
    limited('ip:'+ip,180);
    if(path==='/api/health'&&req.method==='GET')return json(res,200,{service:'range-lab',version:'0.24.2',cloud:true,inviteRequired:!!env.INVITE_CODE,active:active?1:0,queued:pending.length});
    if(path==='/api/players'&&req.method==='POST'){
     limited('signup:'+ip,5,600000);const b=await body(req);
     if(env.INVITE_CODE&&!timingSafeEqual(Buffer.from(hash(String(b.invite||''))),Buffer.from(hash(env.INVITE_CODE))))throw error(403,'Enter the server’s invitation code.');
     if(typeof b.name!=='string'||!b.name.trim()||b.name.trim().length>30)throw error(400,'Choose a name of 1–30 characters.');
     if(db.prepare('SELECT COUNT(*) AS n FROM players').get().n>=config.maxPlayers)throw error(503,'This server has reached its player limit.');
     const token=randomBytes(32).toString('base64url'),p={id:id('player_'),name:b.name.trim()};db.prepare('INSERT INTO players VALUES(?,?,?,?,?)').run(p.id,hash(token),p.name,null,Date.now());return json(res,201,{player:p,token});
    }
    const p=auth(req);
    if(path==='/api/me'&&req.method==='GET'){
     const g=getGame(p.id),j=db.prepare("SELECT * FROM jobs WHERE player_id=? AND status IN ('queued','running')").get(p.id),day=new Date().toISOString().slice(0,10);
     return json(res,200,{player:publicPlayer(p),game:g?JSON.parse(g.view):null,job:j?jobView(j):null,completedHands:p.memory?JSON.parse(p.memory).hands:0,compute:{remainingSeconds:Math.max(0,config.playerDaily-quota(day,p.id)),reservedAndUsedSeconds:quota(day,p.id)}});
    }
    if(path==='/api/history'&&req.method==='GET'){const rows=db.prepare('SELECT raw FROM hands WHERE player_id=? ORDER BY created DESC LIMIT 1000').all(p.id);res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Content-Disposition':'attachment; filename="range-lab-cloud-hands.txt"'});res.end(rows.map(r=>r.raw).join('\n\n\n'));return;}
    if(path.startsWith('/api/jobs/')&&req.method==='GET'){const j=db.prepare('SELECT * FROM jobs WHERE id=? AND player_id=?').get(path.slice(10),p.id);if(!j)throw error(404,'Job not found.');return json(res,200,jobView(j));}
    if(path==='/api/commands'&&req.method==='POST'){
     limited('action:'+p.id,30);const b=await body(req);
     if(!b||!['new','next','rebuy','act'].includes(b.kind)||!Number.isInteger(b.version)||b.version<0||typeof b.requestId!=='string'||!/^[A-Za-z0-9_-]{16,80}$/.test(b.requestId))throw error(400,'Invalid game command.');
     const command={kind:b.kind};if(b.kind==='act'){if(!b.action||!['fold','call','check','bet'].includes(b.action.kind)||b.action.kind==='bet'&&(!Number.isInteger(b.action.to)||b.action.to<1||b.action.to>100000))throw error(400,'Invalid action.');command.action={kind:b.action.kind,...(b.action.kind==='bet'?{to:b.action.to}:{})};}
     const fingerprint=hash(JSON.stringify({command,version:b.version})),old=db.prepare('SELECT * FROM jobs WHERE player_id=? AND request_id=?').get(p.id,b.requestId);
     if(old){if(old.fingerprint!==fingerprint)throw error(409,'Request ID was already used for a different action.');return json(res,200,jobView(old));}
     if(db.prepare("SELECT id FROM jobs WHERE player_id=? AND status IN ('queued','running')").get(p.id))throw error(409,'Your previous action is still processing.');
     const g=getGame(p.id);if((g?.version||0)!==b.version)throw error(409,'Game changed. Refresh before taking another action.');
     const view=g?JSON.parse(g.view):null;
     if(command.kind==='new'&&g||command.kind!=='new'&&!g)throw error(409,'Resume your existing game or deal your first hand.');
     if(['next','rebuy'].includes(command.kind)&&!view.complete)throw error(409,'Finish the current hand first.');
     if(command.kind==='next'&&view.canRebuy)throw error(400,'Start a new 100 BB match.');
     if(command.kind==='act'){
      if(view.complete||view.actor!=='Hero')throw error(409,'It is not your turn.');
      if(command.action.kind==='bet'){const w=view.wager,to=command.action.to;if(!w||to>w.maxBB*view.bb||to<w.minBB*view.bb&&to!==w.maxBB*view.bb)throw error(400,'Choose a legal bet size.');}
      else if(!view.actions.some(a=>a.kind===command.action.kind))throw error(400,'That action is not available.');
     }
     if(pending.length+(active?1:0)>=config.maxQueue)throw error(503,'The table server is busy. Please try again shortly.');
     const day=new Date().toISOString().slice(0,10),jobId=id('job_');
     transaction(db,()=>{if(quota(day,'global')+config.timeout>config.daily||quota(day,p.id)+config.timeout>config.playerDaily)throw error(429,'Daily calculation allowance reached. It resets at 00:00 UTC.');charge(day,'global',config.timeout);charge(day,p.id,config.timeout);db.prepare('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?)').run(jobId,p.id,b.requestId,fingerprint,'queued','Waiting for a calculation slot',null,Date.now());});
     pending.push({id:jobId,player:p,version:b.version,day,payload:{player:publicPlayer(p),version:b.version,command,saved:g?JSON.parse(g.saved):null,memory:p.memory?JSON.parse(p.memory):null,iterations:config.iterations}});pump();return json(res,202,jobView(db.prepare('SELECT * FROM jobs WHERE id=?').get(jobId)));
    }
    throw error(404,'API route not found.');
   }
   if(req.method!=='GET'&&req.method!=='HEAD')throw error(405,'Method not allowed.');
   const name=path==='/'?'/cloud.html':decodeURIComponent(path),file=resolve(root,'.'+name);if(!file.startsWith(root)||!['.html','.css','.js','.svg','.png','.jpeg','.ico'].includes(extname(file)))throw error(404,'Not found.');
   const s=await stat(file);if(!s.isFile())throw error(404,'Not found.');const mime={'.html':'text/html','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.png':'image/png','.jpeg':'image/jpeg','.ico':'image/x-icon'};
   res.writeHead(200,{'Content-Type':`${mime[extname(file)]}; charset=utf-8`,'Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:await readFile(file));
  }catch(e){if(!res.headersSent)json(res,e.status||(e.code==='ENOENT'?404:500),{error:e.status?e.message:e.code==='ENOENT'?'Not found.':'Server error. Please try again.'});else res.end();}
 });
 server.requestTimeout=15000;server.headersTimeout=10000;
 const cleanup=setInterval(()=>{db.prepare("DELETE FROM jobs WHERE status IN ('done','failed') AND created<?").run(Date.now()-7*86400000);db.prepare('DELETE FROM usage WHERE day<?').run(new Date(Date.now()-8*86400000).toISOString().slice(0,10));},3600000);cleanup.unref();
 return {server,db,config,async close(){closing=true;clearInterval(cleanup);if(active){clearTimeout(active.timer);finish('Server is shutting down. Please retry.');}await worker?.terminate();await new Promise(r=>server.close(r));db.close();}};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const app=createApp();app.server.listen(number(process.env.PORT,3000,1,65535),process.env.HOST||'0.0.0.0',()=>console.log('Range Lab backend listening on port '+app.server.address().port));
 for(const s of ['SIGINT','SIGTERM'])process.on(s,()=>app.close().then(()=>process.exit(0)));
}
