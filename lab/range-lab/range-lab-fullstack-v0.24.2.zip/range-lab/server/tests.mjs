import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {createApp} from './index.mjs';
import {publicGame} from './game.mjs';
import {newPractice} from '../dist/practice.js';
import {parseHistory} from '../dist/poker.js';
const dir=await mkdtemp(join(tmpdir(),'range-lab-server-'));
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function start(options={}){const app=createApp({dbPath:':memory:',env:{},...options});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;const request=async(path,token=null,body=null,headers={})=>{const r=await fetch(base+path,{method:body?'POST':'GET',headers:{...(token?{Authorization:'Bearer '+token}:{}),...(body?{'Content-Type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json()};};return {...app,base,request};}
async function player(app,name='Test',invite){const r=await app.request('/api/players',null,{name,invite});assert.equal(r.status,201,JSON.stringify(r));return r.data;}
async function poll(app,token,id){for(let i=0;i<600;i++){const {data}=await app.request('/api/jobs/'+id,token);if(['done','failed'].includes(data.status))return data;await wait(150);}throw Error('Job did not finish.');}
class HeldWorker extends EventEmitter{postMessage(payload){this.payload=payload;}async terminate(){this.emit('exit',0);}}
let app;
try{
 assert.throws(()=>createApp({dbPath:':memory:',env:{NODE_ENV:'production',INVITE_CODE:'replace-with-a-long-random-invitation-code'}}),/INVITE_CODE/);
 // Privacy projection includes only actually shown cards and Hero's own cards.
 const p=newPractice([],0,null,()=>.4,{pauseAtBot:true});p.lastDecision={cards:p.botCards,deck:p.deck};
 const view=publicGame(p),text=JSON.stringify(view);
 for(const key of ['botCards','deck','filters','actionEvidence','memoryStart','lastDecision','spec','commands'])assert(!Object.hasOwn(view,key));
 assert.deepEqual(view.players.find(p=>p.name==='Practice bot').cards,[]);assert.equal(view.players.find(p=>p.name==='Hero').cards.length,2);
 // Controlled worker proves queue admission, owner isolation and idempotency
 // independently of poker speed or stochastic decisions.
 let worker;
 app=await start({env:{MAX_QUEUE:'1',INVITE_CODE:'test-invite'},workerFactory:()=>worker=new HeldWorker()});
 assert.equal((await app.request('/api/players',null,{name:'Denied',invite:'wrong'})).status,403);
 const a=await player(app,'Alice','test-invite'),b=await player(app,'Bob','test-invite');
 assert.equal((await app.request('/api/me')).status,401);
 assert.equal((await app.request('/api/me',a.token,null,{Origin:'https://evil.example'})).status,403);
 const command={kind:'new',version:0,requestId:randomUUID()};
 const first=await app.request('/api/commands',a.token,command);assert.equal(first.status,202);
 const duplicate=await app.request('/api/commands',a.token,command);assert.equal(duplicate.data.id,first.data.id);assert.equal(duplicate.status,200);
 assert.equal((await app.request('/api/commands',a.token,{...command,kind:'next'})).status,409);
 assert.equal((await app.request('/api/jobs/'+first.data.id,b.token)).status,404);
 assert.equal((await app.request('/api/commands',b.token,{...command,requestId:randomUUID()})).status,503);
 worker.emit('message',{type:'done',saved:{private:'kept server-side'},view:{...view,version:1},memory:null,history:null});
 const committed=(await app.request('/api/me',a.token)).data;assert.equal(committed.game.version,1);assert(!JSON.stringify(committed).includes('kept server-side'));
 assert.equal((await app.request('/api/commands',a.token,{kind:'act',version:0,requestId:randomUUID(),action:{kind:'fold'}})).status,409);
 assert.equal((await app.request('/api/commands',a.token,{kind:'act',version:1,requestId:randomUUID(),action:{kind:'bet',to:99999}})).status,400);
 const next=await app.request('/api/commands',a.token,{kind:'act',version:1,requestId:randomUUID(),action:{kind:'fold'}});assert.equal(next.status,202);
 worker.emit('message',{type:'failed',error:'Controlled failure'});assert.equal((await app.request('/api/me',a.token)).data.game.version,1);
 await app.close();app=null;
 // Reservation is atomic and survives restarts. Insufficient allowance blocks work.
 app=await start({env:{DAILY_COMPUTE_SECONDS:'89'},workerFactory:()=>new HeldWorker()});const q=await player(app);assert.equal((await app.request('/api/commands',q.token,{kind:'new',version:0,requestId:randomUUID()})).status,429);await app.close();app=null;
 // Timeout preserves committed state, clears the outstanding job and reclaims worker.
 app=await start({env:{JOB_TIMEOUT_SECONDS:'2'},workerFactory:()=>new HeldWorker()});const t=await player(app);const tj=await app.request('/api/commands',t.token,{kind:'new',version:0,requestId:randomUUID()});const timed=await poll(app,t.token,tj.data.id);assert.equal(timed.status,'failed');assert.match(timed.error,/time limit/);assert.equal((await app.request('/api/me',t.token)).data.game,null);await app.close();app=null;
 // Real worker: deal, fold, save memory, export reconciling history, restore
 // identity after restart, next hand rotates blinds and runs a real bot solve.
 const dbPath=join(dir,'test.sqlite');app=await start({dbPath,env:{CFR_ITERATIONS:'150'}});const real=await player(app,'Real worker');
 const send=async command=>{const r=await app.request('/api/commands',real.token,{...command,requestId:randomUUID()});assert.equal(r.status,202,JSON.stringify(r));const done=await poll(app,real.token,r.data.id);assert.equal(done.status,'done',JSON.stringify(done));return (await app.request('/api/me',real.token)).data;};
 let state=await send({kind:'new',version:0});assert.equal(state.game.players.find(p=>p.name==='Hero').cards.length,2);assert.deepEqual(state.game.players.find(p=>p.name==='Practice bot').cards,[]);assert.equal(state.game.potBB,1.5);
 state=await send({kind:'act',version:1,action:{kind:'fold'}});assert(state.game.complete);assert.equal(state.completedHands,1);assert.equal(state.game.players.reduce((s,p)=>s+p.stackBB,0),200);
 const raw=await fetch(app.base+'/api/history',{headers:{Authorization:'Bearer '+real.token}}).then(r=>r.text());const parsed=parseHistory(raw);assert.equal(parsed.hands.length,1);assert.deepEqual(parsed.hands[0].warnings,[]);assert(!raw.includes(real.token));
 const last=state.game;await app.close();app=null;
 app=await start({dbPath,env:{CFR_ITERATIONS:'150'}});state=(await app.request('/api/me',real.token)).data;assert.deepEqual(state.game,last);assert.equal(state.completedHands,1);
 state=await send({kind:'next',version:2});assert.equal(state.game.button,2);assert.equal(state.game.handNumber,2);assert.equal(state.game.learning.hands,1);assert(state.game.complete||state.game.actor==='Hero');
 await app.close();app=null;
 // Browser payload code is independent of the poker engine.
 const client=await readFile(new URL('../dist/cloud.js',import.meta.url),'utf8');assert(!/^import /m.test(client));assert(client.includes('requestId:crypto.randomUUID()'));assert(client.includes('localStorage.setItem(requestKey()'));
 console.log('PASS: hidden-card filtering, authentication, owner isolation, invite/CORS checks, legal commands, idempotency, stale versions, failure rollback, queue/quotas/timeouts, real worker, hand accounting, export, restart recovery, memory and blind rotation.');
}finally{await app?.close();await rm(dir,{recursive:true,force:true});}
