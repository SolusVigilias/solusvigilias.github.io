import {parentPort} from 'node:worker_threads';
import {randomInt} from 'node:crypto';
import {newPractice,practiceRestore,practiceSave,advancePractice,advancePracticeAdaptive} from '../dist/practice.js';
import {completeMemory} from '../dist/learning.js';
import {publicGame} from './game.mjs';
const random=()=>randomInt(0,4294967296)/4294967296;
let cache=null;
parentPort.on('message',async job=>{
 try{
  let p=cache?.playerId===job.player.id&&cache.version===job.version?cache.p:job.saved?practiceRestore(job.saved,[]):null;
  // Work on the cached tree, but discard it after any failed job. Durable state
  // is committed by the API only after the entire operation succeeds.
  const c=job.command;
  if(['new','rebuy','next'].includes(c.kind)){
   if(c.kind==='new'&&p)throw Error('Resume your existing game.');
   if(c.kind!=='new'&&(!p||!p.hand.live.complete))throw Error('Finish the current hand first.');
   const memory=c.kind==='rebuy'?completeMemory(p.hand,[]):job.memory;
   p=newPractice([],0,c.kind==='next'?p:null,random,{pauseAtBot:true,playerId:job.player.id,playerName:job.player.name,memoryStart:memory||undefined});
   p.config.cfrIterations=job.iterations;
  }else if(c.kind==='act'){
   if(!p||p.hand.live.complete)throw Error('Deal a hand first.');
   advancePractice(p,c.action,random,{pauseAtBot:true});
  }else throw Error('Unknown command.');
  // Apply the configured budget to restored and in-progress games as well.
  p.config.cfrIterations=job.iterations;
  parentPort.postMessage({type:'preview',view:publicGame(p,job.version)});
  let last=0;
  p=await advancePracticeAdaptive(p,null,random,message=>{if(Date.now()-last>350){last=Date.now();parentPort.postMessage({type:'progress',message});}});
  const version=job.version+1,memory=p.hand.live.complete?completeMemory(p.hand,[]):null;
  cache={playerId:job.player.id,version,p};
  parentPort.postMessage({type:'done',saved:practiceSave(p),view:publicGame(p,version),memory,history:p.hand.live.complete?{id:p.hand.id,raw:p.hand.raw}:null});
 }catch(e){cache=null;parentPort.postMessage({type:'failed',error:e.message});}
});
