import {snapshot} from '../dist/poker.js';
import {legalActions,publicContext} from '../dist/policy.js';
// Explicit allowlist. Never send a practice save, deck, filters, solver report,
// actionEvidence, or live.spec to the browser: they contain private information.
export function publicGame(p,version=0){
 const h=p.hand,s=snapshot(h,h.events.length),bb=h.bb;
 return {version,handId:h.id,handNumber:h.live.spec.handNumber,street:s.street,complete:h.live.complete,button:h.button,potBB:s.pot/bb,feeBB:(h.totalFees||0)/bb,bb,actor:h.live.actor,
  players:s.players.map(v=>({seat:v.seat,name:v.name,stackBB:v.stack/bb,position:v.position,folded:v.folded,lastAction:v.lastAction,cards:v.name===h.hero?[...h.players.find(q=>q.name===h.hero).cards]:[...(h.events.find(e=>e.type==='show'&&e.actor===v.name)?.cards||[])]})),
  board:[...s.board],actions:h.live.complete||h.live.actor!==h.hero?[]:legalActions(publicContext(h,h.events.length,h.hero)).map(a=>({kind:a.kind,label:a.label,to:a.to,costBB:a.cost/bb})),
  wager:h.live.actor===h.hero&&h.live.canRaise?{minBB:h.live.minTo/bb,maxBB:h.live.maxTo/bb}:null,
  events:h.events.filter(e=>['action','street','collect','return'].includes(e.type)).map(e=>({type:e.type,actor:e.actor,action:e.action,street:e.street,board:e.board,toBB:e.to==null?null:e.to/bb,amountBB:(e.amount||0)/bb})),
  learning:{hands:p.learning?.sharedHands||0,actions:p.learning?.currentHeroActions||0},engine:'Experimental exact-hand bot',
  canRebuy:h.live.complete&&s.players.some(v=>v.stack<=0)};
}
