import assert from 'node:assert/strict';
import fs from 'node:fs';
import {snapshot,parseHistory,decisionIndices,playerKey} from './dist/poker.js';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {publicContext,actionPolicy,legalActions,seeded,TYPE_PRIOR} from './dist/policy.js';
import {newBelief,updateBelief,typeMass,nodeBeliefs,learnMemory,beliefSummary,conditionCards,comboMass} from './dist/learning.js';
import {newPractice,practicePolicy,advancePractice,practiceSave,practiceRestore} from './dist/practice.js';
import {analyzeTree,advanceState,terminalPayoff} from './dist/tree.js';

const near=(a,b,eps=1e-9)=>assert(Math.abs(a-b)<eps,`${a} != ${b}`);
const make=(id='LIVEbelief1',button=1,cards=['As','Js'])=>createLiveHand({id,date:'2026/09/27 10:00:00',players:[{name:'Hero',stack:1000,memoryKey:'test Hero'},{name:'Villain',stack:1000,memoryKey:'test Villain'}],heroSeat:1,button,sb:5,bb:10,cards});
let h=make(),ctx=publicContext(h,h.events.length,h.hero),belief=newBelief(),summary=beliefSummary(belief,[]);
for(let t=0;t<4;t++)for(const cards of [['As','Js'],['2h','7d'],['Ac','Ad']]){
 const policy=actionPolicy(ctx,cards,t,summary);near(policy.reduce((n,a)=>n+a.prob,0),1);assert(policy.every(a=>a.prob>0&&Number.isFinite(a.prob)));
 if(cards[1]==='Js')assert(policy.find(a=>a.allIn).prob<.01,'Deep AJs should not have an automatic shove policy.');
}
const raised=legalActions(ctx).find(a=>a.to===25),posterior=updateBelief(belief,ctx,raised,summary);near(posterior.rows.reduce((n,r)=>n+r.prob,0),1);assert.notDeepEqual(typeMass(posterior.rows),TYPE_PRIOR);assert(posterior.logLoss>0);
const sumEvidence=legalActions(ctx).reduce((total,a)=>total+updateBelief(belief,ctx,a,summary).evidence,0);near(sumEvidence,1);
const known=conditionCards(posterior.rows,[],['As','Js']);assert(known.every(r=>r.cards.includes('As')&&r.cards.includes('Js')));
assert(!JSON.stringify(ctx).includes('As'),'Public policy context must contain no hole cards.');

// Enumerate all legal BB holdings against the inferred opening range, rather
// than accepting a noisy handful of dealt hands as evidence of blind defense.
const defenses=[];
for(const size of [2,2.5,3,4,10,100]){
 let open=make('LIVEdefense'+size*10,1,['7c','2d']);
 open=appendLiveAction(open,{kind:'bet',actor:'Hero',to:size*10});
 const n=nodeBeliefs([],open,open.events.length),c=publicContext(open,open.events.length,'Villain'),image=beliefSummary(n.views.Villain.rows,[]),combos=comboMass(n.ranges.Villain);
 const folds=[0,1,2,3].map(type=>combos.reduce((sum,r)=>sum+r.prob*actionPolicy(c,r.cards,type,image).find(a=>a.kind==='fold').prob,0));
 assert(folds[1]>folds[0]&&folds[0]>folds[2],'Tight/neutral/loose defenses must retain their ordering.');
 defenses.push({size,folds});
}
assert(defenses[0].folds[0]>.15&&defenses[0].folds[0]<.45,'A cheap heads-up open must allow broad BB defense.');
for(let i=1;i<defenses.length;i++)assert(defenses[i].folds[0]>defenses[i-1].folds[0],'Larger opening bets should tighten defense.');
assert(defenses.at(-1).folds[0]>.9,'Cheap blind defense must not turn into loose 100 BB shove calls.');
let limped=appendLiveAction(make('LIVEfreecheck'),{kind:'call',actor:'Hero'});
assert(!actionPolicy(publicContext(limped,limped.events.length,'Villain'),['2c','7d']).some(a=>a.kind==='fold'),'A free BB check cannot fold.');
console.log('Neutral BB fold probability by opening size:',defenses.map(r=>`${r.size} BB: ${(100*r.folds[0]).toFixed(1)}%`).join(', '));

// Freeze a public prefix; later boards, shown cards, winnings and private opponent cards cannot change it.
h=appendLiveAction(h,{kind:'bet',actor:'Hero',to:25});h=appendLiveAction(h,{kind:'call',actor:'Villain'});h=appendLiveAction(h,{kind:'board',cards:['2s','7h','Qd']});h=appendLiveAction(h,{kind:'check',actor:'Villain'});
const step=h.events.length,changed=structuredClone(h);changed.players[1].cards=['Ac','Ad'];changed.heroNet=100000;changed.events.push({type:'action',actor:'Hero',action:'checks',amount:0,street:'Flop',index:step},{type:'street',street:'Turn',board:['2s','7h','Qd','Ah'],index:step},{type:'show',actor:'Villain',cards:['Ac','Ad'],index:step+1});
const node=nodeBeliefs([],h,step),nodeChanged=nodeBeliefs([],changed,step);assert.deepEqual(node.ranges,nodeChanged.ranges);for(const r of node.ranges.Villain)assert(r.cards.every(c=>!['As','Js','2s','7h','Qd'].includes(c)));
let sim=publicContext(h,step,'Hero'),own=['As','Js'],villain=['Kc','Kd'];
const action=legalActions(sim).find(a=>a.to===25);assert(action);let phase=advanceState(sim,action);assert.equal(phase,'action');assert.equal(sim.actor,'Villain');phase=advanceState(sim,legalActions(sim).find(a=>a.kind==='fold'));assert.equal(phase,'terminal');
const paid=terminalPayoff(sim,{Hero:own,Villain:villain},'Hero',975,{rakePct:0});near(paid.payoff,.5);near(paid.award,.5);near(paid.invested,0); // uncalled wager refunded; prior pot belongs to winner

console.time('belief tree regressions');
const result=await analyzeTree({hands:[],hand:h,step,iterations:100,config:{rakePct:0}}),future=await analyzeTree({hands:[],hand:changed,step,iterations:100,config:{rakePct:0}});
assert.deepEqual(result,future,'Tree must be invariant to future/private replay data.');
near(result.allActions.reduce((n,a)=>n+a.policy,0),1);near(result.allActions.reduce((n,a)=>n+a.reach,0),1);
function checkTree(tree){near(tree.opponentRange.reduce((n,r)=>n+r.probability,0),1);if(tree.children.length){near(tree.children.reduce((n,c)=>n+c.conditionalProbability,0),1);tree.children.forEach(checkTree);}}
for(const a of result.allActions){near(a.heroActionRange.reduce((n,r)=>n+r.probability,0),1);near(a.routes.reduce((n,r)=>n+r.p,0),1);near(a.routes.reduce((n,r)=>n+r.contribution,0),a.ev);for(const route of a.routes)near(route.award-route.investment,route.payoff);checkTree(a.tree);assert(a.se>=0);}
assert(result.allActions.some(a=>a.tree.children.some(c=>c.label.includes('Opponent Bet'))),'Checks must permit opponent bets.');
console.timeEnd('belief tree regressions');

// Play full matches with the shared legal policy. Check conservation, unique deals, blind rotation and exact saves.
const random=seeded(8282),history=[];let practice=newPractice(history,3,null,random);
assert.deepEqual(practice.learning,{sharedHands:0,pastHeroActions:0,currentHeroActions:0,heroRevealed:false});
for(let handNumber=0;handNumber<5;handNumber++){
 for(let actions=0;actions<50&&!practice.hand.live.complete;actions++){
  const saved=practiceSave(practice),restored=practiceRestore(saved,history);assert.deepEqual(practiceSave(restored),saved);
  assert.deepEqual(restored.learning,practice.learning,'Learning status must rebuild exactly on resume.');
  assert.deepEqual(restored.filters,practice.filters,'Beliefs must rebuild exactly on resume.');
  // Changing the hidden Hero holding in a bot state cannot change a policy passed only the bot's information.
  const policy=practicePolicy(practice);near(policy.reduce((n,a)=>n+a.prob,0),1);
  const choice=policy.find(a=>a.kind==='call'||a.kind==='check'),count=practice.learning.currentHeroActions;advancePractice(practice,choice,random);
  assert.equal(practice.learning.currentHeroActions,count+1,'Each Hero action must update immediately.');
 }
 assert(practice.hand.live.complete);const finished=practice.hand,end=snapshot(finished,finished.events.length);assert.equal(end.players.reduce((n,p)=>n+p.stack,0)+finished.totalFees,finished.players.reduce((n,p)=>n+p.stack,0));
 const all=[...finished.players[0].cards,...practice.botCards,...practice.deck,...end.board];assert.equal(new Set(all).size,52);assert.equal(all.length,52);assert(!finished.players[1].cards.length,'Private bot cards must stay outside hand records.');history.unshift(finished);
 const learned=learnMemory(history);assert.equal(learned.profiles['Practice Hero'].hands,history.length);assert(learned.images['Practice bot · aggressive → Practice Hero'].hands===history.length);
 assert.equal(practice.learning.heroRevealed,finished.events.some(e=>e.type==='show'&&e.actor===finished.hero));
 if(practice.learning.heroRevealed)assert(practice.filters[finished.hero].every(r=>r.cards.every(c=>finished.players[0].cards.includes(c))),'Public showdown cards must condition the current belief.');
 if(end.players.some(p=>p.stack<=0))break;
 const next=newPractice(history,3,practice,random);assert.equal(next.hand.button,3-finished.button);assert.deepEqual(next.hand.players.map(p=>p.stack),end.players.map(p=>p.stack));
 assert.equal(next.learning.sharedHands,history.length);assert.equal(next.learning.pastHeroActions,learned.images['Practice bot · aggressive → Practice Hero'].actions);practice=next;
}
const broken=practiceSave(practice);broken.deck[0]=broken.botCards[0];assert.throws(()=>practiceRestore(broken,history),/deck/);
// Different observers only receive shared-table evidence. Unknown observers retain the prior.
let observed=make('LIVEshared',1);observed=appendLiveAction(observed,{kind:'fold',actor:'Hero'});observed=appendLiveAction(observed,{kind:'settle'});
const learned=learnMemory([observed]);assert.equal(learned.images['test Villain → test Hero'].hands,1);assert.equal(learned.images['Absent → test Hero'],undefined);near(learned.profiles['test Hero'].posterior.reduce((a,b)=>a+b,0),1);
assert.equal(learnMemory([observed],observed).hands,0,'Current hand cannot train its own prior.');
console.log('PASS: normalized shared policies, Bayesian evidence, private/future isolation, branch accounting, future bets, complete bot hands, exact resume, stacks, blind rotation and observer-specific memory.');
