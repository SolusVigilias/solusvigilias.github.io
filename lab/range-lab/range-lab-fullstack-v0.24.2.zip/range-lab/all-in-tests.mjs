import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {conditionAction,newBelief,conditionCards,nodeBeliefs,comboMass,restoreActionEvidence,updateBelief,beliefSummary} from './dist/learning.js';
import {analyzeAllIn,analyzeCfr,buildRiverGame,trainRiver,cfrActionLikelihood,wagerConditionedBeliefs} from './dist/river-cfr.js';
import {newPractice,practiceSave,practiceRestore,advancePracticeAdaptive} from './dist/practice.js';
import {seeded,publicContext} from './dist/policy.js';
import {RESPONSE_PRIOR,trainResponse} from './dist/adaptation.js';
const config={rakePct:5,rakeCap:1,extraFee:0};
const near=(a,b)=>assert(Math.abs(a-b)<1e-9,`${a} != ${b}`);
const source=newBelief(),get=cards=>source.find(r=>cards.every(c=>r.cards.includes(c))),aa=get(['As','Ah']),six=get(['6h','5c']);
const posterior=conditionAction([{...aa,prob:.8},{...six,prob:.2}],{[aa.key]:.9,[six.key]:.1});near(posterior.find(r=>r.key===aa.key).prob,.72/.74);
let h=createLiveHand({players:[{name:'Hero',stack:735},{name:'Bot',stack:1103}],heroSeat:1,button:1,sb:5,bb:10,cards:['Jd','9d']});
for(const a of [{kind:'bet',actor:'Hero',to:20},{kind:'bet',actor:'Bot',to:735}])h=appendLiveAction(h,a);
const step=h.events.length,before=step-1,event=h.events[before];
const likelihood=Object.fromEntries(comboMass(source).map(r=>[r.key,r.cards.every(c=>six.cards.includes(c))?1:0]));
h.actionEvidence={[before]:{actor:event.actor,action:event.action,to:event.to??null,likelihood,source:'Recorded bot strategy'}};
assert.deepEqual(restoreActionEvidence(h.actionEvidence,h),h.actionEvidence);
assert.throws(()=>restoreActionEvidence({[before]:{...h.actionEvidence[before],actor:'Hero'}},h));
const beliefs=nodeBeliefs([],h,step);assert.equal(comboMass(beliefs.filters.Bot).length,1);
const conditioned=await wagerConditionedBeliefs({hand:h,step,beliefState:beliefs});assert.equal(conditioned.conditioning.source,'Recorded bot strategy');assert.equal(comboMass(conditioned.beliefs.filters.Bot).length,1);
const result=await analyzeCfr({hand:h,step,hands:[],config,equitySamples:3000});assert.equal(result.model,'hand-specific-all-in');near(result.callCost,7.15);near(result.netPot,13.96);near(result.breakEven,7.15/13.96);assert.equal(result.opponentRange.length,1);assert(result.equity>.5);
near(result.allActions.find(a=>a.kind==='call').routes.reduce((s,r)=>s+r.contribution,0),result.allActions.find(a=>a.kind==='call').ev);
assert.equal(await analyzeCfr({hand:h,step,hands:[],config,cancel:()=>true}),null);
// Replay must ignore actual opponent cards and future outcomes.
let future=appendLiveAction(h,{kind:'call',actor:'Hero'});for(const cards of [['Qs','2h','7d'],['5h'],['Tc']])future=appendLiveAction(future,{kind:'board',cards});future.actionEvidence=h.actionEvidence;future.players.find(p=>p.name==='Bot').cards=['As','Ah'];
const replay=await analyzeCfr({hand:future,step,hands:[],config,equitySamples:3000});assert.deepEqual(replay.allActions,result.allActions);
// Exact river evaluation: J9 high loses to 65's pair of fives.
let river=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['Jd','9d']});
for(const a of [{kind:'call',actor:'Hero'},{kind:'check',actor:'Bot'},{kind:'board',cards:['Qs','2h','7d']},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:['5h']},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:['Tc']},{kind:'bet',actor:'Bot',to:990}])river=appendLiveAction(river,a);
const fixed={filters:{Hero:conditionCards(source,['Qs','2h','7d','5h','Tc']),Bot:[{...six,prob:1}]}};
const losing=await analyzeAllIn({hand:river,step:river.events.length,beliefState:fixed,config});assert(losing.exact);near(losing.equity,0);near(losing.allActions.find(a=>a.kind==='call').ev,-9.9);near(losing.policy.find(a=>a.kind==='fold').prob,1);
// Unrecorded human actions retain their learned posterior, without CFR reconstruction.
const unknown={...h,actionEvidence:{}};const inferred=await analyzeCfr({hand:unknown,step,hands:[],config,solveOptions:{iterations:10,samples:128,runouts:4},equitySamples:1000});assert.equal(inferred.conditioning.source,'Learned opponent action model');
// A sharply different learned posterior must survive unchanged, including
// response parameters. Conditioning is idempotent and runs no solver work.
const learned=nodeBeliefs([],unknown,step);
learned.filters.Bot=[{...six,prob:1}];learned.ranges.Bot=[{...six,prob:1}];
const snapshot=JSON.stringify(learned);let progress=0;
const kept=await wagerConditionedBeliefs({hand:unknown,step,beliefState:learned,onProgress:()=>progress++});
assert.strictEqual(kept.beliefs,learned);assert.equal(JSON.stringify(learned),snapshot);assert.equal(progress,0);
assert.strictEqual((await wagerConditionedBeliefs({hand:unknown,step,beliefState:kept.beliefs})).beliefs,learned);
const learnedEV=await analyzeAllIn({hand:unknown,step,beliefState:kept.beliefs,config,equitySamples:3000});
assert.equal(learnedEV.opponentRange.length,1);assert(learnedEV.equity>.5);
// Repeated observed shoves change the predictive posterior and that learned
// distribution reaches wager evaluation intact (not a newly solved CFR range).
const repeatedPrior=nodeBeliefs([],unknown,before),model=RESPONSE_PRIOR();
const shoveCtx={...publicContext(unknown,before,'Bot'),responseModel:model};
const other=beliefSummary(repeatedPrior.filters.Hero,[]);
const originalUpdate=updateBelief(repeatedPrior.filters.Bot,shoveCtx,event,other);
for(let i=0;i<12;i++)trainResponse(model,shoveCtx,updateBelief(repeatedPrior.filters.Bot,shoveCtx,event,other),event);
const adaptedUpdate=updateBelief(repeatedPrior.filters.Bot,shoveCtx,event,other);
assert.equal(model.actions,12);assert.notEqual(adaptedUpdate.evidence,originalUpdate.evidence);
assert(adaptedUpdate.rows.some((r,i)=>Math.abs(r.prob-originalUpdate.rows[i].prob)>1e-10));
const adapted={...learned,filters:{...learned.filters,Bot:adaptedUpdate.rows},responses:{...learned.responses,Bot:model}};
assert.strictEqual((await wagerConditionedBeliefs({hand:unknown,step,beliefState:adapted})).beliefs,adapted);
// Policy evidence is independent of actual cards selected to query the strategy.
const pre=nodeBeliefs([],unknown,before),prehand={...unknown,hero:'Bot',players:unknown.players.map(p=>({...p,cards:p.name==='Bot'?['As','Ah']:[]}))};
const game=buildRiverGame({hand:prehand,step:before,beliefState:pre,config},{samples:128,runouts:4});trainRiver(game,10);const action=game.root.actions.at(-1),plan={game,node:game.root,mass:game.mass};const actual=cfrActionLikelihood(plan,action);assert(Object.keys(actual).length>1000);assert(Object.values(actual).every(p=>p>=0&&p<=1));
// Newly played bot actions survive save/restore, with no private hand in evidence.
let p=newPractice([],0,null,seeded(773),{pauseAtBot:true});p=await advancePracticeAdaptive(p,{kind:'call'},seeded(44));const saved=practiceSave(p),restored=practiceRestore(saved,[]);assert(Object.keys(saved.actionEvidence).length>0);assert.deepEqual(restored.hand.actionEvidence,p.hand.actionEvidence);assert.deepEqual(restored.filters,p.filters);
console.log('PASS: action likelihood Bayes update, exact-card all-in EV and rake, blockers, recorded/inferred labels, future-card isolation, cancellation, and practice evidence persistence.');
