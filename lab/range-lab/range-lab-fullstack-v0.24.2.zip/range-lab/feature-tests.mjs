import assert from 'node:assert/strict';
import {RESPONSE_PRIOR,RESPONSE_FEATURES,trainResponse,responseContext} from './dist/adaptation.js';
import {actionPolicy} from './dist/policy.js';
import {newBelief,conditionCards,beliefSummary,updateBelief,freshMemory,restoreMemory} from './dist/learning.js';
const model=RESPONSE_PRIOR(),ctx={players:[{name:'Hero',stack:990,streetContribution:0,position:'BTN/SB'},{name:'Bot',stack:990,streetContribution:10,position:'BB'}],actor:'Hero',street:'Flop',board:['Qh','8h','4s'],bb:10,pot:30,level:10,minRaise:10,raises:1,acted:{},responseModel:model};
const rows=conditionCards(newBelief(),ctx.board),opposing=beliefSummary(rows,ctx.board),event={kind:'call'},base=updateBelief(rows,ctx,event,opposing),key=responseContext(ctx);
const zero=()=>Object.fromEntries(['fold','check','call','bet'].map(k=>[k,RESPONSE_FEATURES.map(()=>0)]));
model.contexts[key]={theta:{fold:0,check:0,call:0,bet:0},weights:zero(),n:0,counts:{fold:0,check:0,call:0,bet:0},logLoss:0};
// Differentiate the marginal likelihood across hidden holdings, including the
// lapse and action-dependent size features, not a known-hand surrogate loss.
for(const group of ['fold','call','bet'])for(const index of [0,1,5,7,9,13]){
 const epsilon=1e-5,w=model.contexts[key].weights[group];w[index]=epsilon;const plus=updateBelief(rows,ctx,event,opposing).logLoss;
 w[index]=-epsilon;const minus=updateBelief(rows,ctx,event,opposing).logLoss;w[index]=0;
 assert(Math.abs(base.featureGradient[group][index]+(plus-minus)/(2*epsilon))<1e-7,`${group}/${index} gradient`);
}
const prob=cards=>actionPolicy(ctx,cards,0,opposing).find(a=>a.kind==='call').prob;
const weak=['7c','2d'],strong=['Qs','Qc'],initial=[prob(weak),prob(strong)];
// Controlled inference fixture: a narrow strong range repeatedly calls.
// Training uses that range; no access to the player's actual private cards.
const concentrated=conditionCards(rows,[],strong);
for(let n=0;n<20;n++)trainResponse(model,ctx,updateBelief(concentrated,ctx,event,opposing),event);
const learned=[prob(weak),prob(strong)],w=model.contexts[key].weights.call;
assert(w[0]>0,'Strong-range calls should fit a strength-specific call coefficient.');
const logitChange=cards=>{const p=actionPolicy(ctx,cards,0,opposing),a=p.find(a=>a.kind==='call');return a.features.reduce((n,x,i)=>n+x*w[i],0);};
assert(logitChange(strong)>logitChange(weak),'Learned response must depend on the candidate holding.');
const before=updateBelief(concentrated,ctx,event,opposing).logLoss;
assert(before<base.logLoss);
const memory=freshMemory();memory.profiles.Hero={posterior:[.55,.15,.15,.15],hands:1,actions:20,logLoss:1,response:model};
assert.deepEqual(restoreMemory(JSON.parse(JSON.stringify(memory))),memory);
const old=structuredClone(memory);delete old.profiles.Hero.response.contexts[key].weights;assert.doesNotThrow(()=>restoreMemory(old));
const bad=structuredClone(memory);bad.profiles.Hero.response.contexts[key].weights.call[0]=Infinity;assert.throws(()=>restoreMemory(bad));
console.log('PASS: marginal feature gradients, hand-conditioned transfer, legacy migration, exact memory round-trip, invalid-weight rejection.',{initial,learned});
