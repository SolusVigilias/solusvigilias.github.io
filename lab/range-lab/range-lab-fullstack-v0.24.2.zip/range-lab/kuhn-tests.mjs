import assert from 'node:assert/strict';
import {newKuhn,trainKuhn,measureKuhn,kuhnStrategy,kuhnValue,kuhnBestResponse,kuhnTerminal} from './dist/kuhn.js';
const near=(a,b,e=1e-10)=>assert(Math.abs(a-b)<e,`${a} vs ${b}`);
near(kuhnTerminal('bf',[0,2]),1);near(kuhnTerminal('cbf',[2,0]),-1);near(kuhnTerminal('bc',[2,0]),2);near(kuhnTerminal('cc',[0,1]),-1);
// Analytic equilibrium family member alpha=1/3. A clairvoyant best response
// would incorrectly beat this, so this also checks information-set consistency.
const eq={'0:J:':[2/3,1/3],'0:Q:':[1,0],'0:K:':[0,1],
 '0:J:cb':[1,0],'0:Q:cb':[1/3,2/3],'0:K:cb':[0,1],
 '1:J:c':[2/3,1/3],'1:Q:c':[1,0],'1:K:c':[0,1],
 '1:J:b':[1,0],'1:Q:b':[2/3,1/3],'1:K:b':[0,1]};
near(kuhnValue(eq),-1/18);near(kuhnBestResponse(eq,0).value,-1/18);near(kuhnBestResponse(eq,1).value,1/18);
const m=newKuhn(),initial=measureKuhn(m);near(initial.nashConv,11/12);
trainKuhn(m,1000);const intermediate=measureKuhn(m);trainKuhn(m,9000);const final=measureKuhn(m);
assert(final.nashConv<.01);assert(final.nashConv<intermediate.nashConv);near(final.value,-1/18,.001);
for(const row of Object.values(kuhnStrategy(m))){near(row[0]+row[1],1);assert(row.every(p=>p>=0&&p<=1));}
const uninterrupted=trainKuhn(newKuhn(),10000);assert.deepEqual(m,uninterrupted,'Training chunk boundaries must not affect the result.');
console.log('PASS: analytic equilibrium and exact best responses, payoff rules, convergence, normalization and deterministic resume.',{iterations:final.iterations,value:final.value,nashConv:final.nashConv});
