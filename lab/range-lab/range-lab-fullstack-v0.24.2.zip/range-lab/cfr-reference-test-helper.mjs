// v0.19 reference traversal retained only for mathematical regression tests.
const B=6,S=B*B;
const normalized=a=>{const total=a.reduce((s,v)=>s+v,0);return total?a.map(v=>v/total):a.map(()=>1/a.length);};
function strategy(node,average){return (average?node.sum:node.regret).map(row=>normalized(average?row:row.map(v=>Math.max(0,v))));}
export function trainRiverReference(game,count=1){
 function visit(node,reach,chanceReach){
  if(node.values)return node.values;
  if(node.chance){const values=[Array(S).fill(0),Array(S).fill(0)];node.children.forEach((child,a)=>{const childValues=visit(child,reach,chanceReach.map((r,k)=>r*node.probs[a][k]));for(let p=0;p<2;p++)for(let k=0;k<S;k++)values[p][k]+=node.probs[a][k]*childValues[p][k];});return values;}
  const actor=node.actor,policy=strategy(node,false),children=node.children.map((child,a)=>{const next=[...reach];next[actor]=reach[actor].map((r,b)=>r*policy[b][a]);return visit(child,next,chanceReach);});
  const values=[Array(S).fill(0),Array(S).fill(0)];
  for(let k=0;k<S;k++){const t0=Math.floor(k/B),t1=k%B,type=actor===0?t0:t1;
   for(let a=0;a<node.actions.length;a++)for(let p=0;p<2;p++)values[p][k]+=policy[type][a]*children[a][p][k];
   const counter=game.mass[k]*chanceReach[k]*reach[1-actor][actor===0?t1:t0];
   for(let a=0;a<node.actions.length;a++)node.regret[type][a]+=counter*(children[a][actor][k]-values[actor][k]);
  }
  const marginal=Array(B).fill(0);for(let k=0;k<S;k++)marginal[actor===0?Math.floor(k/B):k%B]+=game.mass[k]*chanceReach[k];
  for(let b=0;b<B;b++)for(let a=0;a<node.actions.length;a++)node.sum[b][a]+=marginal[b]*reach[actor][b]*policy[b][a];
  return values;
 }
 for(let i=0;i<count;i++){visit(game.root,[Array(B).fill(1),Array(B).fill(1)],Array(S).fill(1));game.iterations++;}return game;
}
