import assert from 'node:assert/strict';
import {RESPONSE_PRIOR,trainResponse,MEMORY_DECAY} from './dist/adaptation.js';
import {newBelief,conditionCards,beliefSummary,updateBelief,freshMemory,completeMemory,nodeBeliefs,restoreMemory} from './dist/learning.js';
import {actionPolicy,seeded} from './dist/policy.js';
import {createLiveHand,appendLiveAction,undoLiveAction} from './dist/live.js';
import {newPractice,practiceSave,practiceRestore,advancePractice,practicePolicy} from './dist/practice.js';

const model=RESPONSE_PRIOR(),ctx={players:[{name:'Hero',stack:990,streetContribution:0,position:'BTN/SB'},{name:'Bot',stack:990,streetContribution:0,position:'BB'}],actor:'Hero',street:'Flop',board:['Qh','8d','4s'],bb:10,pot:20,level:0,minRaise:10,raises:0,acted:{},responseModel:model};
const rows=conditionCards(newBelief(),ctx.board),opposing=beliefSummary(rows,ctx.board),frequency=()=>actionPolicy(ctx,['7c','2d'],0,opposing).filter(a=>a.kind==='bet').reduce((n,a)=>n+a.prob,0);
const observe=kind=>{const a={kind,to:10};trainResponse(model,ctx,updateBelief(rows,ctx,a,opposing),a);};
for(let i=0;i<60;i++)observe('bet');const before=frequency(),oldWeight=model.contexts['Flop/free'].recent.bet;
for(let i=0;i<8;i++)observe('check');const after=frequency(),cell=model.contexts['Flop/free'];
assert(Math.abs(cell.recent.bet-oldWeight/2)<1e-10);assert(after<before/3,'A sustained old pattern must not prevent a rapid reversal.');
const frozen=structuredClone(cell);for(let i=0;i<8;i++)trainResponse(model,{...ctx,street:'Turn'},{gradient:{bet:.1},logLoss:1},{kind:'bet'});assert.deepEqual(model.contexts['Flop/free'],frozen,'Half-life is measured in comparable opportunities.');
console.log('After 60 bets, then 8 checks:',{betPredictionBefore:before,betPredictionAfter:after,recentBetRate:cell.recent.bet/cell.weight});

// A compact checkpoint replaces old hand records for next-hand inference.
let h=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Villain',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Kd']});h.memoryStart=freshMemory();
h=appendLiveAction(h,{kind:'fold',actor:'Hero'});assert.equal(undoLiveAction(h).memoryStart.hands,0);h=appendLiveAction(h,{kind:'settle'});
const checkpoint=completeMemory(h),next=createLiveHand({...h.live.spec,id:undefined,handNumber:2,cards:['2c','3c']});next.memoryStart=restoreMemory(JSON.parse(JSON.stringify(checkpoint)));
assert.deepEqual(nodeBeliefs([],next,next.events.length),nodeBeliefs([h],next,next.events.length));assert.equal(next.memoryStart.hands,1);
const bad=structuredClone(checkpoint);Object.values(bad.profiles)[0].response.contexts['<img>']={};assert.throws(()=>restoreMemory(bad));

const random=seeded(8282),p=newPractice([h],3,null,random);assert.equal(p.learning.sharedHands,0,'A new match ignores all prior imported/session history.');
for(let i=0;i<50&&!p.hand.live.complete;i++)advancePractice(p,practicePolicy(p).find(a=>a.kind==='check'||a.kind==='call'),random);
assert(p.hand.live.complete);
const nextPractice=newPractice([],3,p,random),restored=practiceRestore(JSON.parse(JSON.stringify(practiceSave(nextPractice))),[]);
assert.equal(nextPractice.learning.sharedHands,1);assert.deepEqual(restored.responses,nextPractice.responses);assert.deepEqual(restored.filters,nextPractice.filters);
assert.equal(newPractice([p.hand],3,null,random).learning.sharedHands,0);
console.log('PASS: exact EMA decay, strategy reversal, context isolation, compact live and practice continuity without history, fresh-match reset, validated checkpoints.');
