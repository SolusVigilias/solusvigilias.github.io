import assert from 'node:assert/strict';
import {createLiveHand,appendLiveAction} from './dist/live.js';
import {newBelief,conditionCards} from './dist/learning.js';
import {buildRiverGame,trainRiver,measureRiver,advanceCfrPlan,cfrPlanDecision,riverGroup} from './dist/river-cfr.js';
import {advancePracticeAdaptive,botDecisionInput} from './dist/practice.js';
import {RESPONSE_PRIOR} from './dist/adaptation.js';
import {publicContext} from './dist/policy.js';
let h=createLiveHand({players:[{name:'Hero',stack:1000},{name:'Bot',stack:1000}],heroSeat:1,button:1,sb:5,bb:10,cards:['As','Ad']});
for(const c of [{kind:'call',actor:'Hero'},{kind:'check',actor:'Bot'},{kind:'board',cards:['Qh','8d','4s']},{kind:'check',actor:'Bot'},{kind:'check',actor:'Hero'},{kind:'board',cards:['2c']}])h=appendLiveAction(h,c);
const rows=conditionCards(newBelief(),['Qh','8d','4s','2c']),p={hand:h,type:0,botCards:['Qc','Qd'],deck:['9h'],filters:{Hero:rows,Bot:rows},responses:{Hero:RESPONSE_PRIOR(),Bot:RESPONSE_PRIOR()},learning:{sharedHands:0},config:{rakePct:5,rakeCap:1,extraFee:0}};
const input=botDecisionInput(p),start=Date.now(),game=buildRiverGame(input,{samples:512}),initial=measureRiver(game);
let chanceCount=0;function inspect(node){if(node.chance){chanceCount++;game.mass.forEach((m,k)=>{if(m)assert(Math.abs(node.probs.reduce((n,p)=>n+p[k],0)-1)<1e-12);});}node.children?.forEach(inspect);}inspect(game.root);assert(chanceCount>0);
trainRiver(game,600);const final=measureRiver(game);assert(final.nashConv<initial.nashConv/5);
const changed=structuredClone(input);changed.hand.players.find(p=>p.name===changed.hand.hero).cards=['7c','6c'];const other=buildRiverGame(changed,{samples:512});assert.deepEqual(other.mass,game.mass);assert.deepEqual(other.root.children[0].actions,game.root.children[0].actions);
let plan={game,node:game.root,mass:game.mass,steps:0};
const originalMass=[...plan.mass],rootPolicy=game.root.sum.map(row=>{const s=row.reduce((a,b)=>a+b,0);return row.map(v=>v/s);}),index=game.root.actions.findIndex(a=>a.kind==='check');
plan=advanceCfrPlan(plan,{type:'action',actor:'Bot',action:'checks'});const expected=originalMass.map((m,k)=>m*rootPolicy[Math.floor(k/6)][index]),total=expected.reduce((a,b)=>a+b,0);assert.deepEqual(plan.mass,expected.map(v=>v/total));
plan=advanceCfrPlan(plan,{type:'action',actor:'Hero',action:'checks'});assert(plan.node.chance);
plan=advanceCfrPlan(plan,{type:'street',board:['Qh','8d','4s','2c','9h']});assert(cfrPlanDecision(plan)?.reused);assert.equal(game.iterations,600);
assert.equal(advanceCfrPlan({game,node:game.root,mass:game.mass,steps:0},{type:'action',actor:'Bot',action:'bets',amount:123}),null);
const noRake=buildRiverGame({...input,config:{rakePct:0,rakeCap:0}},{samples:32}),pot=publicContext(input.hand,input.step,input.hand.hero).pot/input.hand.bb;
function conserved(node){if(node.values){for(let k=0;k<36;k++)assert(Math.abs(node.values[0][k]+node.values[1][k]-pot)<1e-10);}node.children?.forEach(conserved);}conserved(noRake.root);
// Actual play follows the turn strategy's river continuation, rather than
// invoking a new river solve. A deterministic draw chooses check when supported.
await advancePracticeAdaptive(p,null,()=>0);assert.equal(p.lastDecision.engine,'turn-river-cfr');const trained=p.cfrPlan.game;
await advancePracticeAdaptive(p,{kind:'check'},()=>0);assert.equal(p.lastDecision.engine,'turn-river-cfr');assert(p.lastDecision.reused);assert.equal(p.cfrPlan.game,trained);
await advancePracticeAdaptive(p,{kind:'check'},()=>0);assert(p.hand.live.complete);
console.log('PASS: coupled turn/river solve, chance normalization, conditional policy range update, exact continuation reuse, unsupported-action invalidation, no hidden-card input, chip conservation and complete hand.',{initialGap:initial.nashConv,finalGap:final.nashConv,nodes:game.nodeCount,groups:game.riverGroups,elapsedMs:Date.now()-start});
