import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const output=process.argv[2];
if(!output||!path.isAbsolute(output))throw Error('Pass an absolute output HTML path.');
const modules={'./kuhn.js':'__kuhn','./poker.js':'__poker','./live.js':'__live','./live-ui.js':'__liveUI','./adaptation.js':'__adaptation','./policy.js':'__policy','./learning.js':'__learning','./tree.js':'__tree','./exact-cfr.js':'__exactCfr','./river-cfr.js':'__riverCfr','./exploration.js':'__exploration','./practice.js':'__practice','./player-profiles.js':'__playerProfiles','./learning-ui.js':'__learningUI'};
const read=name=>fs.readFileSync(path.join(root,'dist',name),'utf8');
const imports=s=>s.replace(/^import \{([^}]+)\} from '([^']+)';\s*$/gm,(_,names,file)=>{
 if(!modules[file])throw Error('Unknown module '+file);
 return 'const {'+names+'}='+modules[file]+';';
});
let script='(async function(){\n"use strict";\n';
for(const [file,id] of Object.entries(modules)){
 const source=read(file.slice(2)),exports=[...source.matchAll(/^export (?:function|const) (\w+)/gm)].map(m=>m[1]);
 script+='const '+id+'=(()=>{\n'+imports(source).replace(/^export /gm,'')+'\nreturn {'+exports.join(',')+'};\n})();\n';
}
const sample=JSON.stringify(read('sample.txt')).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
let app=imports(read('app.js'));
const fetchSample="const text=await(await fetch('./sample.txt')).text();";
if(!app.includes(fetchSample))throw Error('Sample loader changed.');
app=app.replace('href="cloud.html"', 'href="https://poker.solusvigilias.com/cloud.html"');
app=app.replace(fetchSample,()=>'const text='+sample+';').replace('CASH GAME WORKSPACE','OFFLINE CASH GAME WORKSPACE');
script+=app+'\n})().catch(error=>{console.error(error);document.getElementById("app").textContent="Range Lab could not start: "+error.message;});\n';
if(/<\/script/i.test(script)||/\bfetch\(/.test(script))throw Error('Unsafe inline script or unexpected network dependency.');
const css=read('style.css').replace(/^@import[^;]+;\s*/,'');
const html=read('index.html').replace('<link rel="stylesheet" href="style.css">',()=>'<style>\n'+css+'\n</style>').replace('<script type="module" src="app.js"></script>',()=>'<script>\n'+script+'</script>').replace('Hand history workspace</title>','Offline hand history workspace</title>').replace('<body>','<body><noscript>Enable JavaScript to use Range Lab.</noscript>');
fs.writeFileSync(output,html);console.log('Offline app written to '+output);
