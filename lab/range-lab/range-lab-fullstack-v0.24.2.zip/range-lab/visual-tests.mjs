import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseHistory,memory,playerKey,snapshot} from './dist/poker.js';
import {createLiveHand,appendLiveAction,restoreLiveHand} from './dist/live.js';
import {defaultLiveSetup,playerCatalog,liveSetupView,visualLiveView} from './dist/live-ui.js';
const imported=parseHistory(fs.readFileSync(new URL('./dist/sample.txt',import.meta.url),'utf8'),'Imported GG').hands;
const catalog=playerCatalog(imported),hero=catalog.find(p=>p.name==='Hero'),villain=catalog.find(p=>p.name!=='Hero');
assert(hero.key.includes('[Imported GG]'));assert.equal(hero.stats.hands,42);
const action=(h,kind,to)=>appendLiveAction(h,{kind,actor:h.live.actor,...(to===undefined?{}:{to})});
const fromDraft=d=>createLiveHand({players:d.players.slice(0,d.count).map(p=>({name:p.name,stack:Math.round(Number(p.stack)*100),memoryKey:p.memoryKey})),heroSeat:d.hero,button:d.button,sb:Math.round(Number(d.sb)*100),bb:Math.round(Number(d.bb)*100),cards:d.cards,sessionId:d.sessionId||undefined,handNumber:d.handNumber});
let h=createLiveHand({players:[{name:'My seat',stack:1000,memoryKey:hero.key},{name:villain.name,stack:1000,memoryKey:villain.key}],heroSeat:1,button:1,sb:5,bb:10,cards:'As Kh',id:'LIVEz',date:'2026/09/28 06:00:00'});
h=action(h,'fold');h=appendLiveAction(h,{kind:'settle',fee:0,winners:[]});
const records=memory([...imported,h]);assert.equal(records.find(p=>p.key===hero.key).hands,43);assert.equal(records.find(p=>p.key===hero.key).net,hero.stats.net-5);
assert.equal(playerCatalog([h,...imported]).find(p=>p.key===hero.key).source,'Imported GG','Imported source labels must survive a live display-name alias.');
assert.equal(records.find(p=>p.key===villain.key).hands,villain.stats.hands+1);
const draft=defaultLiveSetup(h);assert.equal(draft.cards,'');assert.equal(draft.button,2);assert.equal(draft.handNumber,2);assert.equal(draft.sessionId,h.live.spec.sessionId);assert.equal(draft.players[0].memoryKey,hero.key);assert.equal(draft.players[0].stack,'9.95');
draft.cards='Ac Kd';const next=fromDraft(draft);assert.equal(next.players[0].position,'BB');assert.equal(next.players[1].position,'BTN/SB');assert.equal(next.events[0].actor,villain.name);assert.equal(next.events[1].actor,'My seat');
const sameSecond=restoreLiveHand({...next.live.spec,id:'LIVEa',date:h.date},next.live.commands);
assert.equal(memory([...imported,h,sameSecond],sameSecond).find(p=>p.key===hero.key).hands,43,'Session order must survive equal timestamps and inverted ID order.');
assert.deepEqual(restoreLiveHand(JSON.parse(JSON.stringify(next.live.spec)),[]),next);
assert.equal(playerKey(next,next.players[0]),hero.key);

// A six-player hand advances the button, both blinds, and each ending stack.
const six=defaultLiveSetup();six.cards='Ah Ad';let table=fromDraft(six);
while(table.live.phase==='action')table=action(table,'fold');
table=appendLiveAction(table,{kind:'settle',fee:0,winners:[]});const d6=defaultLiveSetup(table);d6.cards='Ac As';
const next6=fromDraft(d6);assert.equal(next6.button,2);assert.equal(next6.players[2].position,'SB');assert.equal(next6.players[3].position,'BB');
assert.deepEqual(next6.players.map(p=>p.stack),snapshot(table,table.events.length).players.map(p=>p.stack));

// Transition to heads-up after the old button busts: the BB advances correctly.
let three=createLiveHand({players:[{name:'A',stack:100},{name:'B',stack:200},{name:'C',stack:500}],heroSeat:1,button:1,sb:5,bb:10,cards:'As Ah'});
three=action(three,'all-in');three=action(three,'all-in');three=action(three,'call');
for(const cards of ['2c 3d 7s','8c','9h'])three=appendLiveAction(three,{kind:'board',cards});
three=appendLiveAction(three,{kind:'settle',fee:0,winners:[['B'],['B']]});
const d2=defaultLiveSetup(three);assert.equal(d2.count,2);assert.equal(d2.players[d2.button-1].name,'C');d2.cards='Ks Qh';const two=fromDraft(d2);assert.equal(two.players.find(p=>p.name==='B').position,'BB');

// Visual surfaces contain the full deck and stable, unique input identifiers.
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const money=n=>'$'+(n/100).toFixed(2);
const html=liveSetupView(draft,{esc,money,hands:imported,selectedSeat:1});
assert.equal((html.match(/data-action="live-card"/g)||[]).length,52);
assert.equal((html.match(/data-action="live-seat"/g)||[]).length,2);assert(html.includes('Choose a player from history'));assert(html.includes('52 cards'));
const entry={board:[],shown:{},winners:{},amount:'',fee:'0.00',showHero:false};
const live=visualLiveView(next,{entry,seat:1,target:null},{esc,money,hands:[...imported,h,next]});
for(const page of [html,live]){const ids=[...page.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);}
console.log('PASS: imported profile links, aliased names, accumulated memory, same-second session order, next-hand stacks/button/blinds, heads-up transition, export restoration, and 52-card visual controls.');
